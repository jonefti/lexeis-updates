window.APP_BUILD = 7; window.APP_VERSION = '2.3.2';
