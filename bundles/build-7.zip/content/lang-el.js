/* Language pack settings: Greek (adult, intermediate/advanced) */
window.LANG = {
  code: 'el', name: 'Greek', native: 'Ελληνικά', flag: '🇬🇷', tts: 'el-GR', engine: 'Greek', audience: 'adult',
  hello: h => h < 12 ? 'Καλημέρα' : h < 18 ? 'Καλησπέρα' : 'Καλό βράδυ',
  dateLocale: 'el-GR',
  wordRe: /[\u0370-\u03FF\u1F00-\u1FFF]+/g,
  lookupUrl: w => 'https://en.wiktionary.org/wiki/' + encodeURIComponent(w) + '#Greek',
  addPlaceholder: 'e.g. η οδός, γράφω, ωραίος',
  writePlaceholder: 'Γράψε στα ελληνικά…',
  chatPlaceholder: 'Γράψε κάτι…',
  chatHello: 'Γεια σου! Pick a topic or just say hello in Greek.',
  topicStart: t => `Ας μιλήσουμε για: ${t}. Ξεκίνα εσύ.`,
  learner: 'The learner is an English-speaking adult at intermediate/advanced (B1–B2) level in Modern Greek. They struggle most with vocabulary retention, noun gender, declension, conjugation and irregular verbs. Use natural, everyday spoken Modern Greek, including common colloquial expressions.',
  tutorTopics: ['Free chat', 'My day', 'Food & cooking', 'Travel in Greece', 'Family', 'Work', 'Films & series', 'Football', 'Plans for the weekend', 'Greek news', 'Role-play: at a taverna', 'Role-play: at the doctor'],
  writingPrompts: ['Describe your perfect Sunday in Greece.', 'Write a message to a friend inviting them to dinner on Friday.', 'What did you do last weekend? Use the aorist.', 'Describe someone in your family: looks and character.', 'Write a short review of a restaurant or café you like.', 'What are your plans for next summer? Use θα.', 'Write a complaint email to a hotel about a noisy room.', 'Tell a funny story that happened to you.', 'Do you prefer the city or the village? Why?', 'Write a reply to an Instagram post about Greek food.', 'Explain how to make your favourite dish.', 'What would you change about where you live?'],
  formExample: 'πήγαμε or γυναικών',
  dictLevels: ['', 'core', 'intermediate', 'advanced']
};
