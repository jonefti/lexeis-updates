/* Language pack settings: Spanish, from first lessons (Year 7) through to GCSE. Stages gate content and tenses. */
window.LANG = {
  code: 'es', name: 'Spanish', native: 'Español', flag: '🇪🇸', tts: 'es-ES', engine: 'Spanish', audience: 'teen',
  hello: h => h < 12 ? '¡Buenos días!' : h < 20 ? '¡Buenas tardes!' : '¡Buenas noches!',
  dateLocale: 'es-ES',
  wordRe: /[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+/g,
  lookupUrl: w => 'https://www.spanishdict.com/translate/' + encodeURIComponent(w),
  addPlaceholder: 'e.g. el perro, hablar, bonito',
  writePlaceholder: 'Escribe en español…',
  chatPlaceholder: 'Escribe algo…',
  chatHello: '¡Hola! Pick a topic or just say hello in Spanish.',
  topicStart: t => `Vamos a hablar de: ${t}. Empieza tú.`,
  learner: 'The learner is a British teenager (about 14–16) studying Spanish for GCSE, roughly A2–B1. Use clear, everyday Spanish from Spain, and simple, encouraging English explanations. Keep content age-appropriate.',
  tutorTopics: ['Free chat', 'Me and my family', 'School', 'Free time', 'Food', 'My town', 'Holidays', 'Technology', 'Future plans', 'Role-play: café', 'Role-play: shopping', 'GCSE speaking practice'],
  writingPrompts: ['Describe yourself and your family.', 'What do you do at the weekend?', 'Describe your school and your favourite subject. Give reasons.', 'Write about your last holiday (use the preterite).', 'What are your plans for next summer?', 'What do you think about social media?', 'Describe your town: what is there to do?', 'What job would you like to do and why?', 'Write an email to a Spanish friend inviting them to stay.', 'What do you do to help the environment?'],
  formExample: 'tengo or canciones',
  dictLevels: ['', 'starter', 'building up', 'GCSE foundation', 'GCSE higher'],
  defaultStage: 1,
  stages: [
    { id: 1, name: 'Starter', desc: 'Just started Spanish (around Year 7)', dict: 1, audience: 'kid', tenses: ['present'],
      learner: 'The learner is a British child of about 11 who has just started learning Spanish at secondary school (complete beginner, A1). Use very short, simple sentences in the present tense only, with basic words: greetings, numbers, family, pets, colours, school things, food, likes and dislikes. Give very simple, encouraging English explanations. Keep everything friendly and age-appropriate, and never ask for personal details such as their address, school name or surname.',
      tutorTopics: ['Say hello', 'Me and my family', 'My pets', 'Colours', 'Numbers & age', 'My school bag', 'Food I like', 'Days of the week'],
      writingPrompts: ['Write 3 sentences: your name, your age and where you live.', 'Describe your family: who is in it?', 'Do you have a pet? Describe it.', 'What is in your school bag?', 'What food do you like and not like?', 'What is your favourite colour and why?'] },
    { id: 2, name: 'Building up', desc: 'Years 8–9: more topics, first past tense', dict: 2, audience: 'teen', tenses: ['present', 'preterite', 'imperative'],
      learner: 'The learner is a British student of about 12–14 in their 2nd or 3rd year of Spanish (A1–A2). Use simple everyday Spanish from Spain: mostly present tense, the near future (ir a + infinitive) and simple preterite. Give short, clear, encouraging English explanations. Keep content age-appropriate and never ask for personal details.' },
    { id: 3, name: 'GCSE Foundation', desc: 'Years 10–11, foundation tier', dict: 3, audience: 'teen', tenses: ['present', 'preterite', 'imperfect', 'future', 'perfect', 'imperative'] },
    { id: 4, name: 'GCSE Higher', desc: 'Years 10–11, aiming for top grades', dict: 4, audience: 'teen', tenses: ['present', 'preterite', 'imperfect', 'future', 'conditional', 'perfect', 'imperative'],
      learner: 'The learner is a British teenager (about 15–16) studying for GCSE Spanish at higher tier (B1). Use natural Spanish from Spain, including a range of tenses, opinions with reasons and some complex structures examiners reward. Explanations in clear, encouraging English. Keep content age-appropriate.' }
  ]
};
