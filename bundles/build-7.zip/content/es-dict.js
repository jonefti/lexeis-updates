/* Spanish core dictionary for a teenage learner (GCSE level). Format: lemma|type|meaning|extra
   type: m f (noun gender), v verb, a adjective, adv, prep, conj, pron, x phrase. Extra: emoji, or verb stem change ie / ue / i
   Levels follow the stages: 1 starter, 2 building up, 3 GCSE foundation, 4 GCSE higher */
window.LANG_DICT_RAW = `
#1 Hello!
hola|x|hello|👋
adiós|x|goodbye|👋
buenos días|x|good morning|🌅
buenas tardes|x|good afternoon|🌇
buenas noches|x|good night|🌙
por favor|x|please|🙏
gracias|x|thank you|🙏
de nada|x|you're welcome|😊
sí|x|yes|✅
no|x|no|❌
¿qué tal?|x|how are you?|🙂
bien|adv|well, fine|👍
mal|adv|badly, not well|👎
fenomenal|a|great|🤩
me llamo|x|my name is|🏷️
¿cómo te llamas?|x|what's your name?|❓
tengo ... años|x|I'm ... years old|🎂
lo siento|x|sorry|😔
hasta luego|x|see you later|👋
#1 Numbers
uno|x|one|1️⃣
dos|x|two|2️⃣
tres|x|three|3️⃣
cuatro|x|four|4️⃣
cinco|x|five|5️⃣
seis|x|six|6️⃣
siete|x|seven|7️⃣
ocho|x|eight|8️⃣
nueve|x|nine|9️⃣
diez|x|ten|🔟
once|x|eleven|
doce|x|twelve|
trece|x|thirteen|
catorce|x|fourteen|
quince|x|fifteen|
dieciséis|x|sixteen|
veinte|x|twenty|
treinta|x|thirty|
cuarenta|x|forty|
cincuenta|x|fifty|
cien|x|a hundred|💯
#1 Days & months
lunes|m|Monday|📅
martes|m|Tuesday|📅
miércoles|m|Wednesday|📅
jueves|m|Thursday|📅
viernes|m|Friday|📅
sábado|m|Saturday|🎉
domingo|m|Sunday|😴
enero|m|January|❄️
febrero|m|February|💝
marzo|m|March|🌱
abril|m|April|🌧️
mayo|m|May|🌷
junio|m|June|☀️
julio|m|July|🏖️
agosto|m|August|🍉
septiembre|m|September|🍂
octubre|m|October|🎃
noviembre|m|November|🍁
diciembre|m|December|🎄
#1 My family & pets
familia|f|family|👪
madre|f|mother|👩
padre|m|father|👨
hermano|m|brother|👦
hermana|f|sister|👧
abuelo|m|grandfather|👴
abuela|f|grandmother|👵
bebé|m|baby|👶
perro|m|dog|🐶
gato|m|cat|🐱
pez|m|fish (pet)|🐟
pájaro|m|bird|🐦
caballo|m|horse|🐴
conejo|m|rabbit|🐰
ratón|m|mouse|🐭
serpiente|f|snake|🐍
tortuga|f|tortoise|🐢
cobaya|f|guinea pig|🐹
#1 Colours
rojo|a|red|🔴
azul|a|blue|🔵
verde|a|green|🟢
amarillo|a|yellow|🟡
negro|a|black|⚫
blanco|a|white|⚪
naranja|a|orange|🟠
rosa|a|pink|🌸
morado|a|purple|🟣
marrón|a|brown|🟤
gris|a|grey|🩶
#1 In the classroom
libro|m|book|📖
cuaderno|m|exercise book|📓
bolígrafo|m|pen|🖊️
lápiz|m|pencil|✏️
goma|f|rubber|🧽
regla|f|ruler|📏
mochila|f|school bag|🎒
estuche|m|pencil case|✏️
mesa|f|table|🪑
silla|f|chair|🪑
puerta|f|door|🚪
ventana|f|window|🪟
pizarra|f|board|🧑‍🏫
profesor|m|teacher (male)|🧑‍🏫
profesora|f|teacher (female)|👩‍🏫
#1 Food I like
manzana|f|apple|🍎
plátano|m|banana|🍌
naranja|f|orange (fruit)|🍊
fresa|f|strawberry|🍓
pan|m|bread|🍞
agua|f|water|💧
leche|f|milk|🥛
zumo|m|juice|🧃
queso|m|cheese|🧀
huevo|m|egg|🥚
pizza|f|pizza|🍕
hamburguesa|f|burger|🍔
helado|m|ice cream|🍦
chocolate|m|chocolate|🍫
#1 First verbs
ser|v|to be|✨
tener|v|to have|🤲
llamarse|v|to be called|🏷️
vivir|v|to live|🏠
hablar|v|to speak|🗣️
estudiar|v|to study|📚
jugar|v|to play|🎮
comer|v|to eat|🍽️
beber|v|to drink|🥤
gustar|v|to like (me gusta)|❤️
#1 Describing
grande|a|big|🐘
pequeño|a|small|🐭
alto|a|tall|🦒
bajo|a|short|🐕
simpático|a|nice, friendly|😊
divertido|a|fun, funny|😂
aburrido|a|boring|🥱
inteligente|a|clever|🧠
guapo|a|good-looking|😎
feo|a|ugly|👹
#2 Me, family & friends
familia|f|family
padre|m|father
madre|f|mother
padres|m|parents
hermano|m|brother
hermana|f|sister
hijo|m|son
hija|f|daughter
abuelo|m|grandfather
abuela|f|grandmother
tío|m|uncle
tía|f|aunt
primo|m|cousin (male)
prima|f|cousin (female)
amigo|m|friend (male)
amiga|f|friend (female)
novio|m|boyfriend
novia|f|girlfriend
bebé|m|baby
gente|f|people
persona|f|person
chico|m|boy
chica|f|girl
hombre|m|man
mujer|f|woman, wife
nombre|m|name
edad|f|age
cumpleaños|m|birthday
mascota|f|pet
perro|m|dog
gato|m|cat
pez|m|fish (alive)
pájaro|m|bird
caballo|m|horse
conejo|m|rabbit
llamarse|v|to be called
tener|v|to have|ie
ser|v|to be (permanent)
estar|v|to be (state, location)
vivir|v|to live
llevarse bien|v|to get on well
#2 Describing people
alto|a|tall
bajo|a|short
delgado|a|slim
gordo|a|fat
guapo|a|good-looking
feo|a|ugly
joven|a|young
viejo|a|old
simpático|a|nice, friendly
antipático|a|unfriendly
divertido|a|fun, funny
aburrido|a|boring, bored
inteligente|a|intelligent
tonto|a|silly
trabajador|a|hard-working
perezoso|a|lazy
tímido|a|shy
hablador|a|chatty
amable|a|kind
generoso|a|generous
egoísta|a|selfish
serio|a|serious
gracioso|a|funny
feliz|a|happy
triste|a|sad
contento|a|happy, pleased
cansado|a|tired
enfadado|a|angry
nervioso|a|nervous
pelo|m|hair
ojos|m|eyes
rubio|a|blond
moreno|a|dark-haired, tanned
pelirrojo|a|red-haired
largo|a|long
corto|a|short (length)
rizado|a|curly
liso|a|straight (hair)
gafas|f|glasses
barba|f|beard
#2 Colours
color|m|colour
rojo|a|red
azul|a|blue
verde|a|green
amarillo|a|yellow
negro|a|black
blanco|a|white
gris|a|grey
marrón|a|brown
naranja|a|orange
rosa|a|pink
morado|a|purple
#2 School
instituto|m|secondary school
colegio|m|school
clase|f|class, lesson
aula|f|classroom
profesor|m|teacher (male)
profesora|f|teacher (female)
alumno|m|pupil
asignatura|f|school subject
matemáticas|f|maths
inglés|m|English (subject)
ciencias|f|science
historia|f|history, story
geografía|f|geography
dibujo|m|art
música|f|music
educación física|f|PE
informática|f|IT, computing
idiomas|m|languages
deberes|m|homework
examen|m|exam
nota|f|mark, grade, note
uniforme|m|uniform
recreo|m|break time
horario|m|timetable
libro|m|book
cuaderno|m|exercise book
bolígrafo|m|pen
lápiz|m|pencil
mochila|f|school bag
regla|f|ruler, rule
pizarra|f|board
estudiar|v|to study
aprender|v|to learn
aprobar|v|to pass (an exam)|ue
suspender|v|to fail (an exam)
enseñar|v|to teach, show
escribir|v|to write
leer|v|to read
entender|v|to understand|ie
repetir|v|to repeat|i
fácil|a|easy
difícil|a|difficult
útil|a|useful
estricto|a|strict
#2 Home
casa|f|house, home
piso|m|flat, floor
habitación|f|room, bedroom
dormitorio|m|bedroom
cocina|f|kitchen
salón|m|living room
comedor|m|dining room
cuarto de baño|m|bathroom
jardín|m|garden
baño|m|bathroom, bath
cama|f|bed
mesa|f|table
silla|f|chair
sofá|m|sofa
armario|m|wardrobe, cupboard
ventana|f|window
puerta|f|door
pared|f|wall
escalera|f|stairs
llave|f|key
nevera|f|fridge
ordenador|m|computer
televisión|f|television
lámpara|f|lamp
barrio|m|neighbourhood
afueras|f|outskirts
ayudar|v|to help
limpiar|v|to clean
cocinar|v|to cook
lavar|v|to wash
ordenar|v|to tidy
fregar|v|to wash up|ie
poner la mesa|v|to lay the table
#2 Daily routine
despertarse|v|to wake up|ie
levantarse|v|to get up
ducharse|v|to have a shower
vestirse|v|to get dressed|i
lavarse los dientes|v|to brush your teeth
desayunar|v|to have breakfast
almorzar|v|to have lunch|ue
comer|v|to eat, have lunch
cenar|v|to have dinner
acostarse|v|to go to bed|ue
dormir|v|to sleep|ue
salir|v|to go out, leave
volver|v|to return|ue
llegar|v|to arrive
ir|v|to go
venir|v|to come|ie
empezar|v|to start|ie
terminar|v|to finish
mañana|f|morning; (adv) tomorrow
tarde|f|afternoon, evening; (adv) late
noche|f|night
día|m|day
semana|f|week
mes|m|month
año|m|year
hora|f|hour, time
fin de semana|m|weekend
siempre|adv|always
nunca|adv|never
a veces|adv|sometimes
normalmente|adv|usually
temprano|adv|early
pronto|adv|soon
luego|adv|then, later
después|adv|afterwards
antes|adv|before
hoy|adv|today
ayer|adv|yesterday
ahora|adv|now
todavía|adv|still, yet
ya|adv|already
#2 Food & drink
comida|f|food, lunch
desayuno|m|breakfast
cena|f|dinner
pan|m|bread
agua|f|water
leche|f|milk
zumo|m|juice
café|m|coffee
té|m|tea
refresco|m|fizzy drink
carne|f|meat
pollo|m|chicken
pescado|m|fish (food)
jamón|m|ham
queso|m|cheese
huevo|m|egg
arroz|m|rice
pasta|f|pasta
patatas fritas|f|chips, crisps
verduras|f|vegetables
ensalada|f|salad
tomate|m|tomato
fruta|f|fruit
manzana|f|apple
naranja|f|orange (fruit)
plátano|m|banana
fresa|f|strawberry
uvas|f|grapes
pastel|m|cake
helado|m|ice cream
chocolate|m|chocolate
bocadillo|m|sandwich (baguette)
tortilla|f|Spanish omelette
paella|f|paella
sal|f|salt
azúcar|m|sugar
aceite|m|oil
restaurante|m|restaurant
camarero|m|waiter
cuenta|f|bill
menú|m|menu
plato|m|plate, dish
vaso|m|glass
beber|v|to drink
tomar|v|to take, have (food/drink)
pedir|v|to order, ask for|i
probar|v|to try, taste|ue
preferir|v|to prefer|ie
rico|a|tasty, rich
sano|a|healthy
#2 Free time
tiempo libre|m|free time
deporte|m|sport
fútbol|m|football
baloncesto|m|basketball
tenis|m|tennis
natación|f|swimming
equipo|m|team
partido|m|match
película|f|film
cine|m|cinema
serie|f|series
videojuego|m|video game
música|f|music
canción|f|song
concierto|m|concert
grupo|m|band, group
libro|m|book
revista|f|magazine
red social|f|social network
móvil|m|mobile phone
foto|f|photo
jugar|v|to play (sport, game)|ue
tocar|v|to play (instrument), touch
ver|v|to see, watch
escuchar|v|to listen
bailar|v|to dance
cantar|v|to sing
nadar|v|to swim
correr|v|to run
montar en bici|v|to ride a bike
ir de compras|v|to go shopping
quedar|v|to meet up
gustar|v|to like (me gusta)
encantar|v|to love (me encanta)
odiar|v|to hate
preferir|v|to prefer|ie
#2 Town
ciudad|f|city, town
pueblo|m|village, town
calle|f|street
plaza|f|square
tienda|f|shop
mercado|m|market
supermercado|m|supermarket
centro comercial|m|shopping centre
iglesia|f|church
museo|m|museum
parque|m|park
playa|f|beach
polideportivo|m|sports centre
piscina|f|swimming pool
biblioteca|f|library
estación|f|station, season
banco|m|bank, bench
hospital|m|hospital
farmacia|f|chemist's
correos|m|post office
ayuntamiento|m|town hall
coche|m|car
autobús|m|bus
tren|m|train
avión|m|plane
barco|m|boat
bicicleta|f|bicycle
metro|m|underground
a pie|adv|on foot
cerca|adv|near
lejos|adv|far
aquí|adv|here
allí|adv|there
a la derecha|adv|on the right
a la izquierda|adv|on the left
todo recto|adv|straight on
#2 Holidays & weather
vacaciones|f|holidays
viaje|m|trip, journey
hotel|m|hotel
camping|m|campsite
maleta|f|suitcase
billete|m|ticket
país|m|country
extranjero|m|abroad, foreigner
mar|m|sea
montaña|f|mountain
campo|m|countryside, field
sol|m|sun
tiempo|m|weather, time
calor|m|heat
frío|m|cold
lluvia|f|rain
nieve|f|snow
viento|m|wind
nube|f|cloud
verano|m|summer
invierno|m|winter
primavera|f|spring
otoño|m|autumn
viajar|v|to travel
visitar|v|to visit
alojarse|v|to stay (hotel)
descansar|v|to rest
tomar el sol|v|to sunbathe
llover|v|to rain|ue
nevar|v|to snow|ie
hace calor|x|it's hot
hace frío|x|it's cold
hace sol|x|it's sunny
está nublado|x|it's cloudy
#3 Clothes & shopping
ropa|f|clothes
camiseta|f|T-shirt
camisa|f|shirt
pantalones|m|trousers
vaqueros|m|jeans
falda|f|skirt
vestido|m|dress
zapatos|m|shoes
zapatillas|f|trainers
abrigo|m|coat
chaqueta|f|jacket
jersey|m|jumper
gorra|f|cap
talla|f|size
precio|m|price
dinero|m|money
euro|m|euro
barato|a|cheap
caro|a|expensive
de moda|a|fashionable
comprar|v|to buy
costar|v|to cost|ue
llevar|v|to wear, carry
probarse|v|to try on|ue
gastar|v|to spend
#3 Health & body
cuerpo|m|body
cabeza|f|head
cara|f|face
boca|f|mouth
diente|m|tooth
nariz|f|nose
oreja|f|ear
brazo|m|arm
mano|f|hand
pierna|f|leg
pie|m|foot
espalda|f|back
estómago|m|stomach
corazón|m|heart
médico|m|doctor
enfermo|a|ill
dolor|m|pain
salud|f|health
dieta|f|diet
ejercicio|m|exercise
doler|v|to hurt (me duele)|ue
sentirse|v|to feel|ie
fumar|v|to smoke
evitar|v|to avoid
dormir bien|v|to sleep well|ue
#3 Technology & media
internet|m|internet
aplicación|f|app
mensaje|m|message
pantalla|f|screen
contraseña|f|password
página web|f|website
vídeo|m|video
seguidor|m|follower
publicar|v|to post
mandar|v|to send
descargar|v|to download
compartir|v|to share
chatear|v|to chat online
navegar|v|to browse, sail
peligroso|a|dangerous
adicto|a|addicted
#3 Jobs & future
trabajo|m|job, work
empresa|f|company
oficina|f|office
sueldo|m|salary
jefe|m|boss
médico|m|doctor
enfermero|m|nurse
abogado|m|lawyer
ingeniero|m|engineer
periodista|m|journalist
cocinero|m|cook, chef
policía|m|police officer
futuro|m|future
universidad|f|university
carrera|f|degree, career, race
sueño|m|dream, sleepiness
trabajar|v|to work
ganar|v|to earn, win
buscar|v|to look for
encontrar|v|to find|ue
querer|v|to want, love|ie
poder|v|to be able to, can|ue
deber|v|must, to owe
esperar|v|to hope, wait
#3 Environment & society
medio ambiente|m|environment
planeta|m|planet
contaminación|f|pollution
basura|f|rubbish
reciclaje|m|recycling
energía|f|energy
cambio climático|m|climate change
problema|m|problem
pobreza|f|poverty
paro|m|unemployment
ayuda|f|help
reciclar|v|to recycle
proteger|v|to protect
ahorrar|v|to save
apagar|v|to switch off
malgastar|v|to waste
#3 Useful little words
muy|adv|very
mucho|adv|a lot
poco|adv|a little
bastante|adv|quite, enough
demasiado|adv|too, too much
también|adv|also
tampoco|adv|neither
sólo|adv|only
casi|adv|almost
bien|adv|well
mal|adv|badly
más|adv|more
menos|adv|less
y|conj|and
o|conj|or
pero|conj|but
porque|conj|because
cuando|conj|when
si|conj|if
aunque|conj|although
entonces|conj|so, then
sin embargo|conj|however
además|adv|furthermore, besides
con|prep|with
sin|prep|without
para|prep|for, in order to
por|prep|for, by, through
desde|prep|from, since
hasta|prep|until
entre|prep|between
sobre|prep|on, about
#4 Higher-level verbs & expressions
acabar de|v|to have just (done)
volver a|v|to (do) again|ue
soler|v|to usually (do)|ue
tener que|v|to have to|ie
ir a|v|to be going to
dejar de|v|to stop (doing)
conseguir|v|to manage, get|i
darse cuenta|v|to realise
quejarse|v|to complain
sentir|v|to feel, be sorry|ie
pensar|v|to think|ie
creer|v|to believe
parecer|v|to seem
olvidar|v|to forget
recordar|v|to remember|ue
decidir|v|to decide
elegir|v|to choose|i
mejorar|v|to improve
cambiar|v|to change
conocer|v|to know (people, places)
saber|v|to know (facts, how to)
decir|v|to say, tell|i
hacer|v|to do, make
poner|v|to put
traer|v|to bring
dar|v|to give
seguir|v|to follow, carry on|i
merecer la pena|x|to be worth it
tener éxito|x|to be successful
echar de menos|x|to miss (someone)
estar harto de|x|to be fed up with
lo mejor|x|the best thing
lo peor|x|the worst thing
`;
