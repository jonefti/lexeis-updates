/* French first words for a young learner (8–11). Format: lemma|type|meaning|emoji  ·  types: m f v a adv x */
window.LANG_DICT_RAW = `
#1 Animals
chat|m|cat|🐱
chien|m|dog|🐶
lapin|m|rabbit|🐰
oiseau|m|bird|🐦
poisson|m|fish|🐟
cheval|m|horse|🐴
vache|f|cow|🐮
cochon|m|pig|🐷
mouton|m|sheep|🐑
poule|f|hen|🐔
canard|m|duck|🦆
souris|f|mouse|🐭
lion|m|lion|🦁
tigre|m|tiger|🐯
éléphant|m|elephant|🐘
singe|m|monkey|🐵
girafe|f|giraffe|🦒
ours|m|bear|🐻
serpent|m|snake|🐍
tortue|f|tortoise, turtle|🐢
grenouille|f|frog|🐸
papillon|m|butterfly|🦋
abeille|f|bee|🐝
araignée|f|spider|🕷️
dauphin|m|dolphin|🐬
requin|m|shark|🦈
hibou|m|owl|🦉
renard|m|fox|🦊
#1 Family & people
famille|f|family|👪
mère|f|mother|👩
père|m|father|👨
maman|f|mum|👩
papa|m|dad|👨
frère|m|brother|👦
sœur|f|sister|👧
bébé|m|baby|👶
grand-mère|f|grandma|👵
grand-père|m|grandpa|👴
oncle|m|uncle|🧔
tante|f|aunt|👩
cousin|m|cousin (boy)|🧒
cousine|f|cousin (girl)|🧒
ami|m|friend (boy)|🧑‍🤝‍🧑
amie|f|friend (girl)|🧑‍🤝‍🧑
garçon|m|boy|👦
fille|f|girl, daughter|👧
enfant|m|child|🧒
homme|m|man|👨
femme|f|woman, wife|👩
professeur|m|teacher|🧑‍🏫
maîtresse|f|teacher (primary, woman)|👩‍🏫
#1 Colours
rouge|a|red|🔴
bleu|a|blue|🔵
vert|a|green|🟢
jaune|a|yellow|🟡
orange|a|orange|🟠
violet|a|purple|🟣
rose|a|pink|🌸
noir|a|black|⚫
blanc|a|white|⚪
marron|a|brown|🟤
gris|a|grey|🩶
#1 Numbers
un|x|one|1️⃣
deux|x|two|2️⃣
trois|x|three|3️⃣
quatre|x|four|4️⃣
cinq|x|five|5️⃣
six|x|six|6️⃣
sept|x|seven|7️⃣
huit|x|eight|8️⃣
neuf|x|nine|9️⃣
dix|x|ten|🔟
onze|x|eleven|
douze|x|twelve|
vingt|x|twenty|
cent|x|a hundred|💯
#1 Food
pomme|f|apple|🍎
banane|f|banana|🍌
orange|f|orange (fruit)|🍊
fraise|f|strawberry|🍓
raisin|m|grapes|🍇
poire|f|pear|🍐
cerise|f|cherry|🍒
citron|m|lemon|🍋
carotte|f|carrot|🥕
tomate|f|tomato|🍅
pomme de terre|f|potato|🥔
salade|f|salad, lettuce|🥗
pain|m|bread|🍞
croissant|m|croissant|🥐
fromage|m|cheese|🧀
beurre|m|butter|🧈
œuf|m|egg|🥚
lait|m|milk|🥛
eau|f|water|💧
jus|m|juice|🧃
gâteau|m|cake|🎂
glace|f|ice cream|🍦
chocolat|m|chocolate|🍫
bonbon|m|sweet|🍬
pizza|f|pizza|🍕
frites|f|chips|🍟
poulet|m|chicken|🍗
poisson|m|fish|🐟
soupe|f|soup|🍲
petit-déjeuner|m|breakfast|🥣
déjeuner|m|lunch|🍽️
dîner|m|dinner|🍽️
#1 Clothes
pantalon|m|trousers|👖
jupe|f|skirt|👗
robe|f|dress|👗
tee-shirt|m|T-shirt|👕
pull|m|jumper|🧥
manteau|m|coat|🧥
chaussure|f|shoe|👟
chaussette|f|sock|🧦
chapeau|m|hat|🎩
casquette|f|cap|🧢
écharpe|f|scarf|🧣
lunettes|f|glasses|👓
#1 Body
tête|f|head|🙂
cheveux|m|hair|💇
œil|m|eye|👁️
nez|m|nose|👃
bouche|f|mouth|👄
oreille|f|ear|👂
dent|f|tooth|🦷
main|f|hand|✋
bras|m|arm|💪
jambe|f|leg|🦵
pied|m|foot|🦶
ventre|m|tummy|🫃
dos|m|back|🔙
#1 Home & things
maison|f|house|🏠
chambre|f|bedroom|🛏️
cuisine|f|kitchen|🍳
salon|m|living room|🛋️
salle de bain|f|bathroom|🛁
jardin|m|garden|🌳
lit|m|bed|🛏️
table|f|table|🪑
chaise|f|chair|🪑
porte|f|door|🚪
fenêtre|f|window|🪟
télé|f|TV|📺
ordinateur|m|computer|💻
téléphone|m|phone|📱
livre|m|book|📖
jouet|m|toy|🧸
ballon|m|ball|⚽
vélo|m|bike|🚲
voiture|f|car|🚗
bus|m|bus|🚌
train|m|train|🚆
avion|m|plane|✈️
bateau|m|boat|⛵
#1 School
école|f|school|🏫
classe|f|class|🧑‍🎓
crayon|m|pencil|✏️
stylo|m|pen|🖊️
gomme|f|rubber|🧽
règle|f|ruler|📏
cahier|m|exercise book|📓
cartable|m|school bag|🎒
ciseaux|m|scissors|✂️
colle|f|glue|🧴
récré|f|break time|🤸
#1 Nature & weather
soleil|m|sun|☀️
lune|f|moon|🌙
étoile|f|star|⭐
nuage|m|cloud|☁️
pluie|f|rain|🌧️
neige|f|snow|❄️
vent|m|wind|💨
arbre|m|tree|🌳
fleur|f|flower|🌸
mer|f|sea|🌊
plage|f|beach|🏖️
montagne|f|mountain|⛰️
forêt|f|forest|🌲
été|m|summer|🌞
hiver|m|winter|⛄
printemps|m|spring|🌷
automne|m|autumn|🍂
#1 Action words
être|v|to be|✨
avoir|v|to have|🤲
aller|v|to go|🚶
faire|v|to do, to make|🛠️
manger|v|to eat|🍽️
boire|v|to drink|🥤
dormir|v|to sleep|😴
jouer|v|to play|🎲
parler|v|to speak|🗣️
aimer|v|to like, to love|❤️
adorer|v|to love, adore|😍
détester|v|to hate|😖
regarder|v|to watch, look at|👀
écouter|v|to listen|🎧
chanter|v|to sing|🎤
danser|v|to dance|💃
nager|v|to swim|🏊
courir|v|to run|🏃
sauter|v|to jump|🦘
lire|v|to read|📚
écrire|v|to write|✍️
dessiner|v|to draw|🖍️
habiter|v|to live|🏠
venir|v|to come|👋
voir|v|to see|👁️
prendre|v|to take|✋
vouloir|v|to want|🙏
pouvoir|v|can, to be able|💪
finir|v|to finish|🏁
ouvrir|v|to open|📭
fermer|v|to close|📪
#1 Describing words
grand|a|big, tall|🦒
petit|a|small|🐭
gentil|a|kind|😊
méchant|a|mean, naughty|😠
content|a|happy|😃
triste|a|sad|😢
fatigué|a|tired|🥱
beau|a|beautiful, handsome|🌟
joli|a|pretty|🌼
nouveau|a|new|🆕
vieux|a|old|👴
chaud|a|hot|🔥
froid|a|cold|🧊
drôle|a|funny|😂
facile|a|easy|👍
difficile|a|difficult|🤯
bon|a|good|👌
super|a|great|🤩
#1 Little words
oui|x|yes|✅
non|x|no|❌
merci|x|thank you|🙏
s'il te plaît|x|please (to a friend)|🙏
bonjour|x|hello, good morning|👋
au revoir|x|goodbye|👋
salut|x|hi, bye|✋
bonne nuit|x|good night|🌙
et|x|and|➕
avec|x|with|🤝
aujourd'hui|adv|today|📅
demain|adv|tomorrow|➡️
hier|adv|yesterday|⬅️
très|adv|very|‼️
beaucoup|adv|a lot|🔝
maintenant|adv|now|⏰
#2 A bit harder
anniversaire|m|birthday|🎉
cadeau|m|present|🎁
fête|f|party|🥳
vacances|f|holidays|🏝️
week-end|m|weekend|📆
matin|m|morning|🌅
soir|m|evening|🌆
semaine|f|week|🗓️
jour|m|day|☀️
heure|f|hour, o'clock|🕒
ville|f|town, city|🏙️
parc|m|park|🌳
magasin|m|shop|🏪
piscine|f|swimming pool|🏊
cinéma|m|cinema|🎬
musique|f|music|🎵
chanson|f|song|🎶
film|m|film|🎞️
jeu|m|game|🎮
sport|m|sport|🏅
foot|m|football|⚽
dessin animé|m|cartoon|📺
sortir|v|to go out|🚪
partir|v|to leave|🧳
acheter|v|to buy|🛒
aider|v|to help|🤝
chercher|v|to look for|🔍
trouver|v|to find|💡
apprendre|v|to learn|🧠
comprendre|v|to understand|💭
se lever|v|to get up|⏰
se laver|v|to wash (yourself)|🧼
s'appeler|v|to be called|🏷️
`;
