/* French learning content for a young beginner: phrases, mini lessons with quizzes, tiny stories, daily tips */
window.LANG_PHRASES_RAW = `
# Hello!
Bonjour !|Hello!
Salut ! Ça va ?|Hi! How are you?
Ça va bien, merci.|I'm fine, thanks.
Comment tu t'appelles ?|What's your name?
Je m'appelle Lily.|My name is Lily.
Tu as quel âge ?|How old are you?
J'ai neuf ans.|I'm nine.
Où habites-tu ?|Where do you live?
J'habite en Angleterre.|I live in England.
Au revoir ! À demain !|Goodbye! See you tomorrow!
# About me
J'ai un frère et une sœur.|I have a brother and a sister.
J'ai un chat qui s'appelle Minou.|I have a cat called Minou.
Mon anniversaire, c'est le dix mai.|My birthday is the tenth of May.
Ma couleur préférée, c'est le bleu.|My favourite colour is blue.
J'ai les cheveux bruns et les yeux verts.|I have brown hair and green eyes.
Je suis grande et sportive.|I'm tall and sporty.
# Likes
J'aime les chats.|I like cats.
J'adore le chocolat !|I love chocolate!
Je n'aime pas les carottes.|I don't like carrots.
Je déteste la pluie.|I hate the rain.
J'aime jouer au foot.|I like playing football.
J'aime danser et chanter.|I like dancing and singing.
# At school
Je ne comprends pas.|I don't understand.
Tu peux répéter, s'il te plaît ?|Can you repeat, please?
Comment dit-on "dog" en français ?|How do you say "dog" in French?
J'ai fini !|I've finished!
Je peux aller aux toilettes ?|Can I go to the toilet?
Ouvrez vos cahiers.|Open your exercise books.
# Food
J'ai faim !|I'm hungry!
J'ai soif.|I'm thirsty.
Je voudrais un croissant, s'il vous plaît.|I'd like a croissant, please.
C'est délicieux !|It's delicious!
Encore un peu, s'il te plaît.|A little more, please.
# Feelings
Je suis content. / Je suis contente.|I'm happy.
Je suis fatigué. / Je suis fatiguée.|I'm tired.
J'ai peur !|I'm scared!
C'est super !|It's great!
Bravo !|Well done!
Oh là là !|Oh dear! / Wow!
# Weather
Quel temps fait-il ?|What's the weather like?
Il fait beau.|It's nice weather.
Il fait chaud.|It's hot.
Il fait froid.|It's cold.
Il pleut.|It's raining.
Il neige !|It's snowing!
# Playing
On joue ?|Shall we play?
C'est à toi !|It's your turn!
C'est à moi !|It's my turn!
J'ai gagné !|I won!
Viens ici !|Come here!
On va au parc ?|Shall we go to the park?
`;

window.LANG_GRAMMAR = [
{ id: 'lela', title: 'le, la, l\', les', level: 1, summary: 'Every word is a boy word or a girl word.',
  body: `In French, every naming word (noun) is masculine or feminine.
> le chat, le livre | masculine (boy words)
> la pomme, la maison | feminine (girl words)
> l'école, l'arbre | before a, e, i, o, u
> les chats, les pommes | more than one
! Learn the little word with the noun: say "la pomme", not just "pomme".`,
  quiz: [
    { q: '___ chat 🐱', o: ['le', 'la'], a: 0, ex: 'chat is masculine: le chat.' },
    { q: '___ pomme 🍎', o: ['le', 'la'], a: 1, ex: 'pomme is feminine: la pomme.' },
    { q: '___ école 🏫', o: ['la', "l'"], a: 1, ex: 'Before a vowel: l\'école.' },
    { q: '___ chiens 🐶🐶', o: ['le', 'les'], a: 1, ex: 'More than one: les.' }
  ] },
{ id: 'unune', title: 'un, une, des', level: 1, summary: 'a, an, some.',
  body: `> un chien | a dog (masculine)
> une fleur | a flower (feminine)
> des bonbons | some sweets (more than one)
! J'ai un frère. J'ai une sœur.`,
  quiz: [
    { q: "J'ai ___ chien.", o: ['un', 'une'], a: 0, ex: 'le chien → un chien.' },
    { q: "J'ai ___ sœur.", o: ['un', 'une'], a: 1, ex: 'la sœur → une sœur.' },
    { q: 'Je mange ___ bonbons.', o: ['un', 'des'], a: 1, ex: 'More than one: des.' }
  ] },
{ id: 'plural', title: 'More than one', level: 1, summary: 'Usually add -s (you can\'t hear it!).',
  body: `- Most words add -s: un chat → des chats.
- Words ending in -eau add -x: un gâteau → des gâteaux, un oiseau → des oiseaux.
- -al often becomes -aux: un cheval → des chevaux.
! The -s is silent: chat and chats sound the same. Listen to le or les instead.`,
  quiz: [
    { q: 'des ___ (gâteau)', o: ['gâteaus', 'gâteaux'], a: 1, ex: '-eau → -eaux.' },
    { q: 'des ___ (cheval)', o: ['chevals', 'chevaux'], a: 1, ex: '-al → -aux.' },
    { q: 'des ___ (pomme)', o: ['pommes', 'pommex'], a: 0, ex: 'Just add -s.' }
  ] },
{ id: 'etreavoir', title: 'être (to be) and avoir (to have)', level: 1, summary: 'The two most important verbs.',
  body: `> je suis, tu es, il/elle est, nous sommes, vous êtes, ils/elles sont | être = to be
> j'ai, tu as, il/elle a, nous avons, vous avez, ils/elles ont | avoir = to have
! French uses avoir for age: J'ai neuf ans = I am nine (I have nine years).
! Also: J'ai faim (I'm hungry), J'ai peur (I'm scared).`,
  quiz: [
    { q: 'Je ___ content.', o: ['suis', 'ai'], a: 0, ex: 'être: je suis.' },
    { q: "J'___ dix ans.", o: ['suis', 'ai'], a: 1, ex: 'Age uses avoir: j\'ai dix ans.' },
    { q: 'Nous ___ un chien.', o: ['avons', 'sommes'], a: 0, ex: 'avoir: nous avons.' },
    { q: 'Elle ___ gentille.', o: ['a', 'est'], a: 1, ex: 'être: elle est.' }
  ] },
{ id: 'er', title: '-er verbs: jouer, parler, aimer', level: 1, summary: 'The biggest family of verbs.',
  body: `Take off -er and add the endings:
> je joue, tu joues, il/elle joue, nous jouons, vous jouez, ils/elles jouent | jouer
- je, tu, il and ils forms all sound the same!
- je becomes j' before a vowel: j'aime, j'habite.`,
  quiz: [
    { q: 'Je ___ au foot. (jouer)', o: ['joue', 'jouons', 'jouez'], a: 0, ex: 'je joue.' },
    { q: 'Nous ___ français. (parler)', o: ['parle', 'parlons', 'parlez'], a: 1, ex: 'nous → -ons.' },
    { q: '___ aime les chats.', o: ['Je', "J'"], a: 1, ex: 'Before a vowel: j\'aime.' }
  ] },
{ id: 'negative', title: 'Saying "not": ne … pas', level: 1, summary: 'Wrap the verb in ne … pas.',
  body: `Put ne before the verb and pas after it.
> Je joue. → Je ne joue pas. | I don't play.
> J'aime. → Je n'aime pas. | I don't like.
! ne becomes n' before a vowel.`,
  quiz: [
    { q: 'I don\'t like carrots.', o: ['Je n\'aime pas les carottes.', 'Je pas aime les carottes.', 'Je ne aime les carottes pas.'], a: 0, ex: 'n\'… pas around the verb.' },
    { q: 'Il ___ mange ___ de viande.', o: ['ne … pas', 'pas … ne'], a: 0, ex: 'ne before, pas after.' }
  ] },
{ id: 'adjectives', title: 'Describing words', level: 1, summary: 'Girl words often add -e.',
  body: `- Describing words change to match: un petit chat, une petite souris.
- Add -s for more than one: des petits chats.
- Most colours come after the noun: un chat noir, une voiture rouge.
- A few come before: petit, grand, beau, joli, bon, nouveau, vieux.
! Words already ending in -e don't change: un garçon triste, une fille triste.`,
  quiz: [
    { q: 'une robe ___ (vert)', o: ['vert', 'verte'], a: 1, ex: 'robe is feminine: verte.' },
    { q: 'un chat ___ (noir)', o: ['noir', 'noire'], a: 0, ex: 'chat is masculine: noir.' },
    { q: 'a big house', o: ['une grande maison', 'une maison grand', 'un grand maison'], a: 0, ex: 'grand goes before; maison is feminine.' }
  ] },
{ id: 'questions', title: 'Asking questions', level: 2, summary: 'Make your voice go up, or use a question word.',
  body: `- Easiest: say it with a rising voice. Tu aimes le chocolat ?
- Add est-ce que: Est-ce que tu aimes le chocolat ?
- Question words: qui (who), quoi / qu'est-ce que (what), où (where), quand (when), comment (how), pourquoi (why), combien (how many).
! In French you put a space before ? and !`,
  quiz: [
    { q: 'Where do you live?', o: ['Où habites-tu ?', 'Qui habites-tu ?', 'Quand habites-tu ?'], a: 0, ex: 'où = where.' },
    { q: 'Why?', o: ['Comment ?', 'Pourquoi ?', 'Combien ?'], a: 1, ex: 'pourquoi = why.' }
  ] },
{ id: 'aller', title: 'aller (to go) and the near future', level: 2, summary: 'je vais + verb = I\'m going to…',
  body: `> je vais, tu vas, il/elle va, nous allons, vous allez, ils/elles vont | aller
- Je vais au parc. = I go / I'm going to the park.
- Je vais jouer. = I'm going to play.
! au parc (to the park), à la plage (to the beach), à l'école (to school).`,
  quiz: [
    { q: 'Nous ___ à la plage.', o: ['allons', 'allez', 'vont'], a: 0, ex: 'nous allons.' },
    { q: 'I\'m going to eat.', o: ['Je vais manger.', 'Je va manger.', 'Je vais mange.'], a: 0, ex: 'je vais + verb ending in -er.' }
  ] }
];

window.LANG_READINGS = [
{ id: 'minou', title: 'Minou le chat', en: 'Minou the cat', level: 'A1', text: `Voici Minou. Minou est un petit chat noir. Il a les yeux verts. Minou habite avec Léa dans une grande maison. Il aime dormir sur le lit de Léa. Il adore le poisson, mais il n'aime pas l'eau ! Le matin, Minou joue dans le jardin avec un ballon rouge.`,
  q: [{ q: 'Minou est de quelle couleur ?', o: ['blanc', 'noir', 'gris'], a: 1 }, { q: 'Où dort Minou ?', o: ['sur le lit de Léa', 'dans le jardin', 'dans la cuisine'], a: 0 }, { q: "Qu'est-ce que Minou n'aime pas ?", o: ['le poisson', "l'eau", 'le ballon'], a: 1 }] },
{ id: 'anniversaire', title: "L'anniversaire de Tom", en: "Tom's birthday", level: 'A1', text: `Aujourd'hui, c'est l'anniversaire de Tom. Il a dix ans ! Ses amis viennent à la maison. Maman fait un gros gâteau au chocolat. Tom a beaucoup de cadeaux : un livre, un jeu et un vélo bleu. Tout le monde chante "Joyeux anniversaire" ! Tom est très content.`,
  q: [{ q: 'Tom a quel âge ?', o: ['neuf ans', 'dix ans', 'onze ans'], a: 1 }, { q: 'Le gâteau est au…', o: ['chocolat', 'citron', 'fraise'], a: 0 }, { q: 'Le vélo est de quelle couleur ?', o: ['rouge', 'vert', 'bleu'], a: 2 }] },
{ id: 'plage', title: 'À la plage', en: 'At the beach', level: 'A1', text: `C'est l'été. Il fait beau et il fait chaud. Lucie va à la plage avec son papa. Elle nage dans la mer et elle fait un château de sable. Son papa lit un livre sous le parasol. À midi, ils mangent des sandwichs et une glace à la fraise. Miam !`,
  q: [{ q: 'Quel temps fait-il ?', o: ['Il pleut.', 'Il fait beau.', 'Il neige.'], a: 1 }, { q: 'Que fait le papa ?', o: ['Il nage.', 'Il lit un livre.', 'Il dort.'], a: 1 }, { q: 'La glace est à la…', o: ['vanille', 'fraise', 'banane'], a: 1 }] },
{ id: 'ecole', title: "Mon école", en: 'My school', level: 'A1', text: `Je m'appelle Hugo. Mon école est petite mais très jolie. Ma maîtresse s'appelle Madame Martin. Elle est gentille et drôle. Dans ma classe, il y a vingt enfants. J'aime le dessin et le sport. Je n'aime pas beaucoup les maths. À la récré, je joue au foot avec mes copains.`,
  q: [{ q: 'Comment est la maîtresse ?', o: ['méchante', 'gentille et drôle', 'triste'], a: 1 }, { q: "Il y a combien d'enfants ?", o: ['dix', 'vingt', 'trente'], a: 1 }, { q: 'À la récré, Hugo…', o: ['lit', 'joue au foot', 'dessine'], a: 1 }] },
{ id: 'neige', title: 'Il neige !', en: "It's snowing!", level: 'A1', text: `Ce matin, Emma regarde par la fenêtre. Oh ! Tout est blanc ! Il neige ! Emma met son manteau, son écharpe et son chapeau. Elle sort dans le jardin avec son frère. Ils font un bonhomme de neige. Il a une carotte pour le nez ! Après, ils boivent un chocolat chaud. C'est le meilleur jour de l'hiver !`,
  q: [{ q: 'Quel temps fait-il ?', o: ['Il fait chaud.', 'Il neige.', 'Il pleut.'], a: 1 }, { q: 'Le nez du bonhomme est…', o: ['une carotte', 'une pomme', 'un bonbon'], a: 0 }, { q: 'Après, ils boivent…', o: ['du lait froid', 'un chocolat chaud', 'du jus'], a: 1 }] },
{ id: 'zoo', title: 'Au zoo', en: 'At the zoo', level: 'A2', text: `Samedi, la classe de Chloé va au zoo. D'abord, ils voient les lions. Ils sont grands et un peu méchants ! Ensuite, ils regardent les singes. Les singes sont très drôles : ils sautent et ils mangent des bananes. Chloé préfère les girafes parce qu'elles sont grandes et belles. À la fin, tout le monde est fatigué mais content.`,
  q: [{ q: 'Quand vont-ils au zoo ?', o: ['lundi', 'samedi', 'dimanche'], a: 1 }, { q: 'Que mangent les singes ?', o: ['des pommes', 'des bananes', 'du pain'], a: 1 }, { q: 'Chloé préfère…', o: ['les lions', 'les singes', 'les girafes'], a: 2 }] }
];

window.LANG_TIPS = [
  'Learn the little word with the noun: la pomme, le chat.',
  'J\'ai neuf ans: French uses "have" for age!',
  'je → j\' before a vowel: j\'aime, j\'habite.',
  'The -s on plurals is silent. Listen for les instead of le or la.',
  'Colours go after the noun: un chat noir.',
  'Girl words often add -e: petit → petite.',
  'Ne … pas wraps around the verb: je ne joue pas.',
  'J\'ai faim = I\'m hungry. J\'ai soif = I\'m thirsty.',
  'Put a space before ? and ! in French.',
  'Bonjour for grown-ups, salut for friends.',
  'S\'il te plaît to a friend, s\'il vous plaît to a grown-up.',
  'Je vais + verb = I\'m going to…: je vais jouer.',
  'Words ending in -eau add -x: des gâteaux.',
  'Il fait beau = it\'s nice weather.',
  'Tu for one friend, vous for a grown-up or lots of people.'
];
