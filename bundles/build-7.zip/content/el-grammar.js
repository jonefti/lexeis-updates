/* Greek grammar guide. body uses a tiny markup: lines starting "- " are bullets, "> " examples (Greek | English), "! " tips. */
window.LANG_GRAMMAR = [
{ id: 'articles', title: 'Articles and the four cases', level: 1,
  summary: 'ο / η / το change with case and number.',
  body: `Greek has four cases. The article shows the case even when the noun ending is unclear.
- Nominative: the subject. Ο φίλος μου ήρθε.
- Genitive: possession, "of". Το σπίτι του φίλου μου.
- Accusative: object, and after most prepositions. Είδα τον φίλο μου.
- Vocative: calling someone. Φίλε μου!
> ο, του, τον, οι, των, τους | masculine
> η, της, την, οι, των, τις | feminine
> το, του, το, τα, των, τα | neuter
! τον/την keep their final -ν before vowels and κ, π, τ, μπ, ντ, γκ, τσ, τζ, ξ, ψ. Otherwise it's often dropped: τη μέρα, το φίλο (colloquial).
! Indefinite: ένας (m), μία/μια (f), ένα (n). Accusative: έναν, μία, ένα.`,
  quiz: [
    { q: 'Είδα ___ γιατρό χθες. (ο γιατρός)', o: ['ο', 'τον', 'του', 'το'], a: 1, ex: 'Object of είδα → accusative: τον γιατρό.' },
    { q: 'Το αυτοκίνητο ___ αδερφής μου.', o: ['η', 'την', 'της', 'τη'], a: 2, ex: 'Possession → genitive feminine: της αδερφής.' },
    { q: 'Μίλησα με ___ παιδιά.', o: ['τα', 'των', 'τους', 'οι'], a: 0, ex: 'με + accusative; neuter plural accusative is τα.' },
    { q: 'Genitive plural of every article is…', o: ['τους', 'των', 'τις', 'τα'], a: 1, ex: 'των is the genitive plural for all three genders.' },
    { q: 'Μίλησα με ___ Γιώργο.', o: ['ο', 'τον', 'του', 'το'], a: 1, ex: 'με + accusative masculine: τον Γιώργο.' }
  ] },
{ id: 'gender', title: 'Guessing gender from the ending', level: 1,
  summary: 'Most endings tell you the gender. Learn the exceptions.',
  body: `The nominative singular ending usually gives the gender away.
- Masculine: -ος, -ας, -ης, -ές, -ούς. ο δρόμος, ο πατέρας, ο μαθητής, ο καφές, ο παππούς.
- Feminine: -α, -η, -ος (a few), -ού. η ώρα, η νίκη, η οδός, η αλεπού.
- Neuter: -ο, -ι, -μα, -ος, -ον, -ιμο. το βουνό, το παιδί, το όνομα, το δάσος, το περιβάλλον, το τρέξιμο.
! -ος is the trap: mostly masculine, but some are feminine (η οδός, η μέθοδος, η είσοδος, η έξοδος, η περίοδος, η διάλεκτος) and some neuter (το δάσος, το λάθος, το μέρος, το κράτος, το έθνος).
! Feminine -ος words are often learned words of ancient origin, especially compounds of -οδος (road).
! Professions in -ος can be both: ο/η γιατρός, ο/η δικηγόρος.
! All diminutives in -άκι are neuter: το σπιτάκι, το κοριτσάκι.`,
  quiz: [
    { q: 'Which article? ___ μέθοδος', o: ['ο', 'η', 'το'], a: 1, ex: 'η μέθοδος: feminine -οδος word.' },
    { q: 'Which article? ___ μέρος', o: ['ο', 'η', 'το'], a: 2, ex: 'το μέρος: neuter -ος, plural τα μέρη.' },
    { q: 'Which article? ___ σύστημα', o: ['ο', 'η', 'το'], a: 2, ex: '-μα nouns are neuter.' },
    { q: 'Which article? ___ έξοδος', o: ['ο', 'η', 'το'], a: 1, ex: 'η έξοδος (exit): feminine.' },
    { q: 'Which article? ___ καναπές', o: ['ο', 'η', 'το'], a: 0, ex: '-ές nouns are masculine: οι καναπέδες.' },
    { q: 'Which article? ___ σκυλάκι', o: ['ο', 'η', 'το'], a: 2, ex: 'Diminutives in -άκι are always neuter.' }
  ] },
{ id: 'plurals', title: 'Plurals, genitive and stress shifts', level: 2,
  summary: 'Where the accent moves in the genitive and plural.',
  body: `Greek stress can never fall further back than the third syllable from the end. When an ending adds a syllable, the stress may move forward.
- ο άνθρωπος → του ανθρώπου, των ανθρώπων, τους ανθρώπους (stress moves when the ending is long: -ου, -ων, -ους).
- το πρόσωπο → του προσώπου, τα πρόσωπα, των προσώπων.
- το όνομα → του ονόματος, τα ονόματα, των ονομάτων.
- Feminine -α/-η: genitive plural is usually stressed on the end: η θάλασσα → των θαλασσών, η ώρα → των ωρών.
- Neuter -ι: παιδί → παιδιού, παιδιά, παιδιών · σπίτι → σπιτιού, σπίτια, σπιτιών.
- Neuter -ος: το δάσος → του δάσους, τα δάση, των δασών.
- Feminine -η with plural -εις: η λέξη → οι λέξεις, των λέξεων.
! -άδες/-έδες plurals: ο ψαράς → οι ψαράδες, ο καφές → οι καφέδες, η γιαγιά → οι γιαγιάδες.`,
  quiz: [
    { q: 'Genitive singular of ο άνθρωπος', o: ['του άνθρωπου', 'του ανθρώπου', 'του ανθρωπού'], a: 1, ex: 'Long ending -ου pulls the stress to the penult.' },
    { q: 'Plural of το πρόβλημα', o: ['τα προβλήματα', 'τα πρόβληματα', 'τα προβλημάτα'], a: 0, ex: '-μα nouns: -ματα with stress on the antepenult.' },
    { q: 'Plural of η απόφαση', o: ['οι αποφάσες', 'οι αποφάσεις', 'οι απόφασεις'], a: 1, ex: '-ση nouns take -εις: αποφάσεις.' },
    { q: 'Genitive plural of η θάλασσα', o: ['των θάλασσων', 'των θαλάσσων', 'των θαλασσών'], a: 2, ex: 'Feminine -α: genitive plural usually -ών.' },
    { q: 'Plural of το λάθος', o: ['τα λάθοι', 'τα λάθη', 'τα λάθα'], a: 1, ex: 'Neuter -ος → -η: τα λάθη.' }
  ] },
{ id: 'adjectives', title: 'Adjective agreement', level: 1,
  summary: 'Adjectives match the noun in gender, number and case.',
  body: `Most adjectives follow -ος, -η, -ο. If the stem ends in a vowel (or -ι), the feminine is -α.
> καλός, καλή, καλό | good
> ωραίος, ωραία, ωραίο | nice
> πλούσιος, πλούσια, πλούσιο | rich
- Agreement: ένας καλός φίλος, μια καλή φίλη, ένα καλό παιδί, των καλών φίλων.
- -ύς, -ιά, -ύ: βαθύς, βαθιά, βαθύ (deep); μακρύς, μακριά, μακρύ.
- -ής, -ής, -ές: ειλικρινής, ειλικρινής, ειλικρινές; plural ειλικρινείς.
- Invariable colours: μπλε, γκρι, ροζ, καφέ, μωβ never change.
! πολύς (much) is irregular: πολύς, πολλή, πολύ; plural πολλοί, πολλές, πολλά. Πολύ as an adverb means "very".`,
  quiz: [
    { q: 'Η θάλασσα είναι πολύ ___ σήμερα. (ήσυχος)', o: ['ήσυχος', 'ήσυχη', 'ήσυχο', 'ήσυχα'], a: 1, ex: 'Feminine singular: ήσυχη.' },
    { q: 'Έχω ___ δουλειά. (πολύς)', o: ['πολύ', 'πολλή', 'πολλά', 'πολύς'], a: 1, ex: 'δουλειά is feminine: πολλή δουλειά.' },
    { q: 'Τα ___ παπούτσια μου. (καινούργιος)', o: ['καινούργια', 'καινούργιες', 'καινούργιοι', 'καινούργιο'], a: 0, ex: 'Neuter plural: καινούργια.' },
    { q: 'Μια ___ φούστα. (μπλε)', o: ['μπλέ', 'μπλε', 'μπλη', 'μπλα'], a: 1, ex: 'μπλε is invariable.' },
    { q: 'Ένας ___ άνθρωπος. (ειλικρινής)', o: ['ειλικρινής', 'ειλικρινές', 'ειλικρινός', 'ειλικρινείς'], a: 0, ex: 'Masculine singular nominative: ειλικρινής.' }
  ] },
{ id: 'clitics', title: 'Weak pronouns: με, σε, τον, μου, σου…', level: 2,
  summary: 'Short object pronouns and where they go.',
  body: `Weak pronouns go before the verb, and after it with imperatives and gerunds.
> με, σε, τον/την/το, μας, σας, τους/τις/τα | direct object (me, you, him…)
> μου, σου, του/της/του, μας, σας, τους | indirect object (to me, to you…)
- Before the verb: Σε βλέπω. Μου το έδωσε. Δεν τον ξέρω. Θα σου πω.
- After imperatives: Δώσ' μου το! Πες μου. Φέρ' το.
- After gerunds: Βλέποντάς τον, κατάλαβα.
- Order: indirect before direct: μου το, σου τα, του τη(ν).
! With two pronouns after an imperative: Δώσε μου το / Δώσ' το μου (both heard).
! The same μου, σου mark possession after nouns: το σπίτι μου. The stress then may double: το αυτοκίνητό μου.`,
  quiz: [
    { q: 'I saw her yesterday: ___ είδα χθες.', o: ['Της', 'Την', 'Τη', 'Τις'], a: 1, ex: 'Direct object, feminine: την είδα (την before a vowel).' },
    { q: 'He gave it to me: ___ έδωσε.', o: ['Το μου', 'Μου το', 'Με το', 'Μου τον'], a: 1, ex: 'Indirect before direct: μου το.' },
    { q: 'Tell me!', o: ['Μου πες!', 'Πες μου!', 'Με πες!', 'Πες με!'], a: 1, ex: 'Imperative: pronoun follows. Πες μου.' },
    { q: 'I will call you: Θα ___ πάρω τηλέφωνο.', o: ['σου', 'σε', 'σας', 'σένα'], a: 1, ex: 'παίρνω κάποιον τηλέφωνο takes a direct object: σε.' },
    { q: 'I don\'t like it: Δεν ___ αρέσει.', o: ['με', 'μου', 'εμένα', 'μένα'], a: 1, ex: 'αρέσει takes the genitive: μου αρέσει.' }
  ] },
{ id: 'groups', title: 'Verb groups A, B1 and B2', level: 1,
  summary: 'How the present tense is formed in each group.',
  body: `Look at the ending and the stress of the 1st person.
- Group A, stressed before -ω: γράφω, γράφεις, γράφει, γράφουμε, γράφετε, γράφουν(ε).
- Group B1, -άω (or -ώ): αγαπάω, αγαπάς, αγαπάει, αγαπάμε (αγαπούμε), αγαπάτε, αγαπάνε (αγαπούν).
- Group B2, -ώ with -είς: μπορώ, μπορείς, μπορεί, μπορούμε, μπορείτε, μπορούν(ε).
- Vowel stems (A): λέω, λες, λέει, λέμε, λέτε, λένε · ακούω, ακούς… · τρώω, τρως…
! B1 verbs can be written -άω or -ώ. If you can say -άω, it's B1: μιλάω, ρωτάω, περνάω.
! B2 verbs are often more formal: θεωρώ, οδηγώ, προσπαθώ, συζητώ (also συζητάω).
! Aorist of most B verbs: -ησα (αγάπησα, μπόρεσα is irregular). Some B1 take -ασα: γέλασα, πέρασα, ξέχασα.`,
  quiz: [
    { q: 'Εσείς ___ (μπορώ)', o: ['μποράτε', 'μπορείτε', 'μπορετε', 'μπορούτε'], a: 1, ex: 'B2: -είτε.' },
    { q: 'Αυτοί ___ ελληνικά. (μιλάω)', o: ['μιλάνε', 'μιλούνε', 'μιλείνε', 'μίλουν'], a: 0, ex: 'B1: μιλάνε (or μιλούν).' },
    { q: 'Εσύ τι ___; (λέω)', o: ['λέεις', 'λες', 'λέις', 'λέσαι'], a: 1, ex: 'Vowel stem: λες.' },
    { q: 'Aorist of ξεχνάω', o: ['ξέχνησα', 'ξέχασα', 'ξεχάνησα', 'ξέχνασα'], a: 1, ex: 'Irregular B1: ξέχασα.' },
    { q: 'Εμείς ___ πολύ. (γελάω)', o: ['γελούμε / γελάμε', 'γελάουμε', 'γελέμε', 'γέλουμε'], a: 0, ex: 'B1 1st plural: γελάμε or γελούμε.' }
  ] },
{ id: 'aspect', title: 'Aspect: imperfect vs aorist', level: 2,
  summary: 'Ongoing or repeated vs one completed action.',
  body: `Greek verbs have two stems: continuous (present stem) and simple (aorist stem). The choice is about how you see the action, not just time.
- Imperfect (continuous past): ongoing, repeated or background. Διάβαζα όταν χτύπησε το τηλέφωνο. Κάθε καλοκαίρι πηγαίναμε στη Νάξο.
- Aorist (simple past): one completed event. Διάβασα το βιβλίο σε δύο μέρες. Πήγαμε στη Νάξο πέρσι.
- The same split exists in the future and after να: θα γράφω (regularly) vs θα γράψω (once); θέλω να διαβάζω κάθε μέρα vs θέλω να διαβάσω αυτό το βιβλίο.
! Past stress rule: in past tenses the stress goes on the third syllable from the end. If there are only two syllables, add έ-: γράφω → έγραφα, έγραψα; but γράψαμε.
! Signal words: κάθε μέρα, συνήθως, πάντα → imperfect. Χθες, ξαφνικά, μια φορά → often aorist.`,
  quiz: [
    { q: 'Όταν ήμουν παιδί, ___ ποδόσφαιρο κάθε μέρα.', o: ['έπαιξα', 'έπαιζα'], a: 1, ex: 'Repeated habit in the past → imperfect.' },
    { q: 'Χθες ___ ένα υπέροχο βιβλίο.', o: ['τελείωνα', 'τελείωσα'], a: 1, ex: 'One completed action → aorist.' },
    { q: 'Ενώ ___, χτύπησε η πόρτα.', o: ['μαγείρεψα', 'μαγείρευα'], a: 1, ex: 'Background, ongoing → imperfect.' },
    { q: 'Θέλω να ___ αυτό το βιβλίο μέχρι την Κυριακή.', o: ['διαβάζω', 'διαβάσω'], a: 1, ex: 'One complete reading → aorist subjunctive.' },
    { q: 'Past of γράφω (we, once)', o: ['εγράψαμε', 'γράψαμε', 'έγραψαμε'], a: 1, ex: 'Three syllables already: no augment. γράψαμε.' }
  ] },
{ id: 'future', title: 'Future and subjunctive: θα and να', level: 2,
  summary: 'θα + verb for the future; να + verb for "to…", wishes and more.',
  body: `θα and να are followed by the same verb forms.
- Simple (one action): θα γράψω, να γράψω (aorist stem + present endings).
- Continuous (ongoing/repeated): θα γράφω, να γράφω (present stem).
- να replaces the English infinitive: Θέλω να φύγω. Μπορώ να έρθω; Πρέπει να πληρώσουμε.
- να for suggestions and wishes: Να πάμε σινεμά; Να είσαι καλά!
- Negative: θα + δεν → δεν θα: Δεν θα έρθω. να + μη(ν): Να μην αργήσεις.
! Irregular simple stems you need: δω (βλέπω), πω (λέω), φάω (τρώω), πιω (πίνω), πάω (πηγαίνω), έρθω (έρχομαι), βγω, μπω, βρω, πάρω, φέρω, δώσω, βάλω, μάθω.
! θα + imperfect = would have / probably: Θα ήταν ωραίο. Θα κοιμόταν. (He was probably sleeping.)`,
  quiz: [
    { q: 'Αύριο θα ___ τη γιαγιά μου. (βλέπω, once)', o: ['βλέπω', 'δω', 'είδω', 'βλέψω'], a: 1, ex: 'Irregular simple stem: θα δω.' },
    { q: 'Πρέπει να ___ στο σούπερ μάρκετ. (πηγαίνω)', o: ['πάω', 'πηγαίνω', 'πάγω', 'πήγω'], a: 0, ex: 'Simple form: να πάω.' },
    { q: 'I won\'t come.', o: ['Θα δεν έρθω.', 'Δεν θα έρθω.', 'Θα μην έρθω.', 'Μην θα έρθω.'], a: 1, ex: 'δεν comes before θα.' },
    { q: 'Don\'t be late!', o: ['Δεν να αργήσεις!', 'Να μην αργήσεις!', 'Να δεν αργήσεις!', 'Μη να αργήσεις!'], a: 1, ex: 'να + μην.' },
    { q: 'Θέλω να ___ κάτι. (λέω, once)', o: ['λέω', 'πω', 'πω σου', 'είπω'], a: 1, ex: 'να πω.' }
  ] },
{ id: 'perfect', title: 'Perfect tenses: έχω + -ει', level: 2,
  summary: 'έχω/είχα/θα έχω + the invariable -ει form.',
  body: `The perfect uses έχω plus a fixed form built from the simple stem + -ει.
> έχω γράψει | I have written
> είχα γράψει | I had written
> θα έχω γράψει | I will have written
- The -ει form never changes: έχουμε φάει, είχαν δει, θα έχει τελειώσει.
- Passive verbs use -εί: έχω σκεφτεί, έχει γίνει, είχαμε κουραστεί.
- Irregular: δει, πει, φάει, πιει, πάει, έρθει, βγει, μπει, βρει, πάρει.
! Greek uses the perfect less than English. "Have you eaten?" is usually Έφαγες; (aorist). Use the perfect for experience or emphasis: Έχεις πάει ποτέ στην Κρήτη;`,
  quiz: [
    { q: 'Have you ever been to Crete?', o: ['Έχεις πάει ποτέ στην Κρήτη;', 'Έχεις πήγει ποτέ στην Κρήτη;', 'Είχες πάεις ποτέ στην Κρήτη;'], a: 0, ex: 'έχω πάει.' },
    { q: 'Δεν έχω ___ ακόμα. (τρώω)', o: ['φάγει', 'φάει', 'τρώει', 'φάω'], a: 1, ex: 'Irregular: έχω φάει.' },
    { q: 'Είχαμε ___ πριν έρθεις. (φεύγω)', o: ['φύγει', 'φεύγει', 'φύγουμε', 'έφυγε'], a: 0, ex: 'είχαμε φύγει.' },
    { q: 'Τι έχει ___; (γίνομαι)', o: ['γίνει', 'γίνεται', 'γίνι', 'γένει'], a: 0, ex: 'Τι έχει γίνει; What has happened?' }
  ] },
{ id: 'imperative', title: 'The imperative', level: 2,
  summary: 'Commands, singular and plural, simple and continuous.',
  body: `Simple (one action) uses the aorist stem; continuous uses the present stem.
> γράψε / γράψτε | write (once)
> γράφε / γράφετε | keep writing
> διάβασε / διαβάστε | read
> μίλησε / μιλήστε | speak
- Common irregulars: έλα/ελάτε, πες/πείτε, δες/δείτε, φάε/φάτε, πιες/πιείτε, βγες/βγείτε, μπες/μπείτε, βρες/βρείτε, πάρε/πάρτε, φέρε/φέρτε, άσε/αφήστε, κάτσε/καθίστε.
- Negative commands don't use the imperative: μη(ν) + subjunctive. Μη γράψεις! Μην αργείτε!
- Passive verbs: σήκω/σηκωθείτε, κάθισε, ντύσου/ντυθείτε, θυμήσου/θυμηθείτε.`,
  quiz: [
    { q: 'Come here! (to one friend)', o: ['Έλα εδώ!', 'Έρθε εδώ!', 'Ελάτε εδώ!', 'Έρχου εδώ!'], a: 0, ex: 'Irregular: έλα.' },
    { q: 'Don\'t forget! (to one person)', o: ['Μην ξέχασε!', 'Μην ξεχάσεις!', 'Δεν ξεχάσεις!', 'Μη ξέχνα!'], a: 1, ex: 'Negative: μην + subjunctive.' },
    { q: 'Tell us! (polite/plural)', o: ['Πες μας!', 'Πείτε μας!', 'Λέτε μας!', 'Πέστε μας!'], a: 1, ex: 'Plural/polite: πείτε. (πέστε is also heard colloquially)' },
    { q: 'Sit down! (to one person, colloquial)', o: ['Κάτσε!', 'Κάθεσαι!', 'Καθίστε!', 'Κάθου!'], a: 0, ex: 'κάτσε (or κάθισε).' }
  ] },
{ id: 'passive', title: 'Passive and -μαι verbs', level: 3,
  summary: 'Verbs ending in -μαι: true passives and deponents.',
  body: `Verbs in -ομαι, -άμαι, -ιέμαι, -ούμαι have their own endings. Many have active meanings (έρχομαι, σκέφτομαι, κοιμάμαι).
> έρχομαι, έρχεσαι, έρχεται, ερχόμαστε, έρχεστε, έρχονται | present
> ερχόμουν, ερχόσουν, ερχόταν, ερχόμασταν, ερχόσασταν, έρχονταν | imperfect
> σκέφτηκα, σκέφτηκες, σκέφτηκε, σκεφτήκαμε, σκεφτήκατε, σκέφτηκαν | aorist
- Aorist usually in -θηκα / -τηκα / -στηκα: γράφτηκα, αγαπήθηκα, χρειάστηκα, κοιμήθηκα.
- Future: θα σκεφτώ, θα κοιμηθώ (stressed on the end).
- Active ↔ passive: πλένω (I wash) → πλένομαι (I wash myself / am washed).
! Irregular aorists: ήρθα (έρχομαι), έγινα (γίνομαι), κάθισα (κάθομαι), χάρηκα (χαίρομαι).`,
  quiz: [
    { q: 'Εμείς ___ αύριο. (έρχομαι)', o: ['ερχόμαστε', 'έρχομαστε', 'ερχόμεθα', 'έρχουμε'], a: 0, ex: '1st plural: ερχόμαστε.' },
    { q: 'Aorist of κοιμάμαι (I slept)', o: ['κοιμήθηκα', 'κοίμησα', 'κοιμάθηκα', 'κοιμόμουν'], a: 0, ex: 'κοιμήθηκα.' },
    { q: 'Δεν ___ τίποτα. (θυμάμαι, present, I)', o: ['θυμάμαι', 'θυμούμαι', 'θυμήθηκα', 'θυμάσαι'], a: 0, ex: 'Δεν θυμάμαι τίποτα.' },
    { q: 'Τι ___; (γίνομαι, what happened)', o: ['γίνηκε', 'έγινε', 'γένηκε', 'γίνεται'], a: 1, ex: 'Irregular aorist: έγινε.' }
  ] },
{ id: 'prepositions', title: 'Prepositions and σε + article', level: 1,
  summary: 'Most prepositions take the accusative. σε merges with the article.',
  body: `σε, από, με, για, χωρίς, μέχρι, προς all take the accusative.
- σε + article merges: σε + τον = στον, σε + την = στην, σε + το = στο, στους, στις, στα.
- Πάω στην παραλία. Μένω στο κέντρο. Είναι στον τρίτο όροφο.
- από: from, by, since. Είμαι από την Αγγλία. Από χθες.
- Adverb + σε or από: δίπλα στο, κοντά στο, μέσα στο, πάνω στο / πάνω από, μακριά από, πριν από, μετά από.
! Fixed genitive phrases: κατά τη διάρκεια (during), εκ μέρους (on behalf of), αντί για / αντί του.`,
  quiz: [
    { q: 'Πάμε ___ θάλασσα;', o: ['στη', 'σε η', 'στον', 'στο'], a: 0, ex: 'σε + τη(ν) = στη(ν).' },
    { q: 'Το κλειδί είναι ___ τραπέζι.', o: ['πάνω στο', 'πάνω του', 'πάνω στον', 'πάνω το'], a: 0, ex: 'πάνω στο τραπέζι (on the table).' },
    { q: 'Ήρθα ___ το Λονδίνο.', o: ['σε', 'από', 'για', 'με'], a: 1, ex: 'από = from.' },
    { q: 'Μένει κοντά ___ σταθμό.', o: ['από τον', 'στον', 'του', 'με τον'], a: 1, ex: 'κοντά σε: κοντά στον σταθμό.' }
  ] },
{ id: 'negation', title: 'Negation: δεν, μη(ν), ούτε, κανείς', level: 2,
  summary: 'δεν for statements, μη(ν) with να and commands.',
  body: `- δεν: indicative statements and θα. Δεν ξέρω. Δεν θα πάω.
- μη(ν): after να, in negative commands and wishes, and "don't" alone. Να μην έρθεις. Μην ανησυχείς! Μη!
- Double negatives are normal: Δεν είδα κανέναν. Δεν θέλω τίποτα. Δεν πάω πουθενά. Δεν έρχεται ποτέ.
- ούτε… ούτε: neither… nor. Δεν τρώει ούτε κρέας ούτε ψάρι.
- μήπως: in case / maybe (often with fear or polite questions). Μήπως ξέρεις πού είναι;
! δεν keeps -ν always in modern spelling; μη(ν) drops -ν by the same rule as την.`,
  quiz: [
    { q: 'I didn\'t see anyone.', o: ['Είδα κανέναν.', 'Δεν είδα κανέναν.', 'Μην είδα κανέναν.'], a: 1, ex: 'Double negative: δεν… κανέναν.' },
    { q: 'Don\'t worry!', o: ['Δεν ανησυχείς!', 'Μην ανησυχείς!', 'Να δεν ανησυχείς!'], a: 1, ex: 'μην + present for an ongoing state.' },
    { q: 'Do you happen to know…?', o: ['Μήπως ξέρεις…;', 'Μη ξέρεις…;', 'Δεν ξέρεις μήπως…'], a: 0, ex: 'μήπως for polite questions.' },
    { q: 'Ο Νίκος δεν θέλει ___ καφέ ___ τσάι.', o: ['ούτε… ούτε', 'ή… ή', 'μήτε… και'], a: 0, ex: 'ούτε… ούτε = neither… nor.' }
  ] },
{ id: 'questions', title: 'Questions: ποιος, τι, πού, πότε…', level: 1,
  summary: 'Question words and the declining ποιος.',
  body: `Questions keep statement word order. In writing, the question mark is ; (semicolon).
- τι (what), ποιος/ποια/ποιο (who, which), πού (where), πότε (when), πώς (how), γιατί (why), πόσο (how much), πόσοι/πόσες/πόσα (how many).
- ποιος declines: ποιος, ποιου/ποιανού, ποιον · ποια, ποιας/ποιανής, ποια · ποιο… Ποιον είδες; Ποιανού είναι αυτό;
! πού (where) and πώς (how) have an accent; που (that, who) and πως (that) don't.`,
  quiz: [
    { q: 'Who did you see?', o: ['Ποιος είδες;', 'Ποιον είδες;', 'Ποιου είδες;'], a: 1, ex: 'Object → accusative: ποιον.' },
    { q: 'Whose is this?', o: ['Ποιος είναι αυτό;', 'Ποιανού είναι αυτό;', 'Πού είναι αυτό;'], a: 1, ex: 'Genitive: ποιανού.' },
    { q: 'How many people?', o: ['Πόσα άτομα;', 'Πόσοι άτομα;', 'Πόσο άτομα;'], a: 0, ex: 'άτομο is neuter: πόσα άτομα.' },
    { q: 'Where are you going?', o: ['Που πας;', 'Πού πας;', 'Πως πας;'], a: 1, ex: 'πού with accent = where.' }
  ] },
{ id: 'relative', title: 'που, ότι, πως and ο οποίος', level: 3,
  summary: 'Linking clauses: relative and "that".',
  body: `- που (no accent): who, which, that. It never changes. Ο φίλος που σου είπα. Η πόλη που γεννήθηκα.
- ο οποίος / η οποία / το οποίο: formal "who/which", declines and is used after prepositions. Η εταιρεία για την οποία δουλεύω.
- ότι / πως: "that" after verbs of saying and thinking. Νομίζω ότι έχεις δίκιο. Μου είπε πως θα αργήσει.
- που after feelings: Χαίρομαι που ήρθες. Λυπάμαι που δεν μπόρεσα.
- όποιος / ό,τι / όπου / όποτε: whoever, whatever, wherever, whenever. Ό,τι θέλεις.
! ό,τι (whatever) has a comma to distinguish it from ότι (that).`,
  quiz: [
    { q: 'Η κοπέλα ___ γνώρισα χθες.', o: ['που', 'πού', 'ότι', 'πως'], a: 0, ex: 'Relative "that/who": που.' },
    { q: 'Χαίρομαι ___ ήρθες!', o: ['ότι', 'που', 'πού', 'να'], a: 1, ex: 'After feelings: χαίρομαι που.' },
    { q: 'Πάρε ___ θέλεις.', o: ['ότι', 'ό,τι', 'που', 'τι'], a: 1, ex: 'Whatever = ό,τι.' },
    { q: 'Το σπίτι στο ___ μένω.', o: ['που', 'οποίο', 'όποιο', 'ποιο'], a: 1, ex: 'After a preposition: στο οποίο.' }
  ] },
{ id: 'comparison', title: 'Comparatives and superlatives', level: 2,
  summary: 'πιο + adjective, or -τερος; ο πιο / -τατος.',
  body: `- Comparative: πιο + adjective, or the -τερος form. πιο μεγάλος = μεγαλύτερος. πιο ωραίος = ωραιότερος.
- "than": από + accusative, or παρά. Είναι πιο ψηλός από μένα. Καλύτερα αργά παρά ποτέ.
- Superlative: ο πιο / ο -τερος. Ο πιο ωραίος, ο καλύτερος.
- Absolute (-τατος): πάρα πολύ. ελάχιστος, μέγιστος, άριστος, ωραιότατος.
! Irregular: καλός → καλύτερος, κακός → χειρότερος, μεγάλος → μεγαλύτερος, λίγος → λιγότερος, πολύς → περισσότερος, απλός → απλούστερος.`,
  quiz: [
    { q: 'better', o: ['πιο καλότερος', 'καλύτερος', 'καλότερος'], a: 1, ex: 'Irregular: καλύτερος.' },
    { q: 'Η Αθήνα είναι μεγαλύτερη ___ τη Θεσσαλονίκη.', o: ['από', 'παρά', 'σε', 'του'], a: 0, ex: 'από + accusative.' },
    { q: 'worse', o: ['κακότερος', 'χειρότερος', 'πιο χειρότερος'], a: 1, ex: 'Irregular: χειρότερος. Never πιο χειρότερος.' },
    { q: 'the most beautiful island', o: ['το πιο όμορφο νησί', 'το πιο ομορφότερο νησί', 'το όμορφο πιο νησί'], a: 0, ex: 'το πιο όμορφο.' }
  ] },
{ id: 'numbers', title: 'Numbers that decline', level: 2,
  summary: '1, 3, 4 and the hundreds change with gender.',
  body: `- 1: ένας (m), μία/μια (f), ένα (n). Accusative: έναν, μία, ένα.
- 3: τρεις (m/f), τρία (n). Genitive τριών.
- 4: τέσσερις (m/f), τέσσερα (n).
- 13, 14, 23, 24… follow: δεκατρία παιδιά, δεκατρείς γυναίκες.
- Hundreds 200–900 decline: διακόσιοι άντρες, διακόσιες γυναίκες, διακόσια ευρώ.
- Χίλιοι/χίλιες/χίλια (1000); 2000 = δύο χιλιάδες.
! Time: στη μία, στις τρεις, στις τέσσερις (ώρα is feminine).`,
  quiz: [
    { q: 'three children', o: ['τρεις παιδιά', 'τρία παιδιά', 'τρίας παιδιά'], a: 1, ex: 'Neuter: τρία.' },
    { q: 'At four o\'clock', o: ['στις τέσσερα', 'στις τέσσερις', 'στο τέσσερα'], a: 1, ex: 'ώρα is feminine: τέσσερις.' },
    { q: '300 euro', o: ['τριακόσιοι ευρώ', 'τριακόσια ευρώ', 'τριακόσιες ευρώ'], a: 1, ex: 'ευρώ is neuter: τριακόσια.' },
    { q: 'I bought one bag (η τσάντα): Αγόρασα ___ τσάντα.', o: ['έναν', 'μία', 'ένα', 'ένας'], a: 1, ex: 'Feminine: μία/μια.' }
  ] },
{ id: 'arese', title: 'μου αρέσει and impersonal verbs', level: 1,
  summary: 'The thing liked is the subject; the person is in the genitive.',
  body: `αρέσω means "I please". The thing you like is the subject; you are the indirect object.
> Μου αρέσει η μουσική. | I like the music.
> Μου αρέσουν τα σύκα. | I like figs (plural verb).
> Σου άρεσε η ταινία; | Did you like the film?
> Του αρέσει να διαβάζει. | He likes reading.
- Same pattern: μου λείπει (I miss), μου φαίνεται (it seems to me), με πονάει (it hurts me, accusative!), μου χρειάζεται, μου κάνει (it fits me).
- Impersonal: πρέπει να, χρειάζεται να, αξίζει να, φαίνεται ότι, πρόκειται να.
! Μου λείπεις = I miss you (you are missing to me).`,
  quiz: [
    { q: 'I like the olives: Μου ___ οι ελιές.', o: ['αρέσει', 'αρέσουν', 'αρέσω', 'αρέσεις'], a: 1, ex: 'Plural subject οι ελιές → αρέσουν.' },
    { q: 'I miss you.', o: ['Σου λείπω.', 'Μου λείπεις.', 'Σε λείπω.'], a: 1, ex: 'You are missing to me: μου λείπεις.' },
    { q: 'My head hurts: ___ πονάει το κεφάλι.', o: ['Μου', 'Με', 'Εμένα'], a: 1, ex: 'πονάω takes accusative: με πονάει.' },
    { q: 'Did she like it? ___ άρεσε;', o: ['Της', 'Την', 'Τη'], a: 0, ex: 'Genitive: της άρεσε.' }
  ] },
{ id: 'wordorder', title: 'Word order and emphasis', level: 3,
  summary: 'Flexible order; what comes first is emphasised.',
  body: `Greek word order is flexible because cases mark who does what. The neutral order is subject–verb–object, but you can front what you want to stress.
- Neutral: Ο Νίκος έφερε το κρασί.
- Object first, doubled by a pronoun: Το κρασί το έφερε ο Νίκος. (As for the wine, Nikos brought it.)
- Subject after the verb for new information: Ήρθε ο Νίκος.
- Subject pronouns are dropped unless stressed: Πάω σπίτι. Εγώ πάω σπίτι (I'm going home, not you).
! Clitic doubling is very common in speech: Τον ξέρω τον Γιάννη. Το είδες το μήνυμα;`,
  quiz: [
    { q: 'Which is natural Greek for "Did you see the message?"', o: ['Το είδες το μήνυμα;', 'Είδες εσύ το μήνυμα το;', 'Εσύ το μήνυμα είδες;'], a: 0, ex: 'Clitic doubling: Το είδες το μήνυμα;' },
    { q: 'Why would you say "Εγώ πληρώνω"?', o: ['It\'s required', 'To stress that it\'s me paying', 'It\'s formal'], a: 1, ex: 'The pronoun is only added for emphasis or contrast.' },
    { q: '"Nikos arrived" (new information)', o: ['Ήρθε ο Νίκος.', 'Ο Νίκος ήρθε ο.', 'Τον Νίκο ήρθε.'], a: 0, ex: 'Verb first, subject after, presents the subject as new information.' }
  ] }
];

/* "Remember today" tips: rotate daily */
window.LANG_TIPS = [
  'ποτέ means both "never" (with δεν) and "ever" in questions: Έχεις πάει ποτέ;',
  'Feminine -ος: η οδός, η μέθοδος, η είσοδος, η έξοδος, η περίοδος, η διάλεκτος.',
  'Neuter -ος: το λάθος, το μέρος, το δάσος, το κράτος, το έθνος, το βάρος. Plural -η.',
  'In past tenses stress goes three syllables back: έγραψα but γράψαμε.',
  'μου αρέσουν (plural) when you like more than one thing: μου αρέσουν τα σύκα.',
  'με πονάει, not μου πονάει: pain takes the accusative.',
  'After χαίρομαι and λυπάμαι use που, not ότι: Χαίρομαι που ήρθες.',
  'να + μη(ν), θα + δεν: Να μην αργήσεις. Δεν θα έρθω.',
  'Imperatives put pronouns after: Πες μου. Δώσ\' το μου.',
  'πού (where) has an accent; που (that) doesn\'t. Same with πώς/πως.',
  'καλύτερος and χειρότερος are already comparatives: never πιο καλύτερος.',
  'τρία παιδιά, τρεις γυναίκες: 3 and 4 change with gender.',
  'Diminutives in -άκι are always neuter: το σπιτάκι, το παιδάκι.',
  'Ο καφές → οι καφέδες. Η γιαγιά → οι γιαγιάδες. -άδες/-έδες plurals.',
  'Έφαγες; is the normal way to ask "Have you eaten?". The perfect is for experience.',
  'Μου λείπεις = I miss you. The person missed is the subject.',
  'ό,τι (whatever) has a comma; ότι means "that".',
  'σε + τον = στον, σε + την = στην, σε + το = στο.',
  'The -ει form after έχω never changes: έχουμε φάει, είχαν δει.',
  'B1 or B2? If you can say -άω, it\'s B1: μιλάω, ρωτάω. B2 keeps -είς: μπορείς.',
  'Ο/η γιατρός, ο/η δικηγόρος: professions in -ος can take either article.',
  'Use the imperfect for habits: Κάθε καλοκαίρι πηγαίναμε στη Νάξο.',
  'Double negatives are correct Greek: Δεν είδα κανέναν.',
  'Θα + imperfect can mean "probably": Θα κοιμόταν. (He was probably asleep.)'
];
