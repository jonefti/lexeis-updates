/* Spanish learning content: phrases, grammar lessons with quizzes, reading texts, daily tips (teen, GCSE level) */
window.LANG_PHRASES_RAW = `
#1 Me
Soy de Inglaterra.|I'm from England.
Tengo un hermano y una hermana.|I have a brother and a sister.
Tengo un perro que se llama Max.|I have a dog called Max.
No tengo mascotas.|I don't have any pets.
Mi cumpleaños es el doce de marzo.|My birthday is the twelfth of March.
Soy alto y simpático.|I'm tall and friendly.
Mi color favorito es el azul.|My favourite colour is blue.
Me gusta el fútbol.|I like football.
No me gusta el chocolate.|I don't like chocolate.
#1 Greetings
¡Hola! ¿Qué tal?|Hi! How are you?
Muy bien, gracias. ¿Y tú?|Very well, thanks. And you?
¿Cómo te llamas?|What's your name?
Me llamo Sam.|My name is Sam.
¿Cuántos años tienes?|How old are you?
Tengo quince años.|I'm fifteen.
¿Dónde vives?|Where do you live?
Vivo en Londres, en el sur de Inglaterra.|I live in London, in the south of England.
¡Hasta luego!|See you later!
¡Hasta mañana!|See you tomorrow!
Encantado. / Encantada.|Nice to meet you.
¡Buen fin de semana!|Have a good weekend!
#1 In class
No entiendo.|I don't understand.
¿Puede repetir, por favor?|Can you repeat, please?
¿Cómo se dice ... en español?|How do you say ... in Spanish?
¿Qué significa esta palabra?|What does this word mean?
¿Puedo ir al baño?|Can I go to the toilet?
He olvidado mis deberes.|I've forgotten my homework.
Lo siento, llego tarde.|Sorry, I'm late.
Mi asignatura favorita es el dibujo porque es creativo.|My favourite subject is art because it's creative.
Odio las matemáticas porque son difíciles.|I hate maths because it's difficult.
El profesor es estricto pero justo.|The teacher is strict but fair.
#2 Opinions
En mi opinión, es genial.|In my opinion, it's great.
Creo que es aburrido.|I think it's boring.
Me gusta mucho el fútbol.|I really like football.
Me encantan los videojuegos.|I love video games.
No me gusta nada.|I don't like it at all.
Prefiero ver series.|I prefer watching series.
Lo bueno es que...|The good thing is that...
Lo malo es que...|The bad thing is that...
Estoy de acuerdo.|I agree.
No estoy de acuerdo.|I disagree.
Depende.|It depends.
#2 Free time
¿Qué haces en tu tiempo libre?|What do you do in your free time?
Juego al fútbol dos veces a la semana.|I play football twice a week.
Los fines de semana salgo con mis amigos.|At weekends I go out with my friends.
Toco la guitarra desde hace tres años.|I've been playing guitar for three years.
¿Quedamos el sábado?|Shall we meet up on Saturday?
¿A qué hora quedamos?|What time shall we meet?
Vamos al cine esta noche.|Let's go to the cinema tonight.
Ayer vi una película muy divertida.|Yesterday I saw a very funny film.
#2 Food
Tengo hambre.|I'm hungry.
Tengo sed.|I'm thirsty.
Quisiera una mesa para dos.|I'd like a table for two.
¿Qué me recomienda?|What do you recommend?
Para mí, una tortilla, por favor.|For me, a Spanish omelette, please.
¿Me trae la cuenta, por favor?|Could you bring me the bill, please?
Soy vegetariano. / Soy vegetariana.|I'm vegetarian.
Está riquísimo.|It's delicious.
Para desayunar tomo cereales.|For breakfast I have cereal.
#2 Town & directions
¿Dónde está la estación?|Where is the station?
¿Hay un banco por aquí?|Is there a bank around here?
Sigue todo recto y gira a la derecha.|Go straight on and turn right.
Está al lado del parque.|It's next to the park.
Está a diez minutos a pie.|It's ten minutes' walk.
En mi pueblo hay un polideportivo pero no hay cine.|In my town there's a sports centre but there's no cinema.
#3 Holidays
El verano pasado fui a España con mi familia.|Last summer I went to Spain with my family.
Nos quedamos en un hotel cerca de la playa.|We stayed in a hotel near the beach.
Hizo sol todos los días.|It was sunny every day.
Fue una experiencia inolvidable.|It was an unforgettable experience.
El año que viene voy a ir a México.|Next year I'm going to go to Mexico.
Si tuviera dinero, viajaría por todo el mundo.|If I had money, I would travel all over the world.
#3 Shopping
¿Cuánto cuesta?|How much does it cost?
¿Tiene una talla más grande?|Do you have a bigger size?
¿Puedo probármelo?|Can I try it on?
Me lo llevo.|I'll take it.
Es demasiado caro.|It's too expensive.
#3 Feelings & health
Estoy cansadísimo.|I'm really tired.
Me duele la cabeza.|I've got a headache.
Estoy un poco nervioso por el examen.|I'm a bit nervous about the exam.
¡Qué guay!|How cool!
¡Qué pena!|What a shame!
¡Qué rollo!|How boring! / What a drag!
¡No me digas!|You don't say!
#3 Future plans
Cuando sea mayor, quiero ser médico.|When I'm older, I want to be a doctor.
Me gustaría estudiar en la universidad.|I'd like to study at university.
Voy a sacar buenas notas este año.|I'm going to get good marks this year.
Espero trabajar en el extranjero.|I hope to work abroad.
`;

window.LANG_GRAMMAR = [
{ id: 'hola', title: 'Saying hello and who you are', level: 1, summary: 'Me llamo…, tengo… años, vivo en…',
  body: `> ¡Hola! ¿Qué tal? | Hi! How are you?
> Bien, gracias. ¿Y tú? | Fine, thanks. And you?
> ¿Cómo te llamas? Me llamo Leo. | What's your name? My name is Leo.
> ¿Cuántos años tienes? Tengo once años. | How old are you? I'm eleven.
> ¿Dónde vives? Vivo en Londres. | Where do you live? I live in London.
! Spanish uses tener (to have) for age: tengo once años = I have eleven years.
! Questions start with an upside-down ¿ and exclamations with ¡.`,
  quiz: [
    { q: 'How do you say "My name is…"?', o: ['Me llamo…', 'Tengo…', 'Soy años…'], a: 0, ex: 'Me llamo = I call myself.' },
    { q: 'I\'m twelve.', o: ['Soy doce años.', 'Tengo doce años.', 'Estoy doce.'], a: 1, ex: 'Age uses tener.' },
    { q: '¿Dónde ___? (you live)', o: ['vives', 'vivo', 'vive'], a: 0, ex: 'tú vives.' },
    { q: 'What goes at the start of a Spanish question?', o: ['?', '¿', '!'], a: 1, ex: 'An upside-down question mark.' }
  ] },
{ id: 'tenerser', title: 'Ser (to be) and tener (to have)', level: 1, summary: 'The first two verbs you need.',
  body: `> soy, eres, es, somos, sois, son | ser = to be
> tengo, tienes, tiene, tenemos, tenéis, tienen | tener = to have
- Soy inglés. Es simpática. Somos amigos.
- Tengo un perro. ¿Tienes hermanos? Tiene los ojos azules.
! You don't need "I" or "you": soy already means "I am".`,
  quiz: [
    { q: 'Yo ___ simpático.', o: ['soy', 'es', 'tengo'], a: 0, ex: 'yo soy.' },
    { q: '¿___ hermanos? (you have)', o: ['Tienes', 'Tengo', 'Eres'], a: 0, ex: 'tú tienes.' },
    { q: 'Mi hermana ___ doce años.', o: ['es', 'tiene', 'tengo'], a: 1, ex: 'Age: tiene.' },
    { q: 'Nosotros ___ amigos.', o: ['somos', 'son', 'tenemos'], a: 0, ex: 'nosotros somos.' }
  ] },
{ id: 'numeros', title: 'Numbers, days and dates', level: 1, summary: 'uno, dos, tres… and el lunes.',
  body: `- 1–10: uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez.
- 11–15: once, doce, trece, catorce, quince. 16–19: dieciséis, diecisiete, dieciocho, diecinueve.
- 20s are one word: veintiuno, veintidós… 31+ use y: treinta y uno, cuarenta y cinco.
- Days and months have no capital letter: el lunes, en enero.
> Mi cumpleaños es el cinco de mayo. | My birthday is the fifth of May.
! "On Monday" is el lunes (no word for "on"). "On Mondays" is los lunes.`,
  quiz: [
    { q: '15', o: ['cinco', 'quince', 'cincuenta'], a: 1, ex: 'quince = 15.' },
    { q: '32', o: ['treinta y dos', 'treintidós', 'tres dos'], a: 0, ex: 'treinta y dos.' },
    { q: 'on Friday', o: ['en viernes', 'el viernes', 'a viernes'], a: 1, ex: 'el viernes.' },
    { q: 'Months in Spanish are written…', o: ['with a capital', 'without a capital'], a: 1, ex: 'enero, febrero…' }
  ] },
{ id: 'preguntas', title: 'Asking questions', level: 1, summary: '¿Qué? ¿Dónde? ¿Cuántos?',
  body: `- ¿Qué? = what? ¿Quién? = who? ¿Dónde? = where? ¿Cuándo? = when?
- ¿Cómo? = how? ¿Por qué? = why? (porque = because) ¿Cuánto/a? = how much? ¿Cuántos/as? = how many?
> ¿Qué te gusta? | What do you like?
> ¿Por qué? Porque es divertido. | Why? Because it's fun.
! Question words always carry an accent.`,
  quiz: [
    { q: 'Where?', o: ['¿Cuándo?', '¿Dónde?', '¿Quién?'], a: 1, ex: 'dónde = where.' },
    { q: 'Why?', o: ['¿Por qué?', '¿Porque?', '¿Qué?'], a: 0, ex: '¿Por qué? (two words, accent). porque = because.' },
    { q: '¿___ hermanos tienes?', o: ['Cuántos', 'Cuánto', 'Qué'], a: 0, ex: 'How many (masculine plural): cuántos.' }
  ] },
{ id: 'gender', title: 'Gender: el, la, los, las', level: 1, summary: 'Every noun is masculine or feminine.',
  body: `- Masculine: el libro, los libros · un libro, unos libros.
- Feminine: la casa, las casas · una casa, unas casas.
- Usually -o is masculine and -a is feminine.
- Feminine endings: -ción, -sión, -dad, -tad, -tud: la canción, la ciudad.
- Masculine traps: el día, el mapa, el problema, el tema, el idioma, el sofá.
- Feminine traps: la mano, la foto, la moto, la radio.
! Feminine nouns starting with a stressed a- take el in the singular: el agua, el aula (but las aguas).`,
  quiz: [
    { q: '___ problema', o: ['el', 'la'], a: 0, ex: 'Words from Greek ending -ma are masculine.' },
    { q: '___ canción', o: ['el', 'la'], a: 1, ex: '-ción words are feminine.' },
    { q: '___ mano', o: ['el', 'la'], a: 1, ex: 'la mano is a famous exception.' },
    { q: '___ día', o: ['el', 'la'], a: 0, ex: 'el día is masculine.' },
    { q: '___ agua está fría.', o: ['el', 'la'], a: 0, ex: 'Stressed a-: el agua (still feminine: el agua fría).' }
  ] },
{ id: 'plurals', title: 'Plurals and adjective agreement', level: 1, summary: 'Add -s or -es; adjectives match.',
  body: `- Vowel at the end → add -s: libro → libros.
- Consonant → add -es: ciudad → ciudades, profesor → profesores.
- -z → -ces: lápiz → lápices.
- Lose the accent: canción → canciones, autobús → autobuses.
- Adjectives agree and usually come after the noun: un chico alto, una chica alta, unos chicos altos, unas chicas altas.
- Adjectives in -e or a consonant don't change for gender: un libro interesante, una película interesante.
! Nationalities add -a: inglés → inglesa, español → española.`,
  quiz: [
    { q: 'Plural of el lápiz', o: ['los lápizs', 'los lápices', 'los lápizes'], a: 1, ex: '-z → -ces.' },
    { q: 'Mis hermanas son muy ___ (simpático)', o: ['simpático', 'simpática', 'simpáticas', 'simpáticos'], a: 2, ex: 'Feminine plural.' },
    { q: 'una casa ___ (grande)', o: ['granda', 'grande', 'grandes'], a: 1, ex: '-e adjectives don\'t change for gender.' },
    { q: 'Plural of la canción', o: ['las canciónes', 'las canciones', 'las cancións'], a: 1, ex: 'Drop the accent: canciones.' }
  ] },
{ id: 'serestar', title: 'Ser vs estar', level: 2, summary: 'Two verbs for "to be".',
  body: `> soy, eres, es, somos, sois, son | ser
> estoy, estás, está, estamos, estáis, están | estar
- Ser: identity, nationality, personality, jobs, time and dates. Soy inglés. Es simpática. Son las tres.
- Estar: location, feelings and temporary states. Estoy en casa. Estoy cansado. La sopa está fría.
! Same adjective, different meaning: es aburrido (he is boring) vs está aburrido (he is bored).`,
  quiz: [
    { q: 'Madrid ___ en España.', o: ['es', 'está'], a: 1, ex: 'Location → estar.' },
    { q: 'Mi madre ___ profesora.', o: ['es', 'está'], a: 0, ex: 'Jobs → ser.' },
    { q: 'Hoy ___ muy cansada.', o: ['soy', 'estoy'], a: 1, ex: 'Temporary state → estar.' },
    { q: 'He is boring.', o: ['Está aburrido.', 'Es aburrido.'], a: 1, ex: 'Personality → ser.' },
    { q: '___ las cinco.', o: ['Son', 'Están'], a: 0, ex: 'Time → ser.' }
  ] },
{ id: 'present', title: 'Present tense: -ar, -er, -ir', level: 1, summary: 'Regular endings in the present.',
  body: `> hablo, hablas, habla, hablamos, habláis, hablan | hablar
> como, comes, come, comemos, coméis, comen | comer
> vivo, vives, vive, vivimos, vivís, viven | vivir
- No subject pronoun needed: Hablo español = I speak Spanish.
- Irregular "yo" forms: tengo, hago, pongo, salgo, digo, vengo, conozco, sé, doy, veo.
! The present can also mean "am doing": ¿Qué haces? What are you doing?`,
  quiz: [
    { q: 'Nosotros ___ en Londres. (vivir)', o: ['vivemos', 'vivimos', 'vivamos'], a: 1, ex: '-ir: vivimos.' },
    { q: 'Ella ___ inglés. (hablar)', o: ['habla', 'hable', 'hablas'], a: 0, ex: 'él/ella: habla.' },
    { q: 'Yo ___ los deberes. (hacer)', o: ['haco', 'hago', 'hace'], a: 1, ex: 'Irregular yo: hago.' },
    { q: 'Ellos ___ pizza. (comer)', o: ['coman', 'comen', 'comin'], a: 1, ex: '-er: comen.' }
  ] },
{ id: 'stem', title: 'Stem-changing verbs', level: 2, summary: 'e→ie, o→ue, e→i in the "boot".',
  body: `The stem vowel changes in every person except nosotros and vosotros (the "boot" shape).
> quiero, quieres, quiere, queremos, queréis, quieren | e → ie (querer)
> puedo, puedes, puede, podemos, podéis, pueden | o → ue (poder)
> pido, pides, pide, pedimos, pedís, piden | e → i (pedir)
- e → ie: pensar, empezar, preferir, entender, cerrar, tener (tengo), venir (vengo).
- o → ue: dormir, volver, encontrar, costar, recordar, jugar (u → ue: juego).
- e → i: pedir, repetir, servir, seguir, vestirse.`,
  quiz: [
    { q: 'Yo ___ al fútbol. (jugar)', o: ['jugo', 'juego', 'jugue'], a: 1, ex: 'jugar: u → ue.' },
    { q: 'Nosotros ___ ir al cine. (querer)', o: ['queremos', 'quieremos'], a: 0, ex: 'No change for nosotros.' },
    { q: '¿A qué hora ___ la película? (empezar)', o: ['empeza', 'empieza', 'empiza'], a: 1, ex: 'e → ie.' },
    { q: 'Ella ___ una pizza. (pedir)', o: ['pide', 'piede', 'pede'], a: 0, ex: 'e → i.' }
  ] },
{ id: 'gustar', title: 'Gustar and encantar', level: 1, summary: 'Me gusta / me gustan.',
  body: `gustar works backwards: the thing liked is the subject.
> Me gusta el fútbol. | I like football.
> Me gustan los perros. | I like dogs.
> Me gusta jugar al tenis. | I like playing tennis.
- me, te, le, nos, os, les: ¿Te gusta? ¿Le gusta a tu madre?
- Same pattern: me encanta(n) (I love), me interesa(n), me duele(n) (it hurts).
- Negative: No me gusta nada.`,
  quiz: [
    { q: 'Me ___ las fresas.', o: ['gusta', 'gustan'], a: 1, ex: 'Plural subject: gustan.' },
    { q: 'A mi hermano ___ gusta el rap.', o: ['me', 'le', 'se'], a: 1, ex: 'a él → le.' },
    { q: 'I love dancing.', o: ['Me encanto bailar.', 'Me encanta bailar.', 'Encanto bailar.'], a: 1, ex: 'Infinitives take singular: encanta.' }
  ] },
{ id: 'preterite', title: 'Preterite: the simple past', level: 2, summary: 'Finished actions: hablé, comí.',
  body: `> hablé, hablaste, habló, hablamos, hablasteis, hablaron | -ar
> comí, comiste, comió, comimos, comisteis, comieron | -er / -ir
- Use it for single, completed actions: Ayer fui al cine. El verano pasado visité Madrid.
- Key irregulars: fui (ser/ir), hice, tuve, estuve, pude, puse, vine, dije, di, vi.
- Spelling: busqué, llegué, empecé (yo forms).
! Fui means both "I went" and "I was": context tells you which.`,
  quiz: [
    { q: 'Ayer ___ al cine. (ir, yo)', o: ['iba', 'fui', 'voy'], a: 1, ex: 'Completed action: fui.' },
    { q: 'El sábado ___ una pizza. (comer, nosotros)', o: ['comemos', 'comimos', 'comíamos'], a: 1, ex: 'comimos (same as present for -ir/-ar nosotros!).' },
    { q: '¿Qué ___ el fin de semana? (hacer, tú)', o: ['hiciste', 'haciste', 'hacías'], a: 0, ex: 'Irregular: hiciste.' },
    { q: 'Yo ___ a las ocho. (llegar)', o: ['llegé', 'llegué', 'llegó'], a: 1, ex: 'Spelling change: llegué.' }
  ] },
{ id: 'imperfect', title: 'Imperfect: used to / was -ing', level: 3, summary: 'Description and habits in the past.',
  body: `> hablaba, hablabas, hablaba, hablábamos, hablabais, hablaban | -ar
> comía, comías, comía, comíamos, comíais, comían | -er / -ir
- Habits: Cuando era pequeño, jugaba en el parque.
- Description: Hacía sol y la playa estaba llena.
- Background: Leía cuando sonó el teléfono.
- Only three irregulars: era (ser), iba (ir), veía (ver).`,
  quiz: [
    { q: 'Cuando era pequeña, ___ mucho. (leer)', o: ['leí', 'leía', 'leo'], a: 1, ex: 'Habit → imperfect.' },
    { q: 'Mientras yo ___ la tele, llamó mi abuela. (ver)', o: ['vi', 'veía', 'veo'], a: 1, ex: 'Background → imperfect.' },
    { q: 'Imperfect of ir (nosotros)', o: ['íbamos', 'ibamos', 'fuimos'], a: 0, ex: 'íbamos.' }
  ] },
{ id: 'future', title: 'Talking about the future', level: 2, summary: 'Voy a + infinitive, or the future tense.',
  body: `- Near future: ir a + infinitive. Voy a estudiar. Vamos a viajar.
- Future tense: infinitive + é, ás, á, emos, éis, án. Hablaré, comerás, vivirá.
- Irregular stems: tendr-, har-, podr-, saldr-, vendr-, dir-, pondr-, querr-, sabr-.
- Conditional (would): same stems + ía: me gustaría, sería, tendría.
> Cuando sea mayor, seré médico. | When I'm older, I'll be a doctor.`,
  quiz: [
    { q: 'I\'m going to go out.', o: ['Voy salir.', 'Voy a salir.', 'Voy a salgo.'], a: 1, ex: 'ir a + infinitive.' },
    { q: 'Mañana ___ calor. (hacer, future)', o: ['hacerá', 'hará', 'haré'], a: 1, ex: 'Irregular stem: har-.' },
    { q: 'I would like…', o: ['Me gustaré…', 'Me gustaría…', 'Me gusto…'], a: 1, ex: 'Conditional: gustaría.' }
  ] },
{ id: 'reflexive', title: 'Reflexive verbs', level: 2, summary: 'Me levanto, te duchas…',
  body: `Reflexive verbs have a pronoun that matches the subject.
> me levanto, te levantas, se levanta, nos levantamos, os levantáis, se levantan | levantarse
- Daily routine: despertarse, levantarse, ducharse, vestirse, acostarse.
- Pronoun before the verb, or on the end of an infinitive: Me voy a duchar = Voy a ducharme.
- Past: Me levanté a las siete.`,
  quiz: [
    { q: 'Ella ___ a las once. (acostarse)', o: ['se acosta', 'se acuesta', 'me acuesto'], a: 1, ex: 'Stem change o → ue + se.' },
    { q: 'Nosotros ___ temprano. (levantarse)', o: ['nos levantamos', 'se levantamos', 'levantamos nos'], a: 0, ex: 'nos.' },
    { q: 'I\'m going to have a shower.', o: ['Voy a ducharme.', 'Voy a me duchar.', 'Me voy duchar.'], a: 0, ex: 'Pronoun on the infinitive.' }
  ] },
{ id: 'porpara', title: 'Por vs para', level: 4, summary: 'Two words for "for".',
  body: `- Para: purpose, destination, deadline, recipient. Estudio para aprobar. Un regalo para mi madre. Para el lunes.
- Por: cause, exchange, through, duration, means. Gracias por todo. Lo compré por diez euros. Paseamos por el parque. Por teléfono.
! Para + infinitive = in order to.`,
  quiz: [
    { q: 'Gracias ___ tu ayuda.', o: ['por', 'para'], a: 0, ex: 'Cause/thanks → por.' },
    { q: 'Este regalo es ___ ti.', o: ['por', 'para'], a: 1, ex: 'Recipient → para.' },
    { q: 'Estudio ___ ser médico.', o: ['por', 'para'], a: 1, ex: 'Purpose → para.' },
    { q: 'Hablamos ___ teléfono.', o: ['por', 'para'], a: 0, ex: 'Means → por.' }
  ] },
{ id: 'perfect', title: 'Present perfect: he hecho', level: 3, summary: 'haber + past participle.',
  body: `> he, has, ha, hemos, habéis, han + hablado / comido | perfect
- Recent past or experience: Hoy he comido paella. ¿Has estado en Madrid?
- Participles: -ar → -ado, -er/-ir → -ido.
- Irregular: hecho, dicho, visto, escrito, puesto, vuelto, abierto, roto, muerto.`,
  quiz: [
    { q: 'Have you seen the film?', o: ['¿Has visto la película?', '¿Has veído la película?', '¿Has vido la película?'], a: 0, ex: 'visto.' },
    { q: 'Hoy ___ mucho. (trabajar, yo)', o: ['he trabajado', 'ha trabajado', 'he trabajo'], a: 0, ex: 'he + -ado.' },
    { q: 'Participle of escribir', o: ['escribido', 'escrito', 'escribiendo'], a: 1, ex: 'Irregular: escrito.' }
  ] }
];

window.LANG_READINGS = [
{ id: 'hola', title: '¡Hola!', en: 'Hello!', level: 'A1', stage: 1, text: `¡Hola! Me llamo Daniel. Tengo once años. Vivo en Madrid con mi madre, mi padre y mi hermana. Mi hermana se llama Ana. Tiene ocho años. Tengo un perro. Se llama Coco. Es pequeño y muy divertido. Me gusta el fútbol. No me gusta el brócoli.`,
  q: [{ q: '¿Cuántos años tiene Daniel?', o: ['ocho', 'once', 'doce'], a: 1 }, { q: '¿Cómo se llama el perro?', o: ['Ana', 'Coco', 'Max'], a: 1 }, { q: '¿Qué no le gusta?', o: ['el fútbol', 'el brócoli', 'el perro'], a: 1 }] },
{ id: 'mochila', title: 'Mi mochila', en: 'My school bag', level: 'A1', stage: 1, text: `En mi mochila tengo muchas cosas. Tengo un libro de español, dos cuadernos y un estuche. En mi estuche hay un bolígrafo azul, un lápiz, una goma y una regla. También tengo una botella de agua y una manzana. ¡Mi mochila es grande y roja!`,
  q: [{ q: '¿Cuántos cuadernos tiene?', o: ['uno', 'dos', 'tres'], a: 1 }, { q: '¿De qué color es el bolígrafo?', o: ['rojo', 'verde', 'azul'], a: 2 }, { q: '¿Cómo es la mochila?', o: ['pequeña y azul', 'grande y roja', 'grande y negra'], a: 1 }] },
{ id: 'semana', title: 'Mi semana', en: 'My week', level: 'A1', stage: 1, text: `El lunes juego al fútbol. El martes estudio inglés con mi amigo. El miércoles como en casa de mi abuela. ¡Su pizza es fenomenal! El jueves y el viernes hago los deberes. El sábado voy al parque con mi familia. El domingo descanso y veo la tele.`,
  q: [{ q: '¿Qué hace el lunes?', o: ['Juega al fútbol', 'Estudia inglés', 'Va al parque'], a: 0 }, { q: '¿Dónde come el miércoles?', o: ['en el colegio', 'en casa de su abuela', 'en un restaurante'], a: 1 }, { q: '¿Qué hace el domingo?', o: ['Descansa', 'Hace los deberes', 'Juega al fútbol'], a: 0 }] },
{ id: 'presentacion', stage: 2, title: 'Me presento', en: 'Introducing myself', level: 'A2', text: `¡Hola! Me llamo Lucía y tengo quince años. Vivo en Sevilla, una ciudad muy bonita en el sur de España. Vivo con mis padres, mi hermano mayor, Pablo, y nuestro perro, Toby. Mi hermano tiene dieciocho años y es muy divertido, pero a veces es un poco perezoso. Me encanta la música y toco el piano desde hace cinco años. Los fines de semana salgo con mis amigos al centro o vamos a la playa en verano. Mi asignatura favorita es la historia porque el profesor es muy interesante. No me gustan las matemáticas porque son difíciles.`,
  q: [{ q: '¿Dónde vive Lucía?', o: ['En Madrid', 'En Sevilla', 'En Barcelona'], a: 1 }, { q: '¿Cómo es su hermano?', o: ['Serio y trabajador', 'Divertido pero un poco perezoso', 'Tímido'], a: 1 }, { q: '¿Por qué le gusta la historia?', o: ['Es fácil', 'El profesor es interesante', 'Le gustan las fechas'], a: 1 }] },
{ id: 'instituto', stage: 2, title: 'Un día en mi instituto', en: 'A day at my school', level: 'A2', text: `Las clases en mi instituto empiezan a las ocho y media y terminan a las tres. Tenemos seis clases al día y un recreo de treinta minutos. Durante el recreo como un bocadillo y charlo con mis amigos en el patio. No llevamos uniforme, así que puedo ponerme lo que quiero, normalmente vaqueros y una sudadera. Los profesores son simpáticos, aunque la profesora de química es bastante estricta. Después de las clases, los martes y jueves juego al baloncesto en el equipo del instituto. Lo malo es que tenemos muchos deberes.`,
  q: [{ q: '¿A qué hora terminan las clases?', o: ['A las dos', 'A las tres', 'A las cuatro'], a: 1 }, { q: '¿Llevan uniforme?', o: ['Sí', 'No', 'Solo los lunes'], a: 1 }, { q: '¿Qué hace los martes y jueves?', o: ['Juega al baloncesto', 'Va a clases de música', 'Hace los deberes'], a: 0 }] },
{ id: 'vacaciones', stage: 3, title: 'Mis vacaciones en Mallorca', en: 'My holidays in Mallorca', level: 'B1', text: `El verano pasado fui a Mallorca con mi familia durante dos semanas. Fuimos en avión desde Londres y nos alojamos en un hotel muy cerca de la playa. Hizo sol todos los días y hacía mucho calor. Por las mañanas nadaba en el mar y por las tardes visitábamos los pueblos de la isla. Un día alquilamos bicicletas y fuimos a una cala preciosa. Lo mejor fue la comida: probé la paella por primera vez y me encantó. Lo peor fue el último día, porque perdí mi móvil en la playa. El año que viene me gustaría volver con mis amigos.`,
  q: [{ q: '¿Cuánto tiempo pasó en Mallorca?', o: ['Una semana', 'Dos semanas', 'Un mes'], a: 1 }, { q: '¿Qué pasó el último día?', o: ['Llovió', 'Perdió su móvil', 'Se puso enfermo'], a: 1 }, { q: '¿Qué hacía por las mañanas?', o: ['Nadaba en el mar', 'Visitaba pueblos', 'Dormía'], a: 0 }] },
{ id: 'redes', stage: 3, title: 'Las redes sociales', en: 'Social media', level: 'B1', text: `Hoy en día casi todos los jóvenes usan las redes sociales. Yo paso unas tres horas al día en el móvil, sobre todo en Instagram y TikTok. Creo que las redes tienen ventajas: puedo hablar con mis amigos, ver vídeos divertidos y aprender cosas nuevas. Sin embargo, también tienen inconvenientes. A veces me comparo con otras personas y me siento mal. Además, es fácil perder mucho tiempo. Mis padres dicen que debería apagar el móvil a las diez de la noche para dormir mejor, y creo que tienen razón. Este año voy a intentar usarlo menos.`,
  q: [{ q: '¿Cuántas horas usa el móvil al día?', o: ['Una', 'Tres', 'Seis'], a: 1 }, { q: '¿Qué inconveniente menciona?', o: ['Es caro', 'Se compara con otros', 'No tiene amigos'], a: 1 }, { q: '¿Qué va a intentar este año?', o: ['Usar menos el móvil', 'Abrir una cuenta nueva', 'Comprar otro móvil'], a: 0 }] },
{ id: 'futuro', stage: 3, title: 'Mis planes para el futuro', en: 'My plans for the future', level: 'B1', text: `Cuando termine el instituto, me gustaría ir a la universidad para estudiar medicina. Mi sueño es ser médica porque quiero ayudar a la gente. Sé que es una carrera muy larga y difícil, pero estoy dispuesta a trabajar mucho. Antes de empezar la universidad, voy a tomarme un año sabático para viajar por Sudamérica y mejorar mi español. También me encantaría trabajar como voluntaria en un hospital. En el futuro, espero vivir en una ciudad grande, tener un piso con terraza y, quizás, un perro.`,
  q: [{ q: '¿Qué quiere estudiar?', o: ['Derecho', 'Medicina', 'Historia'], a: 1 }, { q: '¿Qué va a hacer antes de la universidad?', o: ['Trabajar en una tienda', 'Viajar por Sudamérica', 'Aprender a conducir'], a: 1 }, { q: '¿Dónde espera vivir?', o: ['En el campo', 'En una ciudad grande', 'En la playa'], a: 1 }] },
{ id: 'medioambiente', stage: 4, title: 'Salvar el planeta', en: 'Saving the planet', level: 'B1', text: `El cambio climático es uno de los problemas más graves del mundo. En mi casa intentamos hacer pequeñas cosas para proteger el medio ambiente. Reciclamos el papel, el vidrio y el plástico, y siempre apagamos las luces cuando salimos de una habitación. Yo voy al instituto en bici en vez de en coche, y mi madre ya no compra botellas de plástico. En mi instituto hay un club verde: el mes pasado plantamos treinta árboles en el parque del barrio. Creo que si todos hacemos un pequeño esfuerzo, podemos cambiar las cosas.`,
  q: [{ q: '¿Cómo va al instituto?', o: ['En coche', 'En bici', 'En autobús'], a: 1 }, { q: '¿Qué hizo el club verde?', o: ['Limpió la playa', 'Plantó treinta árboles', 'Recicló ropa'], a: 1 }, { q: '¿Qué ya no compra su madre?', o: ['Carne', 'Botellas de plástico', 'Ropa nueva'], a: 1 }] }
];

window.LANG_TIPS = [
  'Age uses tener: Tengo once años = I am eleven.',
  'You can drop "I": hablo already means "I speak".',
  'Days and months don\'t take capital letters: el lunes, en enero.',
  'Questions open with ¿ and exclamations with ¡.',
  'Me gusta el fútbol, but me gustan los perros (plural).',
  'el día, el mapa, el problema: masculine even though they end in -a.',
  'la mano, la foto, la moto: feminine even though they end in -o.',
  'Ser for who/what you are; estar for where you are and how you feel.',
  'Me gusta + one thing or a verb; me gustan + plural things.',
  'Stem changers never change in nosotros and vosotros: queremos, podemos.',
  'Fui means "I went" (ir) and "I was" (ser).',
  'Preterite for one finished action; imperfect for habits and descriptions.',
  'Spelling in the preterite: busqué, llegué, empecé.',
  'Only three irregular imperfects: era, iba, veía.',
  'Voy a + infinitive is the easiest way to talk about the future.',
  'Me gustaría + infinitive = I would like to… Great for exams.',
  'Use opinions with reasons: Me encanta… porque es…',
  'Desde hace + time with the present: Toco el piano desde hace dos años.',
  'Lo bueno / lo malo / lo mejor / lo peor es que… impresses examiners.',
  'Adjectives usually go after the noun: un coche rojo.',
  'Accents matter: el (the) vs él (he), si (if) vs sí (yes), tu (your) vs tú (you).',
  'Questions and exclamations open with ¿ and ¡.',
  'Para = purpose and destination; por = cause and exchange.',
  'Tener que + infinitive = to have to: Tengo que estudiar.',
  'Acabo de comer = I have just eaten.'
];
