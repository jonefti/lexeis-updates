/* Language pack settings: French (young beginner, 8–11) */
window.LANG = {
  code: 'fr', name: 'French', native: 'Français', flag: '🇫🇷', tts: 'fr-FR', engine: 'French', audience: 'kid',
  hello: h => h < 18 ? 'Bonjour !' : 'Bonsoir !',
  dateLocale: 'fr-FR',
  wordRe: /[A-Za-zÀ-ÖØ-öø-ÿŒœ]+/g,
  lookupUrl: w => 'https://www.wordreference.com/fren/' + encodeURIComponent(w),
  addPlaceholder: 'e.g. le chat, jouer, petit',
  writePlaceholder: 'Écris en français…',
  chatPlaceholder: 'Écris quelque chose…',
  chatHello: 'Bonjour ! Pick a topic or say bonjour!',
  topicStart: t => `On parle de : ${t}. Commence, s'il te plaît.`,
  pronounInForm: true,
  learner: 'The learner is a child aged about 8–11 who is a beginner in French (A1). Use very short, simple French sentences with common words, lots of encouragement, and very simple English explanations a child understands. Keep everything friendly, playful and age-appropriate. Never ask for personal details such as their address, school name or surname.',
  tutorTopics: ['Say hello', 'My family', 'Animals', 'Food I like', 'Colours', 'At school', 'The weather', 'My birthday', 'Games & sport', 'A story together'],
  writingPrompts: ['Write 3 sentences about you: name, age, where you live.', 'What animals do you like? Write 3 sentences.', 'Describe your family.', 'What is your favourite food?', 'What colour is your bedroom? What is in it?', 'What do you like doing at the weekend?', 'Describe the weather today.', 'Write about your best friend.'],
  formExample: 'vais or chevaux',
  dictLevels: ['', 'first words', 'a bit harder', 'harder']
};
