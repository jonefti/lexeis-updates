/* Fun layer: streaks with freezes, XP levels, badges, celebrations, sounds and Okto the mascot. */
(function () {
  'use strict';
  const A = window.App, esc = A.esc, DAY = A.DAY;
  const S = () => A.db.stats;

  // ---------- streak ----------
  const ACTIVE_XP = () => Math.min(10, A.db.settings.goal || 10);
  const dayXp = k => (S().days[k] || {}).xp || 0;
  const isActive = k => dayXp(k) >= ACTIVE_XP() || ((S().days[k] || {}).reviews || 0) >= 5;
  const isFrozen = k => (S().frozen || []).includes(k);
  A.streak = function () {
    let n = 0, t = A.today();
    if (!isActive(A.dayKey(t))) t -= DAY; // today not done yet: streak still alive until midnight
    while (isActive(A.dayKey(t)) || isFrozen(A.dayKey(t))) { if (isActive(A.dayKey(t))) n++; else n++; t -= DAY; }
    return n;
  };
  A.doneToday = () => isActive(A.dayKey());
  // use a freeze for a single missed day (yesterday) so the streak survives
  function maintainStreak() {
    const st = S(); st.frozen = st.frozen || []; st.freezes = st.freezes == null ? 1 : st.freezes;
    const y = A.dayKey(A.today() - DAY), y2 = A.dayKey(A.today() - 2 * DAY);
    if (!isActive(y) && !isFrozen(y) && (isActive(y2) || isFrozen(y2)) && st.freezes > 0 && !st._checked?.[y]) {
      st.freezes--; st.frozen.push(y); st.frozen = st.frozen.slice(-30);
      A._froze = true;
    }
    st._checked = { [y]: true };
  }
  A.weekDots = function () {
    const out = [], t0 = A.today(), dow = (new Date(t0).getDay() + 6) % 7; // Monday first
    for (let i = 0; i < 7; i++) {
      const t = t0 - (dow - i) * DAY, k = A.dayKey(t);
      out.push({ k, label: 'MTWTFSS'[i], state: t > t0 ? 'future' : isActive(k) ? 'done' : isFrozen(k) ? 'frozen' : t === t0 ? 'today' : 'missed' });
    }
    return out;
  };

  // ---------- XP & levels ----------
  A.totalXp = () => Object.values(S().days).reduce((s, d) => s + (d.xp || 0), 0);
  const need = l => 25 * l * (l + 1); // cumulative XP to reach level l+1
  A.levelInfo = function () {
    const xp = A.totalXp(); let l = 0;
    while (xp >= need(l + 1) - 0 && l < 200) l++;
    const lo = need(l), hi = need(l + 1);
    return { level: l + 1, xp, into: xp - lo, span: hi - lo };
  };

  // ---------- badges ----------
  const BADGES = [
    { id: 'first', e: '🌱', name: 'First word', desc: 'Add your first word', test: () => A.db.words.length >= 1 },
    { id: 'w10', e: '📗', name: 'Collector', desc: 'Have 10 words', test: () => A.db.words.length >= 10 },
    { id: 'w50', e: '📚', name: 'Bookworm', desc: 'Have 50 words', test: () => A.db.words.length >= 50 },
    { id: 'w200', e: '🏛️', name: 'Library', desc: 'Have 200 words', test: () => A.db.words.length >= 200 },
    { id: 's3', e: '🔥', name: 'On fire', desc: '3-day streak', test: () => A.streak() >= 3 },
    { id: 's7', e: '🚀', name: 'One week', desc: '7-day streak', test: () => A.streak() >= 7 },
    { id: 's30', e: '🏆', name: 'Unstoppable', desc: '30-day streak', test: () => A.streak() >= 30 },
    { id: 's100', e: '💎', name: 'Legend', desc: '100-day streak', test: () => A.streak() >= 100 },
    { id: 'goal', e: '🎯', name: 'Goal getter', desc: 'Hit your daily goal', test: () => A.todayXp() >= A.db.settings.goal },
    { id: 'flash100', e: '⚡', name: 'Lightning', desc: 'Score 100 in a flash test', test: () => (S().best.flash || 0) >= 100 },
    { id: 'flash300', e: '🌩️', name: 'Thunder', desc: 'Score 300 in a flash test', test: () => (S().best.flash || 0) >= 300 },
    { id: 'lesson', e: '🧩', name: 'Grammar fan', desc: 'Finish a grammar quiz', test: () => Object.keys(A.db.lessons).length >= 1 },
    { id: 'lesson5', e: '🧠', name: 'Brainbox', desc: 'Finish 5 grammar quizzes', test: () => Object.keys(A.db.lessons).length >= 5 },
    { id: 'read', e: '📖', name: 'Reader', desc: 'Finish a story', test: () => Object.keys(A.db.readings).length >= 1 },
    { id: 'speak', e: '🎙️', name: 'Speaker', desc: 'Say 10 things out loud', test: () => (S().spoken || 0) >= 10 },
    { id: 'chat', e: '💬', name: 'Chatterbox', desc: 'Chat with Claude', test: () => A.db.chat.some(m => m.role === 'assistant') },
    { id: 'xp500', e: '⭐', name: 'Rising star', desc: 'Earn 500 XP', test: () => A.totalXp() >= 500 },
    { id: 'xp2000', e: '🌟', name: 'Superstar', desc: 'Earn 2,000 XP', test: () => A.totalXp() >= 2000 },
    { id: 'lvl10', e: '👑', name: 'Level 10', desc: 'Reach level 10', test: () => A.levelInfo().level >= 10 }
  ];
  A.BADGES = BADGES;
  function checkBadges() {
    S().badges = S().badges || {};
    const fresh = BADGES.filter(b => !S().badges[b.id] && safe(b.test));
    fresh.forEach(b => { S().badges[b.id] = Date.now(); });
    return fresh;
  }
  const safe = f => { try { return f(); } catch (e) { return false; } };

  // ---------- sounds ----------
  let ctx = null;
  function tone(freqs, dur, type) {
    if (A.global && A.global.sound === false) return;
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      const t = ctx.currentTime;
      freqs.forEach((f, i) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = type || 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t + i * dur); g.gain.exponentialRampToValueAtTime(0.18, t + i * dur + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + (i + 1) * dur);
        o.connect(g); g.connect(ctx.destination); o.start(t + i * dur); o.stop(t + (i + 1) * dur + 0.05);
      });
    } catch (e) { /* no audio */ }
  }
  A.sfx = {
    right: () => tone([660, 880], 0.08),
    wrong: () => tone([220, 180], 0.12, 'triangle'),
    win: () => tone([523, 659, 784, 1047], 0.11),
    badge: () => tone([784, 988, 1175, 1568], 0.09)
  };
  const _record = A.recordCat;
  A.recordCat = function (cat, ok) { _record(cat, ok); (ok ? A.sfx.right : A.sfx.wrong)(); };

  // ---------- confetti ----------
  A.confetti = function () {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const c = document.createElement('canvas'); c.className = 'confetti';
    document.body.appendChild(c);
    const W = c.width = innerWidth * devicePixelRatio, H = c.height = innerHeight * devicePixelRatio, x = c.getContext('2d');
    const cols = ['#1F4FE0', '#FFC53D', '#E5355B', '#4E9A2B', '#8B6CFF', '#5AA9FF'];
    const ps = Array.from({ length: 140 }, () => ({ x: W / 2 + (Math.random() - .5) * W * .3, y: H * .35, vx: (Math.random() - .5) * 22 * devicePixelRatio, vy: (-Math.random() * 24 - 8) * devicePixelRatio, s: (6 + Math.random() * 8) * devicePixelRatio, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[Math.floor(Math.random() * cols.length)] }));
    let f = 0;
    (function step() {
      x.clearRect(0, 0, W, H);
      ps.forEach(p => { p.vy += 0.9 * devicePixelRatio; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); x.restore(); });
      if (++f < 120) requestAnimationFrame(step); else c.remove();
    })();
  };

  // ---------- celebrations ----------
  const queue = [];
  let showing = false;
  function celebrate(item) { queue.push(item); if (!showing) next(); }
  function next() {
    const it = queue.shift(); if (!it) { showing = false; return; }
    showing = true;
    const el = document.createElement('div'); el.className = 'celebrate';
    el.innerHTML = `<div class="cel-card"><div class="cel-big">${it.big}</div><h2>${esc(it.title)}</h2><p>${esc(it.text)}</p><button class="btn sun big wide" data-act="cel-close">${esc(it.btn || 'Yay!')}</button></div>`;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('on'));
    (it.sound || A.sfx.win)(); A.confetti();
  }
  A.acts['cel-close'] = el => { const c = el.closest('.celebrate'); c.classList.remove('on'); setTimeout(() => { c.remove(); next(); }, 200); };
  A.celebrating = () => showing;
  A.closeCelebration = () => { const c = document.querySelector('.celebrate'); if (c) { c.remove(); next(); return true; } return false; };

  const MILESTONES = [3, 7, 14, 21, 30, 50, 75, 100, 150, 200, 365];
  // called after every XP change
  A.afterXp = function () {
    const st = S();
    const today = A.dayKey();
    st.flags = st.flags || {};
    const f = st.flags[today] = st.flags[today] || {};
    if (!f.active && A.doneToday()) {
      f.active = true;
      const s = A.streak();
      if (MILESTONES.includes(s)) {
        if (s % 7 === 0 && (st.freezes || 0) < 2) st.freezes = (st.freezes || 0) + 1;
        celebrate({ big: '🔥<span class="cel-num">' + s + '</span>', title: `${s}-day streak!`, text: `${A.mascot.name} is so proud of you.${s % 7 === 0 ? ' You earned a streak freeze 🧊.' : ''}`, btn: 'Keep going' });
      } else if (s >= 2) A.toast(`🔥 ${s}-day streak! See you tomorrow`);
      if (A.reschedule) A.reschedule();
    }
    if (!f.goal && A.todayXp() >= A.db.settings.goal) {
      f.goal = true;
      celebrate({ big: '🎯', title: 'Daily goal reached!', text: pick(A.mascot.goalLines), btn: 'Awesome' });
      if (A.reschedule) A.reschedule();
    }
    const lv = A.levelInfo().level;
    if (st.level && lv > st.level) celebrate({ big: '⭐<span class="cel-num">' + lv + '</span>', title: `Level ${lv}!`, text: 'You levelled up. Keep collecting XP to climb higher.', btn: 'Nice' });
    st.level = lv;
    checkBadges().forEach(b => celebrate({ big: b.e, title: 'New badge: ' + b.name, text: b.desc, btn: 'Cool', sound: A.sfx.badge }));
    // keep the flags object small
    const keys = Object.keys(st.flags); if (keys.length > 10) keys.sort().slice(0, keys.length - 10).forEach(k => delete st.flags[k]);
  };
  const _xp = A.xp;
  A.xp = function (n) { _xp(n); try { A.afterXp(); } catch (e) { /* never block learning */ } };
  const pick = a => a[Math.floor(Math.random() * a.length)];

  // ---------- mascot ----------
  A.mascot = {
    name: 'Okto', e: '🐙',
    goalLines: ['Eight arms couldn\'t have done it better!', 'Brilliant work today!', 'You smashed it!', 'Your brain just got stronger.'],
    line() {
      const s = A.streak(), done = A.doneToday(), xp = A.todayXp(), goal = A.db.settings.goal, n = A.db.words.length;
      if (A._froze) { A._froze = false; return 'You missed a day, so I used a streak freeze 🧊 to save your streak!'; }
      if (!n) return 'Hi! I\'m Okto. Add your first word and let\'s start a streak!';
      if (!done && s >= 3) return `Don't lose your ${s}-day streak! A quick practice keeps it alive 🔥`;
      if (!done) return pick(['Ready for a quick practice?', 'Five minutes today is all it takes!', 'Let\'s learn something new!']);
      if (xp < goal) return `${goal - xp} more points to hit today's goal!`;
      return pick(['Goal done! Want to beat your flash test record?', 'You\'re on a roll! 🎉', 'Amazing work today!']);
    }
  };

  // ---------- badges screen ----------
  A.routes.badges = function () {
    const got = S().badges || {}, li = A.levelInfo();
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Badges</h1></header>
      <section class="level-card"><div class="lv-big">${li.level}</div><div class="lv-info"><strong>Level ${li.level}</strong><span class="xp-bar"><i style="width:${Math.round(li.into / li.span * 100)}%"></i></span><small>${li.into} / ${li.span} XP to level ${li.level + 1} · ${li.xp} XP total</small></div></section>
      <section class="streak-card"><div><strong>🔥 ${A.streak()} day streak</strong><small>${(S().freezes || 0)} streak freeze${(S().freezes || 0) === 1 ? '' : 's'} 🧊 · earn one every 7 days</small></div></section>
      <div class="badge-grid">${BADGES.map(b => `<div class="badge ${got[b.id] ? 'got' : ''}"><span class="b-e">${got[b.id] ? b.e : '🔒'}</span><strong>${esc(b.name)}</strong><small>${esc(b.desc)}</small></div>`).join('')}</div>`;
  };
  A.navFor.badges = 'learn';

  // run once at start
  const _load = A.load;
  A.load = function () { _load(); try { maintainStreak(); const st = S(); if (!st.level) st.level = A.levelInfo().level; checkBadges(); A.save(); } catch (e) { /* ignore */ } };
})();
