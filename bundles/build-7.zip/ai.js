/* Claude API helpers. Uses the person's own API key, stored only on this phone. */
(function () {
  'use strict';
  const MODELS = [
    { id: 'claude-sonnet-5-5', label: 'Claude Sonnet 5.5 (recommended)' },
    { id: 'claude-haiku-5-5', label: 'Claude Haiku 5.5 (fastest, cheapest)' },
    { id: 'claude-opus-5-5', label: 'Claude Opus 5.5 (most capable, priciest)' }
  ];

  async function call({ key, model, system, messages, maxTokens }) {
    if (!key) throw new Error('NO_KEY');
    let res;
    try {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({ model: model || MODELS[0].id, max_tokens: maxTokens || 1200, system, messages })
      });
    } catch (e) { throw new Error('No connection. Check your internet and try again.'); }
    let data = null;
    try { data = await res.json(); } catch (e) { /* ignore */ }
    if (!res.ok) {
      const msg = data && data.error && data.error.message ? data.error.message : 'HTTP ' + res.status;
      if (res.status === 401) throw new Error('Your API key was rejected. Check it in Settings.');
      if (res.status === 429) throw new Error('Rate limit reached. Wait a minute and try again.');
      if (res.status === 400 && /credit/i.test(msg)) throw new Error('Your Anthropic account is out of credit.');
      throw new Error(msg);
    }
    return (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
  }

  function parseJSON(text) {
    const t = text.replace(/```(?:json)?/g, '');
    const starts = [t.indexOf('['), t.indexOf('{')].filter(i => i >= 0);
    if (!starts.length) throw new Error('Claude replied in an unexpected format. Try again.');
    const s = Math.min(...starts);
    const open = t[s], close = open === '[' ? ']' : '}';
    const e = t.lastIndexOf(close);
    return JSON.parse(t.slice(s, e + 1));
  }

  const L = () => window.LANG || { name: 'Greek', learner: '' };
  const prompts = {
    get tutor() { const l = L(); return topic => `You are a warm, fun ${l.name} conversation partner. ${l.learner}
Chat naturally in ${l.name} about: ${topic || 'whatever the learner wants'}. Keep each reply short (${l.audience === 'kid' ? '1–2 very short sentences' : '2–4 short sentences'}) and end with a question that keeps the conversation going, pitched at the learner's level.
If the learner's last message contains mistakes (spelling, accents, gender, agreement, verb form, word choice), add a final section that starts on its own line with "✏️" followed by each correction as: wrong → right (short, simple English reason). If there were no mistakes, add nothing.
Don't switch to English except inside the ✏️ section, unless the learner asks or is clearly stuck.`; },
    get suggest() { const l = L(); return `You suggest useful ${l.name} vocabulary. ${l.learner} Reply ONLY with a JSON array, no prose. Each item: {"lemma": dictionary form without article, "article": the definite article for nouns (e.g. ${l.code === 'el' ? '"ο"|"η"|"το"' : l.code === 'es' ? '"el"|"la"' : '"le"|"la"'}) or "", "pos": "noun"|"verb"|"adj"|"other", "meaning": short English gloss, "example": one natural ${l.name} example sentence at the learner's level${l.code === 'el' ? ', "aorist": 1st person aorist if the verb is irregular else "", "future": 1st person simple future without θα if irregular else ""' : ''}}.`; },
    get lookup() { const l = L(); return `You are a precise ${l.name}–English dictionary. ${l.learner} The learner gives one ${l.name} word or phrase, possibly inflected or misspelled. Reply ONLY with a JSON object: {"lemma": dictionary form without article, "article": definite article for nouns or "", "pos": "noun"|"verb"|"adj"|"other", "meaning": short English gloss, "example": natural ${l.name} example at the learner's level, "notes": one line on usage or irregularity in simple English${l.code === 'el' ? ', "aorist": irregular aorist 1sg or "", "future": irregular simple future 1sg without θα or ""' : ''}}.`; },
    get test() { const l = L(); return `You write short, ${l.audience === 'kid' ? 'fun, easy' : 'sharp'} ${l.name} tests. ${l.learner} Reply ONLY with a JSON array of 8 multiple-choice questions mixing vocabulary, gender, agreement, verb forms and sentence completion, based on the learner's words given. Each item: {"q": question (${l.name}, may include a short English instruction), "o": [${l.audience === 'kid' ? 3 : 4} options], "a": index of the correct option, "ex": one-line simple English explanation}.`; },
    get check() { const l = L(); return `You are a kind but careful ${l.name} writing tutor. ${l.learner} The learner writes ${l.name} text. Reply ONLY with a JSON object: {"corrected": the fully corrected text, "mistakes": [{"wrong": "...", "right": "...", "why": short simple English explanation}], "comment": one or two encouraging sentences in English with the most useful lesson, "better": an optional more natural way a native speaker would say it}.`; },
    get story() { const l = L(); return `You write short graded ${l.name} reading texts for this learner. ${l.learner} Length: ${l.audience === 'kid' ? '50–80 words, very simple sentences, present tense, a fun little story' : l.audience === 'teen' ? '100–150 words on a teen-friendly topic' : '120–170 words, natural modern language, interesting everyday topic'}. Reply ONLY with JSON: {"title": title in ${l.name}, "en": English title, "level": CEFR level, "text": the text, "q": [3 objects {"q": question in ${l.name}, "o": [3 options in ${l.name}], "a": index}]}`; }
  };

  window.AI = { MODELS, call, parseJSON, prompts };
})();
