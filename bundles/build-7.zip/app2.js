/* Views: practice (flash, drills, writing games), learn (grammar, phrases, reading, writing, tutor), progress, settings; boot */
(function () {
  'use strict';
  const A = window.App, G = A.G, esc = A.esc;

  // ---------------- shared multiple-choice quiz ----------------
  let quiz = null;
  A.runQuiz = function (opts) { quiz = Object.assign({ i: 0, right: 0, answered: false }, opts); renderQuiz(); };
  function renderQuiz() {
    const q = quiz.questions[quiz.i];
    if (!q) return quizDone();
    A.view().innerHTML = `<div class="review">
      <div class="rv-top"><a class="back" href="${quiz.back}">${esc(quiz.backLabel || 'Back')}</a><span class="rv-count">${quiz.i + 1} / ${quiz.questions.length}</span></div>
      <div class="progress"><span style="width:${quiz.i / quiz.questions.length * 100}%"></span></div>
      <article class="card quiz-card"><p class="cue">${esc(quiz.title)}</p><p class="quiz-q" lang="${A.LANG.code}">${q.html || esc(q.q)}</p>
        <div class="options">${q.o.map((o, i) => `<button class="opt" data-act="quiz-pick" data-i="${i}" lang="${A.LANG.code}">${esc(o)}</button>`).join('')}</div>
        <div class="answer" hidden><p class="verdict"></p>${q.ex ? `<p class="ex-text">${esc(q.ex)}</p>` : ''}</div></article>
      <button class="btn primary wide" data-act="quiz-next" hidden>Next</button></div>`;
  }
  A.acts['quiz-pick'] = function (el) {
    if (quiz.answered) return; quiz.answered = true;
    const q = quiz.questions[quiz.i], i = +el.dataset.i, ok = i === q.a;
    A.$$('.opt').forEach((b, k) => { b.disabled = true; if (k === q.a) b.classList.add('right'); if (b === el && !ok) b.classList.add('wrong'); });
    if (ok) quiz.right++;
    A.recordCat(q.cat || quiz.cat || 'grammar', ok); A.xp(ok ? 2 : 1); A.save();
    const ans = A.$('.answer'); ans.hidden = false;
    A.$('.verdict', ans).textContent = ok ? 'Right' : 'Not quite'; A.$('.verdict', ans).className = 'verdict ' + (ok ? 'ok' : 'bad');
    A.$('[data-act="quiz-next"]').hidden = false;
  };
  A.acts['quiz-next'] = () => { quiz.i++; quiz.answered = false; renderQuiz(); };
  function quizDone() {
    const pct = Math.round(quiz.right / quiz.questions.length * 100);
    if (quiz.onDone) quiz.onDone(quiz.right, quiz.questions.length);
    A.save();
    A.view().innerHTML = `<header class="top"><h1>${quiz.right} / ${quiz.questions.length}</h1></header>
      <section class="done-card">${A.ring(quiz.right, quiz.questions.length, 120, 'Score')}<p class="big-num">${pct}%</p><p class="muted">${pct >= 80 ? 'Excellent.' : pct >= 50 ? 'Good work. Try it again tomorrow.' : 'This one needs more practice. The tips will come up again.'}</p>
      <div class="row-btns">${quiz.retry ? `<button class="btn primary" data-act="quiz-retry">Try again</button>` : ''}<a class="btn" href="${quiz.back}">${esc(quiz.backLabel || 'Back')}</a></div></section>`;
  }
  A.acts['quiz-retry'] = () => { const r = quiz.retry; r(); };

  // ---------------- PRACTICE HUB ----------------
  A.routes.practice = function () {
    const best = A.db.stats.best.flash || 0;
    A.view().innerHTML = `
      <header class="top"><h1>Practice</h1><p class="muted">Quick rounds that build speed and accuracy. Everything feeds your weak spots.</p></header>
      <a href="#/flash" class="feature t-sea"><span class="f-ico">⚡</span><span class="f-text"><strong>Flash test</strong><small>90 seconds of rapid-fire questions: words, articles, verb forms, phrases.${best ? ` Best: ${best}` : ''}</small></span></a>
      <div class="tile-grid">
        <a href="#/articles" class="tile"><span class="arts">${G.GENDERS.map(g => `<b class="g-${g}">${G.G_TO_ART[g]}</b>`).join('')}</span><strong>Article sprint</strong><small>60 seconds of gender</small></a>
        <a href="#/forms/weak" class="tile"><span class="glyph">🎯</span><strong>Weak spots</strong><small>Forms you miss most</small></a>
        <a href="#/forms/verbs" class="tile"><span class="glyph">${{ el: '-ω', es: '-ar', fr: '-er' }[A.LANG.code] || '→'}</span><strong>Verb forms</strong><small>Pick tenses, type forms</small></a>
        <a href="#/forms/nouns" class="tile"><span class="glyph">${A.LANG.code === 'el' ? '-ου' : '+s'}</span><strong>${A.LANG.code === 'el' ? 'Noun cases' : 'Plurals & agreement'}</strong><small>${A.LANG.code === 'el' ? 'Genitives and plurals' : 'Nouns and adjectives'}</small></a>
        <a href="#/vocab" class="tile"><span class="glyph">${{ el: 'Αα', es: 'Ññ', fr: 'Éé' }[A.LANG.code] || 'Aa'}</span><strong>Vocab quiz</strong><small>Your words + dictionary</small></a>
        <a href="#/forms/irregular" class="tile"><span class="glyph irr-g">!</span><strong>Irregulars</strong><small>The rule-breakers</small></a>
        <a href="#/scramble" class="tile"><span class="glyph">⇄</span><strong>Word order</strong><small>Unscramble sentences</small></a>
        <a href="#/translate" class="tile"><span class="glyph">✍️</span><strong>Translate</strong><small>English → ${A.LANG.name}</small></a>
        <a href="#/dictation" class="tile"><span class="glyph">🎧</span><strong>Dictation</strong><small>Listen and type</small></a>
        <a href="#/speak" class="tile"><span class="glyph">🎙️</span><strong>Speak</strong><small>Say it, get a score</small></a>
        <a href="#/badges" class="tile"><span class="glyph">🏅</span><strong>Badges</strong><small>Streak, level, trophies</small></a>
        <a href="#/aitest" class="tile ai"><span class="glyph">✨</span><strong>Claude's test</strong><small>A test made from your words</small></a>
      </div>`;
  };

  // pools for generated questions
  function wordPool() {
    const mine = A.db.words.filter(w => w.meaning);
    const dict = A.stageDict().filter(e => e.pos !== 'other' || e.tag === 'adv' || A.stageLevel() === 1).map(e => ({ lemma: e.lemma, meaning: e.meaning, pos: e.pos, gender: e.gender || '', emoji: e.emoji, _e: e }));
    return { mine, dict };
  }
  function pickWord(pred) {
    const { mine, dict } = wordPool();
    const m = mine.filter(pred || (() => true)), d = dict.filter(pred || (() => true));
    if (m.length >= 6 && Math.random() < 0.65) return A.pick(m);
    return A.pick(d.length ? d : m);
  }
  const headOf = w => A.artJoin(w.lemma, w.gender || A.genderOf(w)) + w.lemma;
  function distract(correct, pool, key, n) {
    const out = new Set([correct]); let tries = 0;
    while (out.size < (n || 4) && tries++ < 60) { const x = A.pick(pool)[key]; if (x && x !== correct) out.add(x); }
    return A.shuffle(Array.from(out));
  }
  function genQuestion(kinds) {
    const k = A.pick(kinds || ['gr', 'gr', 'en', 'art', 'form', 'phrase']);
    const { mine, dict } = wordPool();
    const all = mine.concat(dict);
    if (k === 'gr' || k === 'en') {
      const w = pickWord();
      if (k === 'gr') { const o = distract(w.meaning, all, 'meaning'); return { kind: k, q: (w.emoji ? w.emoji + ' ' : '') + headOf(w), sub: 'What does it mean?', o, a: o.indexOf(w.meaning), cat: 'vocab' }; }
      const o = distract(headOf(w), all.map(x => ({ h: headOf(x) })), 'h'); return { kind: k, q: w.meaning, sub: `Which ${A.LANG.name} word?`, o, a: o.indexOf(headOf(w)), cat: 'vocab', en: true };
    }
    if (k === 'art') {
      const w = pickWord(x => x.pos === 'noun' && (x.gender || A.genderOf(x)) && !/'$/.test(A.art(x.lemma, x.gender || A.genderOf(x))) && !/\s/.test(x.lemma));
      const g = w.gender || A.genderOf(w);
      return { kind: k, q: (w.emoji ? w.emoji + ' ' : '') + w.lemma, sub: 'Which article?', o: G.GENDERS.map(x => G.G_TO_ART[x]), a: G.GENDERS.indexOf(g), cat: 'gender:' + g };
    }
    if (k === 'form') {
      for (let t = 0; t < 8; t++) {
        let w = pickWord(x => x.pos === 'verb');
        if (w._e) w = A.entryToWord(w._e);
        const fq = A.formQuestion(w, { tenses: A.stageTenses().filter(t => t !== 'imperative') });
        if (!fq) continue;
        const vals = Array.from(new Set(A.allRows(w, true).map(r => r.value).filter(v => v && v !== fq.row.value)));
        if (vals.length < 3) continue;
        const o = A.shuffle([fq.row.value].concat(A.shuffle(vals).slice(0, 3)));
        return { kind: k, q: fq.prompt.head, sub: fq.prompt.detail, o, a: o.indexOf(fq.row.value), cat: fq.cat };
      }
      return genQuestion(['gr', 'art']);
    }
    const sp = A.stagePhrases();
    const p = A.pick(sp);
    const same = sp.filter(x => x.topic === p.topic);
    const o = distract(p.gr, same.length > 4 ? same : sp, 'gr');
    return { kind: 'phrase', q: p.en, sub: 'Which is right?', o, a: o.indexOf(p.gr), cat: 'phrase', en: true };
  }

  // ---------------- FLASH TEST ----------------
  let flash = null, flashTimer = null;
  A.routes.flash = function () {
    if (!flash || flash.over) {
      const best = A.db.stats.best.flash || 0;
      A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Flash test</h1>
        <p class="muted">90 seconds. Tap fast: right answers in a row build a combo multiplier. Mixes your words with the dictionary.</p></header>
        ${flash && flash.over ? `<section class="done-card flash-done"><p class="big-num">${flash.score}</p><p class="muted">${flash.right} right · ${flash.n - flash.right} wrong · best combo ×${flash.maxCombo}</p>${flash.score >= best && flash.score > 0 ? '<p class="new-best">New best!</p>' : `<p class="tiny">Best: ${best}</p>`}
          ${flash.misses.length ? `<h2>Review these</h2><ul class="miss-list">${flash.misses.slice(0, 8).map(m => `<li><span lang="${A.LANG.code}">${esc(m.q)}</span> → <b lang="${A.LANG.code}">${esc(m.ans)}</b></li>`).join('')}</ul>` : ''}</section>` : ''}
        <button class="btn primary wide big" data-act="flash-start">${flash && flash.over ? 'Go again' : 'Start'}</button>`;
      return;
    }
    const q = flash.q;
    A.view().innerHTML = `<div class="review flash">
      <div class="rv-top"><a class="back" href="#/practice" data-act="flash-stop">Stop</a><span class="combo ${flash.combo >= 3 ? 'hot' : ''}">×${comboMult()}</span><span class="rv-count" id="ftime">${flash.left}s</span></div>
      <div class="progress time"><span id="fbar" style="width:${flash.left / 90 * 100}%"></span></div>
      <article class="card flash-card"><p class="cue">${esc(q.sub)}</p><p class="flash-q" ${q.en ? '' : `lang="${A.LANG.code}"`}>${esc(q.q)}</p></article>
      <div class="options ${q.kind === 'art' ? 'arts3' : ''}">${q.o.map((o, i) => `<button class="opt ${q.kind === 'art' ? 'g-' + G.GENDERS[i] : ''}" data-act="flash-pick" data-i="${i}" lang="${A.LANG.code}">${esc(o)}</button>`).join('')}</div>
      <p class="flash-score">${flash.score} pts</p></div>`;
  };
  const comboMult = () => flash.combo >= 10 ? 4 : flash.combo >= 6 ? 3 : flash.combo >= 3 ? 2 : 1;
  A.acts['flash-start'] = function () {
    flash = { left: 90, score: 0, n: 0, right: 0, combo: 0, maxCombo: 0, misses: [], over: false, q: genQuestion() };
    clearInterval(flashTimer);
    flashTimer = setInterval(() => {
      if (!flash || flash.over) return clearInterval(flashTimer);
      flash.left--;
      const t = A.$('#ftime'); if (t) t.textContent = flash.left + 's';
      const b = A.$('#fbar'); if (b) b.style.width = (flash.left / 90 * 100) + '%';
      if (flash.left <= 0) endFlash();
    }, 1000);
    A.routes.flash();
  };
  function endFlash() {
    clearInterval(flashTimer); flash.over = true;
    if (flash.score > (A.db.stats.best.flash || 0)) A.db.stats.best.flash = flash.score;
    A.save(); if ((location.hash || '').startsWith('#/flash')) A.routes.flash();
  }
  A.acts['flash-stop'] = () => { clearInterval(flashTimer); flash = null; };
  A.acts['flash-pick'] = function (el) {
    if (!flash || flash.locked) return;
    const q = flash.q, ok = +el.dataset.i === q.a;
    flash.n++; flash.locked = true;
    if (ok) { flash.right++; flash.combo++; flash.maxCombo = Math.max(flash.maxCombo, flash.combo); flash.score += 10 * comboMult(); el.classList.add('right'); }
    else { flash.combo = 0; el.classList.add('wrong'); A.$$('.opt')[q.a].classList.add('right'); flash.misses.push({ q: q.q, ans: q.o[q.a] }); }
    A.recordCat(q.cat, ok); A.xp(ok ? 1 : 0); A.save();
    setTimeout(() => { if (!flash || flash.over) return; flash.locked = false; flash.q = genQuestion(); A.routes.flash(); }, ok ? 250 : 900);
  };

  // ---------------- VOCAB QUIZ ----------------
  A.routes.vocab = function () {
    const qs = []; for (let i = 0; i < 10; i++) { const q = genQuestion(['gr', 'en', 'gr', 'art']); qs.push({ q: q.q, o: q.o, a: q.a, cat: q.cat, ex: '', html: `<span class="q-sub">${esc(q.sub)}</span><br>${esc(q.q)}` }); }
    A.runQuiz({ title: 'Vocabulary', questions: qs, back: '#/practice', backLabel: 'Practice', retry: () => A.routes.vocab() });
  };

  // ---------------- ARTICLE SPRINT ----------------
  let sprint = null, sprintTimer = null;
  A.routes.articles = function () {
    if (!sprint || sprint.over) {
      A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Article sprint</h1><p class="muted">60 seconds. A noun appears; tap ${G.GENDERS.map(g => G.G_TO_ART[g]).join(' or ')}. Uses your nouns and the dictionary.</p></header>
        ${sprint && sprint.over ? `<section class="done-card"><p class="big-num">${sprint.right}<small> / ${sprint.n}</small></p>${sprint.misses.length ? `<p class="muted">Missed:</p><div class="chips wrap">${sprint.misses.map(w => `<span class="chip g-${w.g}" lang="${A.LANG.code}">${esc(A.artJoin(w.lemma, w.g) + w.lemma)}</span>`).join('')}</div>` : '<p class="muted">No misses.</p>'}</section>` : ''}
        <button class="btn primary wide big" data-act="art-start">${sprint && sprint.over ? 'Go again' : 'Start'}</button>`;
      return;
    }
    const w = sprint.cur;
    A.view().innerHTML = `<div class="review sprint"><div class="rv-top"><a class="back" href="#/practice" data-act="art-stop">Stop</a><span class="rv-count" id="timer">${sprint.left}s</span></div>
      <article class="card sprint-card"><p class="card-word" lang="${A.LANG.code}">${w.emoji ? `<span class="emo big">${w.emoji}</span>` : ''}<span class="lemma">${esc(w.lemma)}</span></p><p class="muted">${esc(w.meaning)}</p></article>
      <div class="gender-pick big g${G.GENDERS.length}">${G.GENDERS.map(g => `<button class="gp g-${g}" data-act="art-pick" data-g="${g}">${G.G_TO_ART[g]}</button>`).join('')}</div>
      <p class="flash-score">${sprint.right} right</p></div>`;
  };
  function nounPool() {
    const ok = (l, g) => !/\s/.test(l) && !/'$/.test(A.art(l, g));
    const mine = A.db.words.filter(w => w.pos === 'noun' && A.genderOf(w) && ok(w.lemma, A.genderOf(w))).map(w => ({ lemma: w.lemma, meaning: w.meaning, g: A.genderOf(w), emoji: w.emoji }));
    const dict = A.stageDict().filter(e => e.pos === 'noun' && ok(e.lemma, e.gender) && !/\(pl/.test(e.meaning)).map(e => ({ lemma: e.lemma, meaning: e.meaning, g: e.gender, emoji: e.emoji }));
    return mine.length >= 8 && Math.random() < 0.6 ? mine : dict;
  }
  A.acts['art-start'] = function () {
    sprint = { left: 60, n: 0, right: 0, misses: [], again: [], over: false, cur: A.pick(nounPool()) };
    clearInterval(sprintTimer);
    sprintTimer = setInterval(() => {
      if (!sprint || sprint.over) return clearInterval(sprintTimer);
      sprint.left--; const t = A.$('#timer'); if (t) t.textContent = sprint.left + 's';
      if (sprint.left <= 0) { clearInterval(sprintTimer); sprint.over = true; A.save(); if ((location.hash || '').startsWith('#/articles')) A.routes.articles(); }
    }, 1000);
    A.routes.articles();
  };
  A.acts['art-stop'] = () => { clearInterval(sprintTimer); sprint = null; };
  A.acts['art-pick'] = function (el) {
    if (!sprint || sprint.locked) return;
    const w = sprint.cur, ok = el.dataset.g === w.g;
    sprint.n++; sprint.locked = true;
    if (ok) sprint.right++; else { if (!sprint.misses.find(x => x.lemma === w.lemma)) sprint.misses.push(w); sprint.again.push(w); }
    A.recordCat('gender:' + w.g, ok); A.xp(ok ? 1 : 0); A.save();
    el.classList.add(ok ? 'right' : 'wrongpick');
    if (!ok) A.$(`.gp[data-g="${w.g}"]`).classList.add('right');
    setTimeout(() => {
      if (!sprint || sprint.over) return;
      sprint.locked = false;
      sprint.cur = sprint.again.length && Math.random() < 0.35 ? sprint.again.shift() : A.pick(nounPool());
      A.routes.articles();
    }, ok ? 200 : 700);
  };

  // ---------------- FORMS DRILL ----------------
  let drill = null;
  A.routes.forms = function (mode) {
    mode = mode || 'weak';
    if (!drill || drill.mode !== mode) drill = { mode, tenses: A.stageTenses().slice(0, 4), n: 0, right: 0, q: null, started: mode === 'word', wordId: drill && drill.wordId };
    const pool = formsPool(mode);
    const titles = { weak: 'Weak spots', verbs: 'Verb forms', nouns: A.LANG.code === 'el' ? 'Noun cases' : 'Plurals & agreement', irregular: 'Irregulars only', word: 'Word drill' };
    if (!pool.length) { A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>${titles[mode]}</h1></header><p class="empty">No words for this drill yet.</p>`; return; }
    if (!drill.started) {
      const weak = weakCats().slice(0, 4);
      A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>${titles[mode]}</h1><p class="muted">Rounds of 10. Type each form; accents count.${mode !== 'irregular' && A.db.words.length < 10 ? ' Uses dictionary words too until you have more of your own.' : ''}</p></header>
        ${mode !== 'nouns' ? `<p class="label">Tenses</p><div class="chips wrap">${A.stageTenses().map(t => `<button class="chip ${drill.tenses.includes(t) ? 'on' : ''}" data-act="tense" data-t="${t}">${esc(G.TENSE_LABEL[t].split(' (')[0])}</button>`).join('')}</div>` : ''}
        ${mode === 'weak' ? (weak.length ? `<p class="label">Your weakest areas</p><ul class="weak">${weak.map(c => `<li><span>${esc(A.CAT_LABEL[c.cat] || c.cat)}</span><b>${Math.round(c.acc * 100)}%</b></li>`).join('')}</ul>` : `<p class="muted">Do some reviews or drills first and this will focus on what you miss.</p>`) : ''}
        <button class="btn primary wide big" data-act="forms-start">Start</button>`;
      return;
    }
    if (drill.n >= 10 && !drill.q) {
      A.view().innerHTML = `<header class="top"><h1>${drill.right} / 10</h1></header><section class="done-card">${A.ring(drill.right, 10, 120, 'Score')}<p class="muted">${drill.right >= 8 ? 'Strong round.' : drill.right >= 5 ? 'Getting there.' : 'These will come up more often.'}</p>
        <div class="row-btns"><button class="btn primary" data-act="forms-again">Another round</button><a class="btn" href="#/practice">Done</a></div></section>`;
      return;
    }
    if (!drill.q) drill.q = nextFormQ(pool, mode);
    const q = drill.q;
    if (!q) { A.view().innerHTML = `<p class="empty">No forms match these tenses. <a href="#/practice">Back</a></p>`; return; }
    A.view().innerHTML = `<div class="review"><div class="rv-top"><a class="back" href="#/practice">Stop</a><span class="rv-count">${drill.n + 1} / 10</span></div>
      <div class="progress"><span style="width:${drill.n * 10}%"></span></div>
      <article class="card g-card-${A.genderOf(q.w) || 'x'}"><p class="cue">${esc(q.prompt.detail)}</p><p class="card-word" lang="${A.LANG.code}">${esc(q.prompt.head)}</p><p class="muted">${esc(q.w.meaning)}</p>
      <form data-form="drill" class="typed"><input name="a" lang="${A.LANG.code}" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type the form">${A.canListen() ? '<button type="button" class="icon-btn mic" data-act="mic-fill" aria-label="Say it">🎙️</button>' : ''}<button class="btn primary" type="submit">Check</button></form>
      <div class="answer" hidden><p class="verdict"></p><p class="card-word sm" lang="${A.LANG.code}">${esc((q.prompt.prefix ? q.prompt.prefix + ' ' : '') + q.row.value)}</p></div></article>
      <button class="btn primary wide" data-act="drill-next" hidden>Next</button></div>`;
    A.$('.typed input').focus();
  };
  function formsPool(mode) {
    let ws = A.db.words.filter(w => A.tableFor(w));
    if (mode === 'word') return ws.filter(w => w.id === drill.wordId);
    if (mode === 'irregular') return ws.filter(A.isIrregular).concat(A.stageDict().filter(e => e.ov && (e.ov.aorist || e.ov.stem)).map(e => A.entryToWord(e))).concat(A.stageDict().filter(e => e.pos === 'verb' && G.guessVerbGroup(e.lemma) === 'IRR').map(e => A.entryToWord(e)));
    if (ws.length < 10) ws = ws.concat(A.shuffle(A.stageDict().filter(e => e.pos === 'verb' || (e.pos === 'noun' && !/\s/.test(e.lemma)))).slice(0, 60).map(e => A.entryToWord(e)).filter(w => A.tableFor(w)));
    if (mode === 'verbs') ws = ws.filter(w => w.pos === 'verb');
    if (mode === 'nouns') ws = ws.filter(w => w.pos === 'noun' || w.pos === 'adj');
    return ws;
  }
  const weakCats = () => Object.entries(A.db.stats.cats).filter(([, v]) => v.n >= 3).map(([cat, v]) => ({ cat, acc: v.c / v.n, n: v.n })).sort((a, b) => a.acc - b.acc);
  function nextFormQ(pool, mode) {
    const filter = { tenses: drill.tenses, irregularCells: mode === 'irregular' };
    if (mode === 'weak') { const weak = weakCats().slice(0, 3).map(c => c.cat); for (let k = 0; k < 14; k++) { const q = A.formQuestion(A.pick(pool), filter); if (q && (!weak.length || weak.includes(q.cat) || k > 10)) return q; } }
    for (let k = 0; k < 12; k++) { const q = A.formQuestion(A.pick(pool), filter); if (q) return q; }
    return null;
  }
  A.acts['drill-word'] = el => { drill = { mode: 'word', wordId: el.dataset.id, tenses: A.stageTenses().slice(), n: 0, right: 0, q: null, started: true }; A.go('#/forms/word'); };
  A.acts.tense = el => { const t = el.dataset.t; drill.tenses = drill.tenses.includes(t) ? drill.tenses.filter(x => x !== t) : drill.tenses.concat(t); if (!drill.tenses.length) drill.tenses = [t]; A.routes.forms(drill.mode); };
  A.acts['forms-start'] = () => { Object.assign(drill, { started: true, n: 0, right: 0, q: null }); A.routes.forms(drill.mode); };
  A.acts['forms-again'] = () => { Object.assign(drill, { n: 0, right: 0, q: null }); A.routes.forms(drill.mode); };
  A.acts['drill-next'] = () => { drill.n++; drill.q = null; A.routes.forms(drill.mode); };
  A.forms.drill = function (f, fd) {
    const q = drill.q, res = A.checkAnswer(fd.get('a') || '', q.row.value), ok = res === 'right';
    if (ok) drill.right++;
    A.recordCat(q.cat, ok); A.xp(ok ? 2 : 1); A.save();
    A.$$('input,button', f).forEach(x => x.disabled = true);
    const a = A.$('.answer'); a.hidden = false;
    const v = A.$('.verdict', a); v.textContent = ok ? 'Right' : res === 'accent' ? 'Nearly: check the stress' : 'Not quite'; v.className = 'verdict ' + (ok ? 'ok' : res === 'accent' ? 'mid' : 'bad');
    const nb = A.$('[data-act="drill-next"]'); nb.hidden = false; nb.focus();
  };

  // ---------------- SENTENCE GAMES: scramble, translate, dictation ----------------
  function sentencePool(minWords) {
    const PH = A.stagePhrases();
    const mine = A.db.words.flatMap(w => (w.examples || []).filter(e => e.text && e.text.split(/\s+/).length >= minWords).map(e => ({ gr: e.text, en: w.meaning ? `(uses ${w.lemma}: ${w.meaning})` : '' })));
    const ph = PH.filter(p => p.gr.split(/\s+/).length >= minWords);
    return mine.length >= 5 && Math.random() < 0.3 ? mine : ph;
  }
  let game = null;
  A.routes.scramble = function () {
    if (!game || game.kind !== 'scramble' || game.done) { const p = A.pick(sentencePool(3)); const words = p.gr.replace(/[.!;?,]$/, '').split(/\s+/); game = { kind: 'scramble', p, words, pool: A.shuffle(words.map((w, i) => ({ w, i }))), built: [], n: (game && game.kind === 'scramble' ? game.n : 0), done: false }; if (game.pool.map(x => x.i).join() === words.map((_, i) => i).join()) game.pool.reverse(); }
    const g = game;
    A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Word order</h1></header>
      <article class="card"><p class="cue">Put the words in order</p><p class="en-prompt">${esc(g.p.en)}</p>
        <div class="built" id="built">${g.built.map((x, k) => `<button class="token on" data-act="sc-back" data-k="${k}" lang="${A.LANG.code}">${esc(x.w)}</button>`).join('') || '<span class="tiny">Tap the words below</span>'}</div>
        <div class="tokens">${g.pool.map((x, k) => `<button class="token" data-act="sc-take" data-k="${k}" lang="${A.LANG.code}">${esc(x.w)}</button>`).join('')}</div>
        <div class="answer" hidden><p class="verdict"></p><p class="card-ex" lang="${A.LANG.code}">${esc(g.p.gr)}</p></div></article>
      <div class="row-btns"><button class="btn primary" data-act="sc-check" ${g.pool.length ? 'disabled' : ''}>Check</button><button class="btn" data-act="speak" data-t="${esc(g.p.gr)}">🔊</button><button class="btn ghost" data-act="sc-skip">Skip</button></div>`;
  };
  A.acts['sc-take'] = el => { const x = game.pool.splice(+el.dataset.k, 1)[0]; game.built.push(x); A.routes.scramble(); };
  A.acts['sc-back'] = el => { const x = game.built.splice(+el.dataset.k, 1)[0]; game.pool.push(x); A.routes.scramble(); };
  A.acts['sc-skip'] = () => { game.done = true; A.routes.scramble(); };
  A.acts['sc-check'] = function () {
    const ok = game.built.map(x => G.strip(x.w)).join(' ') === game.words.map(w => G.strip(w)).join(' ');
    A.recordCat('scramble', ok); A.xp(ok ? 3 : 1); A.save();
    const a = A.$('.answer'); a.hidden = false; const v = A.$('.verdict', a); v.textContent = ok ? 'Right!' : 'Not quite. Correct order:'; v.className = 'verdict ' + (ok ? 'ok' : 'bad');
    if (ok) A.speak(game.p.gr);
    game.done = true;
    const btn = A.$('[data-act="sc-check"]'); btn.textContent = 'Next'; btn.dataset.act = 'sc-skip'; btn.disabled = false;
  };

  A.routes.translate = function () {
    if (!game || game.kind !== 'translate' || game.done) game = { kind: 'translate', p: A.pick(A.stagePhrases().filter(p => p.gr.split(/\s+/).length >= 2)), done: false };
    const g = game;
    A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Translate</h1></header>
      <article class="card"><p class="cue">${esc(g.p.topic)} · say it in ${A.LANG.name}</p><p class="en-prompt big">${esc(g.p.en)}</p>
        <form data-form="translate"><textarea name="a" rows="2" lang="${A.LANG.code}" autocapitalize="off" spellcheck="false" placeholder="${esc(A.LANG.writePlaceholder)}"></textarea><div class="row-btns"><button class="btn primary" type="submit">Check</button>${A.canListen() ? '<button type="button" class="btn" data-act="mic-fill">🎙️ Say it</button>' : ''}<button type="button" class="btn ghost" data-act="tr-skip">Skip</button></div></form>
        <div class="answer" hidden></div></article>`;
  };
  A.forms.translate = async function (f, fd) {
    const given = (fd.get('a') || '').trim(); if (!given) return;
    const g = game, sim = A.similarity(given, g.p.gr), ok = sim >= 0.9;
    A.recordCat('translate', ok); A.xp(ok ? 3 : 1); A.save();
    const a = A.$('.answer'); a.hidden = false;
    a.innerHTML = `<p class="verdict ${ok ? 'ok' : sim > 0.7 ? 'mid' : 'bad'}">${ok ? 'Spot on' : sim > 0.7 ? 'Close' : 'Here\'s one way to say it'}</p>
      <p class="card-ex" lang="${A.LANG.code}">${A.diffWords(given, g.p.gr)}</p><p class="tiny">Highlighted words are ones you didn't use. Other correct wordings are possible.</p>
      <div class="row-btns"><button class="btn primary" data-act="tr-skip">Next</button><button class="btn" data-act="speak" data-t="${esc(g.p.gr)}">🔊</button>${!ok ? `<button class="btn" data-act="ai-check-tr">✨ Was mine OK?</button>` : ''}</div><div id="aiBox"></div>`;
    g.given = given; g.done = true;
  };
  A.acts['tr-skip'] = () => { game.done = true; A.routes.translate(); };
  A.acts['ai-check-tr'] = async function () {
    const box = A.$('#aiBox');
    if (!A.aiReady()) { box.innerHTML = A.needKeyCard(); return; }
    box.innerHTML = '<p class="muted thinking">Asking Claude…</p>';
    try {
      const r = await A.ask({ system: window.AI.prompts.check, messages: [{ role: 'user', content: `Intended meaning (English): "${game.p.en}"\nA model answer: "${game.p.gr}"\nMy ${A.LANG.name}: "${game.given}"\nIs mine correct and natural? Correct it.` }], maxTokens: 700 });
      box.innerHTML = renderCheck(window.AI.parseJSON(r));
    } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
  };

  A.routes.dictation = function () {
    if (!game || game.kind !== 'dictation' || game.done) { game = { kind: 'dictation', p: A.pick(A.stagePhrases().filter(p => p.gr.split(/\s+/).length >= 3)), done: false }; setTimeout(() => A.speak(game.p.gr, 0.85), 400); }
    const g = game;
    A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Dictation</h1></header>
      <article class="card"><p class="cue">Listen and type what you hear</p>
        <div class="row-btns center"><button class="btn sun big" data-act="dict-play">🔊 Play</button><button class="btn" data-act="dict-slow">🐢 Slowly</button></div>
        <form data-form="dictation"><textarea name="a" rows="2" lang="${A.LANG.code}" autocapitalize="off" spellcheck="false" placeholder="${esc(A.LANG.writePlaceholder)}"></textarea><div class="row-btns"><button class="btn primary" type="submit">Check</button><button type="button" class="btn ghost" data-act="dict-skip">Skip</button></div></form>
        <div class="answer" hidden></div></article>`;
  };
  A.acts['dict-play'] = () => A.speak(game.p.gr, 0.9);
  A.acts['dict-slow'] = () => A.speak(game.p.gr, 0.55);
  A.acts['dict-skip'] = () => { game.done = true; A.routes.dictation(); };
  A.forms.dictation = function (f, fd) {
    const given = (fd.get('a') || '').trim(), sim = A.similarity(given, game.p.gr), ok = sim >= 0.92;
    A.recordCat('dictation', ok); A.xp(ok ? 3 : 1); A.save();
    const a = A.$('.answer'); a.hidden = false;
    a.innerHTML = `<p class="verdict ${ok ? 'ok' : sim > 0.75 ? 'mid' : 'bad'}">${ok ? 'Perfect' : Math.round(sim * 100) + '% match'}</p><p class="card-ex" lang="${A.LANG.code}">${A.diffWords(given, game.p.gr)}</p><p class="muted">${esc(game.p.en)}</p><div class="row-btns"><button class="btn primary" data-act="dict-skip">Next</button></div>`;
    game.done = true;
  };

  // ---------------- CLAUDE TEST ----------------
  A.routes.aitest = async function () {
    if (!A.aiReady()) { A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Claude's test</h1><p class="muted">Claude writes a fresh 8-question test from your own words, mixing vocabulary, gender, cases and verb forms.</p></header>${A.needKeyCard()}`; return; }
    A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Claude's test</h1></header><section class="done-card"><div class="spinner"></div><p class="muted">Writing a test from your words…</p></section>`;
    const src = A.db.words.length >= 6 ? A.shuffle(A.db.words.slice()).slice(0, 25).map(w => A.plainHead(w) + ' = ' + w.meaning) : A.wordsOfDay().concat(A.shuffle(A.stageDict().slice()).slice(0, 20)).map(e => A.entryHead(e) + ' = ' + e.meaning);
    try {
      const r = await A.ask({ system: window.AI.prompts.test, messages: [{ role: 'user', content: 'My words:\n' + src.join('\n') }], maxTokens: 2000 });
      const qs = window.AI.parseJSON(r).filter(q => q && q.q && Array.isArray(q.o) && q.o.length >= 2 && Number.isInteger(q.a));
      if (!qs.length) throw new Error('Claude returned no usable questions. Try again.');
      if ((location.hash || '') !== '#/aitest') return;
      A.runQuiz({ title: 'Claude\'s test', questions: qs.map(q => Object.assign({ cat: 'grammar' }, q)), back: '#/practice', backLabel: 'Practice', retry: () => A.routes.aitest() });
    } catch (e) { A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Claude's test</h1></header><p class="empty">${esc(e.message)}</p><button class="btn" data-act="retry-aitest">Try again</button>`; }
  };
  A.acts['retry-aitest'] = () => A.routes.aitest();
  A.acts['set-lang'] = el => { if (el.dataset.l === A.LANG.code) return; A.save(); window.setLexeisLang(el.dataset.l); };
  A.acts['set-stage'] = el => { A.db.settings.stage = +el.dataset.s; const st = A.LANG.stages.find(x => x.id === +el.dataset.s); if (st && st.audience === 'kid' && !A.db.settings._goalSet) { A.db.settings.goal = 20; A.db.settings.newPerDay = 8; } A.save(); A.applyStage(); A.toast('Level: ' + st.name); A.routes.settings(); };
  A.changes['rem-on'] = async el => { const ok = await A.enableReminders(el.checked); if (el.checked && !ok) el.checked = false; };
  A.changes['rem-time'] = el => { A.global.rem = Object.assign(A.remSettings(), { time: el.value || '18:30' }); A.saveGlobal(); A.reschedule(); A.toast('Reminder set for ' + el.value); };
  A.changes['rem-streak'] = el => { A.global.rem = Object.assign(A.remSettings(), { streakSaver: el.checked }); A.saveGlobal(); A.reschedule(); };
  A.changes.sound = el => { A.global.sound = el.checked; A.saveGlobal(); };
  A.acts['rem-test'] = () => A.testReminder();
  A.acts['check-updates'] = () => A.checkUpdates ? A.checkUpdates() : A.toast('Updates work in the installed app');

  // ---------------- LEARN HUB ----------------
  A.routes.learn = function () {
    const lessonsDone = Object.keys(A.db.lessons).length, readsDone = Object.keys(A.db.readings).length;
    A.view().innerHTML = `
      <header class="top"><h1>Learn</h1></header>
      <a href="#/tutor" class="feature t-sun"><span class="f-ico">✨</span><span class="f-text"><strong>Talk with Claude</strong><small>A Greek conversation partner that corrects you as you go.${A.aiReady() ? '' : ' Needs your API key.'}</small></span></a>
      <div class="tile-grid two">
        <a href="#/grammar" class="tile big-tile t-pom"><span class="glyph">🧩</span><strong>Grammar</strong><small>${A.grammar.length} topics · ${lessonsDone} done</small></a>
        <a href="#/phrases" class="tile big-tile t-sea"><span class="glyph">💬</span><strong>Everyday ${A.LANG.name}</strong><small>${A.phrases.length} phrases</small></a>
        <a href="#/reading" class="tile big-tile t-olive"><span class="glyph">📖</span><strong>Reading</strong><small>${A.readings.length} texts · ${readsDone} read</small></a>
        <a href="#/writing" class="tile big-tile t-ink"><span class="glyph">✍️</span><strong>Writing</strong><small>Prompts and feedback</small></a>
        <a href="#/suggest" class="tile big-tile t-sun2"><span class="glyph">🪄</span><strong>Word ideas</strong><small>Claude suggests words by topic</small></a>
        <a href="#/words/dict" class="tile big-tile t-sky"><span class="glyph">📚</span><strong>Dictionary</strong><small>${A.dict.length} words</small></a>
      </div>
      <ul class="list menu">
        <li><a href="#/shareapp">📲 Share the app with family</a></li>
        <li><a href="#/badges">🏅 Badges, level and streak</a></li>
        <li><a href="#/progress">📈 Progress</a></li>
        <li><a href="#/settings">⚙️ Settings and Claude key</a></li>
        <li><a href="#/backup">💾 Backup and export</a></li>
      </ul>`;
  };

  // ---------------- GRAMMAR ----------------
  A.routes.grammar = function () {
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Grammar</h1><p class="muted">Short explanations with a quiz after each one.</p></header>
      ${lessonGroups()}`;
  };
  function lessonRow(l) { const r = A.db.lessons[l.id]; const tag = A.stageInfo ? (A.LANG.stages.find(x => x.id === l.level) || {}).name || '' : ['', 'B1', 'B2', 'C1'][l.level]; return `<li><a class="lesson-row ${A.unlocked(l.level) ? '' : 'later'}" href="#/lesson/${l.id}"><span class="lv lv${Math.min(3, l.level)}">${esc(tag)}</span>`;}
  function lessonGroups() {
    const now = A.grammar.filter(l => A.unlocked(l.level)), later = A.grammar.filter(l => !A.unlocked(l.level));
    const list = ls => `<ul class="list lessons">${ls.map(l => { const r = A.db.lessons[l.id]; return lessonRow(l) + `<span class="ls-text"><strong>${esc(l.title)}</strong><small>${esc(l.summary)}</small></span>${r ? `<span class="ls-score ${r.best / r.total >= 0.8 ? 'ok' : ''}">${r.best}/${r.total}</span>` : ''}</a></li>`; }).join('')}</ul>`;
    return list(now) + (later.length ? `<h2>Coming later</h2><p class="tiny">For higher levels. You can still open them.</p>` + list(later) : '');
  }
  A.routes.lesson = function (id) {
    const l = A.grammar.find(x => x.id === id); if (!l) return A.go('#/grammar');
    const body = l.body.split('\n').map(line => {
      if (line.startsWith('- ')) return `<li>${fmt(line.slice(2))}</li>`;
      if (line.startsWith('> ')) { const [gr, en] = line.slice(2).split(' | '); return `<div class="ex-line"><span lang="${A.LANG.code}">${A.tappable(gr)}</span>${en ? `<small>${esc(en)}</small>` : ''}</div>`; }
      if (line.startsWith('! ')) return `<p class="tipline">${fmt(line.slice(2))}</p>`;
      return `<p>${fmt(line)}</p>`;
    }).join('').replace(/(<li>.*?<\/li>)+/g, m => `<ul class="bul">${m}</ul>`);
    A.view().innerHTML = `<header class="top"><a class="back" href="#/grammar">Grammar</a><h1>${esc(l.title)}</h1></header>
      <article class="lesson">${body}</article>
      <button class="btn primary wide big" data-act="lesson-quiz" data-id="${l.id}">Take the quiz (${l.quiz.length})</button>`;
  };
  const fmt = s => A.tappable(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  A.acts['lesson-quiz'] = function (el) {
    const l = A.grammar.find(x => x.id === el.dataset.id);
    const run = () => A.runQuiz({ title: l.title, questions: A.shuffle(l.quiz.map(q => ({ q: q.q, o: q.o, a: q.a, ex: q.ex, cat: 'grammar' }))).map(shuffleOpts), back: '#/lesson/' + l.id, backLabel: 'Lesson', retry: run,
      onDone: (r, t) => { const prev = A.db.lessons[l.id]; A.db.lessons[l.id] = { best: Math.max(r, prev ? prev.best : 0), total: t, last: Date.now() }; } });
    run();
  };
  function shuffleOpts(q) { const idx = A.shuffle(q.o.map((_, i) => i)); return Object.assign({}, q, { o: idx.map(i => q.o[i]), a: idx.indexOf(q.a) }); }

  // ---------------- PHRASES ----------------
  let phraseTopic = null;
  A.routes.phrases = function (topic) {
    const topics = Array.from(new Set((A._allPhrases ? A.phrases : A.stagePhrases()).map(p => p.topic)));
    const moreBtn = A.stagePhrases().length < A.phrases.length ? `<button class="chip" data-act="ph-more">${A._allPhrases ? '− Fewer topics' : '＋ Harder topics'}</button>` : '';
    phraseTopic = topic || (topics.includes(phraseTopic) ? phraseTopic : null) || topics[0];
    const list = A.phrases.filter(p => p.topic === phraseTopic);
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Everyday ${A.LANG.name}</h1></header>
      <div class="chips">${topics.map(t => `<button class="chip ${t === phraseTopic ? 'on' : ''}" data-act="ph-topic" data-t="${esc(t)}">${esc(t)}</button>`).join('')}${moreBtn}</div>
      <ul class="list phrases">${list.map((p, i) => `<li class="phrase"><div class="ph-text"><p class="ph-gr" lang="${A.LANG.code}">${A.tappable(p.gr)}</p><p class="ph-en">${esc(p.en)}</p></div>
        <div class="ph-btns"><button class="icon-btn" data-act="speak" data-t="${esc(p.gr)}" aria-label="Listen">🔊</button><button class="icon-btn" data-act="ph-save" data-i="${A.phrases.indexOf(p)}" aria-label="Save to my words">${A.findByLemma(p.gr) ? '✓' : '+'}</button></div></li>`).join('')}</ul>
      <button class="btn primary wide" data-act="ph-practise">Practise this topic</button>`;
  };
  A.acts['ph-more'] = () => { A._allPhrases = !A._allPhrases; phraseTopic = null; A.routes.phrases(); };
  A.acts['ph-topic'] = el => { phraseTopic = el.dataset.t; A.routes.phrases(phraseTopic); };
  A.acts['ph-save'] = function (el) {
    const p = A.phrases[+el.dataset.i]; if (A.findByLemma(p.gr)) return A.toast('Already saved');
    A.db.words.push(A.newWord({ lemma: p.gr, pos: 'other', meaning: p.en, tags: ['phrase'], source: 'Everyday ' + A.LANG.name }));
    A.save(); A.resetIndex(); A.xp(1); el.textContent = '✓'; A.toast('Saved to your words');
  };
  A.acts['ph-practise'] = function () {
    const list = A.phrases.filter(p => p.topic === phraseTopic);
    const qs = A.shuffle(list.slice()).slice(0, 8).map(p => { const o = distract(p.gr, list.length >= 4 ? list : A.phrases, 'gr'); return { q: p.en, o, a: o.indexOf(p.gr), cat: 'phrase', ex: '' }; });
    A.runQuiz({ title: phraseTopic, questions: qs, back: '#/phrases', backLabel: 'Phrases', retry: () => A.acts['ph-practise']() });
  };

  // ---------------- READING ----------------
  A.routes.reading = function () {
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Reading</h1><p class="muted">Tap any word to look it up or save it. Questions at the end.</p></header>
      <ul class="list lessons">${A.readings.slice().sort((x, y) => (A.unlocked(y.stage) - A.unlocked(x.stage))).map(r => { const d = A.db.readings[r.id]; return `<li><a class="lesson-row ${A.unlocked(r.stage) ? '' : 'later'}" href="#/read/${r.id}"><span class="lv lv${r.level === 'B1' ? 1 : r.level === 'B2' ? 2 : 3}">${r.level}</span><span class="ls-text"><strong lang="${A.LANG.code}">${esc(r.title)}</strong><small>${esc(r.en)}</small></span>${d ? `<span class="ls-score ${d.best === r.q.length ? 'ok' : ''}">${d.best}/${r.q.length}</span>` : ''}</a></li>`; }).join('')}</ul>
      ${A.aiReady() ? `<button class="btn wide" data-act="ai-story">✨ Ask Claude for a new text</button>` : ''}`;
  };
  A.routes.read = function (id) {
    const r = A.readings.find(x => x.id === id) || (A._aiStory && A._aiStory.id === id ? A._aiStory : null);
    if (!r) return A.go('#/reading');
    A.view().innerHTML = `<header class="top"><a class="back" href="#/reading">Reading</a><p class="lv-line"><span class="lv">${esc(r.level)}</span> ${esc(r.en)}</p><h1 lang="${A.LANG.code}">${esc(r.title)}</h1></header>
      <div class="row-btns"><button class="btn sm" data-act="speak" data-t="${esc(r.text)}">🔊 Read aloud</button><button class="btn sm ghost" data-act="read-size">Aa</button></div>
      <article class="reading" lang="${A.LANG.code}">${r.text.split(/\n+/).map(par => `<p>${A.tappable(par).replace(/<button class="tw" data-act="lookup" data-t="([^"]+)">/g, (m, t) => `<button class="tw" data-act="lookup" data-t="${t}" data-ctx="${esc(sentenceOf(r.text, t))}">`)}</p>`).join('')}</article>
      ${r.q && r.q.length ? `<button class="btn primary wide big" data-act="read-quiz" data-id="${esc(r.id)}">Answer ${r.q.length} questions</button>` : ''}`;
  };
  const sentenceOf = (text, w) => (text.split(/(?<=[.;!?·])\s+/).find(s => s.includes(w)) || '').slice(0, 220);
  A.acts['read-size'] = () => { document.body.classList.toggle('big-read'); };
  A.acts['read-quiz'] = function (el) {
    const r = A.readings.find(x => x.id === el.dataset.id) || A._aiStory;
    const run = () => A.runQuiz({ title: r.title, questions: r.q.map(q => shuffleOpts({ q: q.q, o: q.o, a: q.a, cat: 'reading' })), back: '#/read/' + r.id, backLabel: 'Text', retry: run,
      onDone: (s) => { const p = A.db.readings[r.id]; A.db.readings[r.id] = { best: Math.max(s, p ? p.best : 0), last: Date.now() }; } });
    run();
  };
  A.acts['ai-story'] = async function () {
    A.view().innerHTML = `<header class="top"><a class="back" href="#/reading">Reading</a><h1>New text</h1></header><section class="done-card"><div class="spinner"></div><p class="muted">Claude is writing a text with some of your words…</p></section>`;
    const words = A.shuffle(A.db.words.slice()).slice(0, 8).map(w => w.lemma).join(', ');
    try {
      const r = await A.ask({ system: window.AI.prompts.story, messages: [{ role: 'user', content: words ? 'Try to include some of these words: ' + words : 'Any topic.' }], maxTokens: 1500 });
      const d = window.AI.parseJSON(r); d.id = 'ai-' + Date.now(); A._aiStory = d;
      A.go('#/read/' + d.id);
    } catch (e) { A.view().innerHTML += `<p class="empty">${esc(e.message)}</p>`; }
  };

  // ---------------- WRITING ----------------
  const PROMPTS = A.LANG.writingPrompts || [];
  A.routes.writing = function () {
    const p = PROMPTS[A.dayIndex() % PROMPTS.length];
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Writing</h1></header>
      <div class="tile-grid">
        <a href="#/translate" class="tile"><span class="glyph">🔁</span><strong>Translate</strong><small>English → Greek sentences</small></a>
        <a href="#/scramble" class="tile"><span class="glyph">⇄</span><strong>Word order</strong><small>Build the sentence</small></a>
        <a href="#/dictation" class="tile"><span class="glyph">🎧</span><strong>Dictation</strong><small>Listen and write</small></a>
      </div>
      <section class="write-box"><h2>Free writing</h2><p class="prompt-line" id="wprompt">${esc(p)}</p><button class="linkish" data-act="w-new">Another prompt</button>
        <form data-form="freewrite"><textarea name="t" rows="7" lang="${A.LANG.code}" placeholder="${esc(A.LANG.writePlaceholder)}">${esc(A.db.draftText || '')}</textarea>
        <div class="row-btns"><button class="btn primary" type="submit">✨ Check with Claude</button><span class="tiny" id="wc"></span></div></form>
        <div id="fwResult"></div></section>`;
  };
  A.acts['w-new'] = () => { A.$('#wprompt').textContent = A.pick(PROMPTS); };
  A.forms.freewrite = async function (f, fd) {
    const t = (fd.get('t') || '').trim(); if (!t) return;
    A.db.draftText = t; A.save();
    const box = A.$('#fwResult');
    if (!A.aiReady()) { box.innerHTML = A.needKeyCard(); return; }
    box.innerHTML = '<p class="muted thinking">Claude is reading your text…</p>';
    try {
      const r = await A.ask({ system: window.AI.prompts.check, messages: [{ role: 'user', content: `Prompt: ${A.$('#wprompt').textContent}\n\nMy text:\n${t}` }], maxTokens: 1500 });
      box.innerHTML = renderCheck(window.AI.parseJSON(r)); A.xp(5); A.recordCat('writing', true); A.save();
    } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
  };
  function renderCheck(d) {
    return `<div class="check">${d.comment ? `<p class="check-comment">${esc(d.comment)}</p>` : ''}
      ${d.mistakes && d.mistakes.length ? `<ul class="mistakes">${d.mistakes.map(m => `<li><span class="wrong" lang="${A.LANG.code}">${esc(m.wrong)}</span> → <span class="right" lang="${A.LANG.code}">${esc(m.right)}</span><small>${esc(m.why)}</small></li>`).join('')}</ul>` : '<p class="verdict ok">No mistakes found. Μπράβο!</p>'}
      ${d.corrected ? `<p class="label">Corrected</p><p class="card-ex" lang="${A.LANG.code}">${A.tappable(d.corrected)}</p>` : ''}
      ${d.better ? `<p class="label">More natural</p><p class="card-ex" lang="${A.LANG.code}">${A.tappable(d.better)}</p>` : ''}</div>`;
  }

  // ---------------- TUTOR ----------------
  const TOPICS = A.LANG.tutorTopics || [];
  A.routes.tutor = function () {
    if (!A.aiReady()) { A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Talk with Claude</h1><p class="muted">Chat in Greek about anything. Claude keeps it at your level, asks you questions, and corrects your mistakes after each message. Tap any word in its replies to look it up.</p></header>${A.needKeyCard()}`; return; }
    const chat = A.db.chat;
    A.view().innerHTML = `<div class="chat-wrap">
      <header class="top chat-top"><a class="back" href="#/learn">Learn</a><div class="chat-head"><h1>Talk with Claude</h1><button class="btn sm ghost" data-act="chat-new">New chat</button></div>
        <div class="chips">${TOPICS.map(t => `<button class="chip ${A.db.chatTopic === t ? 'on' : ''}" data-act="chat-topic" data-t="${esc(t)}">${esc(t)}</button>`).join('')}</div></header>
      <div class="chat" id="chat">${chat.filter(m => !m.hidden).length ? chat.filter(m => !m.hidden).map(renderMsg).join('') : `<div class="chat-empty"><p>${esc(A.LANG.chatHello)}</p></div>`}</div>
      <form data-form="chat" class="chat-input">${A.canListen() ? '<button type="button" class="btn mic-chat" data-act="mic-fill" aria-label="Speak">🎙️</button>' : ''}<textarea name="m" rows="1" lang="${A.LANG.code}" placeholder="${esc(A.LANG.chatPlaceholder)}" autocapitalize="sentences"></textarea><button class="btn primary" type="submit" aria-label="Send">➤</button></form></div>`;
    const c = A.$('#chat'); c.scrollTop = c.scrollHeight; window.scrollTo(0, document.body.scrollHeight);
  };
  function renderMsg(m) {
    if (m.role === 'user') return `<div class="msg me" lang="${A.LANG.code}">${esc(m.content)}</div>`;
    const [main, ...corr] = m.content.split(/\n(?=✏️)/);
    return `<div class="msg ai"><p lang="${A.LANG.code}">${A.tappable(main.trim()).replace(/\n/g, '<br>')}</p>${corr.length ? `<div class="corr">${esc(corr.join('\n')).replace(/\n/g, '<br>')}</div>` : ''}<button class="icon-btn sm" data-act="speak" data-t="${esc(main.trim())}" aria-label="Listen">🔊</button></div>`;
  }
  A.acts['chat-new'] = () => { A.db.chat = []; A.save(); A.routes.tutor(); };
  A.acts['chat-topic'] = el => { A.db.chatTopic = el.dataset.t; A.db.chat = []; A.save(); A.routes.tutor(); sendChat(A.LANG.topicStart(el.dataset.t), true); };
  A.forms.chat = (f, fd) => { const m = (fd.get('m') || '').trim(); if (m) sendChat(m); };
  async function sendChat(text, hidden) {
    const chat = A.db.chat;
    chat.push({ role: 'user', content: text, hidden: !!hidden });
    const box = A.$('#chat');
    if (!hidden) box.insertAdjacentHTML('beforeend', renderMsg({ role: 'user', content: text }));
    box.insertAdjacentHTML('beforeend', '<div class="msg ai typing"><span></span><span></span><span></span></div>');
    const ta = A.$('.chat-input textarea'); if (ta) ta.value = '';
    box.scrollTop = box.scrollHeight; window.scrollTo(0, document.body.scrollHeight);
    try {
      const msgs = chat.slice(-20).map(m => ({ role: m.role, content: m.content }));
      while (msgs.length && msgs[0].role !== 'user') msgs.shift();
      const reply = await A.ask({ system: window.AI.prompts.tutor(A.db.chatTopic), messages: msgs, maxTokens: 700 });
      chat.push({ role: 'assistant', content: reply });
      if (chat.length > 60) chat.splice(0, chat.length - 60);
      A.xp(2); A.save();
    } catch (e) { chat.pop(); A.save(); A.toast(e.message); }
    if ((location.hash || '') === '#/tutor') A.routes.tutor();
  }

  // ---------------- WORD SUGGESTIONS ----------------
  A.routes.suggest = function () {
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Word ideas</h1><p class="muted">Tell Claude a topic or situation and get 10 useful words at your level, ready to add.</p></header>
      ${A.aiReady() ? `<form data-form="suggest" class="capture-form"><input name="t" placeholder="e.g. renovating a flat, football slang, feelings" autocomplete="off"><button class="btn primary" type="submit">✨ Suggest words</button></form>
      <div class="chips wrap">${['Cooking verbs', 'Office life', 'Instagram slang', 'Emotions', 'The beach', 'Doctor visit', 'Politics', 'Arguments'].map(t => `<button class="chip" data-act="suggest-chip" data-t="${t}">${t}</button>`).join('')}</div>
      <div id="sugg"></div>` : A.needKeyCard()}`;
  };
  A.acts['suggest-chip'] = el => { A.$('form[data-form="suggest"] input').value = el.dataset.t; A.forms.suggest(null, new Map([['t', el.dataset.t]])); };
  A.forms.suggest = async function (f, fd) {
    const t = (fd.get('t') || '').trim(); if (!t) return;
    const box = A.$('#sugg'); box.innerHTML = '<p class="muted thinking">Thinking of words…</p>';
    try {
      const have = A.db.words.slice(-80).map(w => w.lemma).join(', ');
      const r = await A.ask({ system: window.AI.prompts.suggest, messages: [{ role: 'user', content: `Topic: ${t}\nGive 10 words. Avoid words I already have: ${have}` }], maxTokens: 1800 });
      A._sugg = window.AI.parseJSON(r);
      box.innerHTML = `<ul class="list words">${A._sugg.map((d, i) => { const g = G.ART_TO_G[d.article] || ''; return `<li><div class="word-row dict g-bar-${g || 'x'}"><div class="dr-main"><span class="wr-head">${g ? `<span class="art g-${g}">${esc(d.article)}</span> ` : ''}<span class="lemma">${esc(d.lemma)}</span></span><span class="wr-mean">${esc(d.meaning)}</span>${d.example ? `<span class="tiny" lang="${A.LANG.code}">${esc(d.example)}</span>` : ''}</div><button class="dr-add" data-act="sugg-add" data-i="${i}">+</button></div></li>`; }).join('')}</ul>`;
    } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
  };
  A.acts['sugg-add'] = el => { const w = A.addAiWord(A._sugg[+el.dataset.i], 'Claude suggestion'); if (w) { el.textContent = '✓'; el.classList.add('on'); } };

  // ---------------- PROGRESS ----------------
  A.routes.progress = function () {
    const db = A.db; let cards = 0, mature = 0, dueTomorrow = 0; const tmr = A.today() + 2 * A.DAY;
    db.words.forEach(w => Object.values(w.srs).forEach(s => { cards++; if (s.ivl >= 21) mature++; if (s.due < tmr) dueTomorrow++; }));
    const days = []; for (let i = 13; i >= 0; i--) { const k = A.dayKey(A.today() - i * A.DAY); days.push({ k, n: (db.stats.days[k] || {}).xp || 0, d: new Date(A.today() - i * A.DAY) }); }
    const mx = Math.max(db.settings.goal, ...days.map(d => d.n));
    const cats = Object.entries(db.stats.cats).map(([cat, v]) => ({ cat, acc: v.c / v.n, n: v.n })).sort((a, b) => a.acc - b.acc);
    const li = A.levelInfo();
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Progress</h1></header>
      <a class="level-card" href="#/badges"><div class="lv-big">${li.level}</div><div class="lv-info"><strong>Level ${li.level}</strong><span class="xp-bar"><i style="width:${Math.round(li.into / li.span * 100)}%"></i></span><small>${li.into} / ${li.span} XP to level ${li.level + 1}</small></div></a>
      <section class="kpis"><div><b>${db.words.length}</b><span>words</span></div><div><b>${mature}</b><span>well known</span></div><div><b>${A.streak()}</b><span>day streak</span></div><div><b>${db.stats.best.flash || 0}</b><span>best flash</span></div></section>
      <section><h2>Points, last 14 days</h2><div class="bars" role="img" aria-label="Points per day">${days.map(d => `<span class="bar-col"><span class="bar ${d.n >= db.settings.goal ? 'goal' : d.n ? '' : 'zero'}" style="height:${Math.max(3, d.n / mx * 100)}%"></span><small>${'SMTWTFS'[d.d.getDay()]}</small></span>`).join('')}<i class="goal-line" style="bottom:${db.settings.goal / mx * 100}%"></i></div>
        <p class="tiny">${dueTomorrow} cards due by tomorrow · ${cards} cards started · goal ${db.settings.goal} points a day</p></section>
      <section><h2>Accuracy by area</h2>${cats.length ? `<ul class="acc">${cats.map(c => `<li><span>${esc(A.CAT_LABEL[c.cat] || c.cat)}</span><span class="acc-bar"><i style="width:${Math.round(c.acc * 100)}%" class="${c.acc < 0.6 ? 'low' : c.acc < 0.8 ? 'mid' : 'ok'}"></i></span><b>${Math.round(c.acc * 100)}%</b></li>`).join('')}</ul>` : `<p class="muted">Practise a little to see where you're strong and weak.</p>`}</section>`;
  };

  // ---------------- SETTINGS & BACKUP ----------------
  A.routes.settings = function () {
    const s = A.db.settings, gl = A.global;
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Settings</h1></header>
      <section><h2>Language</h2><p class="tiny">Each language keeps its own words and progress. Your Claude key is shared.</p>
        <div class="lang-list">${(window.LEXEIS_LANGS || []).map(l => `<button class="lang-card ${l.code === A.LANG.code ? 'on' : ''}" data-act="set-lang" data-l="${l.code}"><span class="lc-flag">${l.flag}</span><span class="lc-text"><strong>${l.name} · ${l.native}</strong><small>${l.level}</small></span>${l.code === A.LANG.code ? '<span class="lc-on">✓</span>' : ''}</button>`).join('')}</div></section>
      ${A.LANG.stages ? `<section><h2>${esc(A.LANG.name)} level</h2><p class="tiny">Sets which words, tenses, lessons and texts you practise. Move up whenever it feels easy; your words stay.</p>
        <div class="lang-list">${A.LANG.stages.map(st => `<button class="lang-card ${A.stageInfo && st.id === A.stageInfo.id ? 'on' : ''}" data-act="set-stage" data-s="${st.id}"><span class="lc-flag stage-num">${st.id}</span><span class="lc-text"><strong>${esc(st.name)}</strong><small>${esc(st.desc)}</small></span>${A.stageInfo && st.id === A.stageInfo.id ? '<span class="lc-on">✓</span>' : ''}</button>`).join('')}</div></section>` : ''}
      <section><h2>Reminders and sound</h2>
        <label class="toggle"><input type="checkbox" data-change="rem-on" ${A.remSettings().reminders ? 'checked' : ''}> Daily reminder</label>
        <label class="field inline"><span>Reminder time</span><input type="time" value="${A.remSettings().time}" data-change="rem-time"></label>
        <label class="toggle"><input type="checkbox" data-change="rem-streak" ${A.remSettings().streakSaver ? 'checked' : ''}> Streak saver at 8:45pm if you haven't practised</label>
        <label class="toggle"><input type="checkbox" data-change="sound" ${A.global.sound === false ? '' : 'checked'}> Sound effects</label>
        <div class="row-btns"><button class="btn sm" data-act="rem-test">Send a test reminder</button></div></section>
      <section><h2>App updates</h2><p class="tiny">Version ${esc(window.APP_VERSION || '')} (build ${window.APP_BUILD || 'dev'}). New versions download automatically when you open the app.</p>
        <div class="row-btns"><button class="btn" data-act="check-updates">Check for updates</button></div></section>
      <section><h2>Claude</h2><p class="tiny">Your key is stored only on this phone and sent only to Anthropic. Create one at console.anthropic.com → API keys, and add credit under Billing.</p>
        <label class="field"><span>API key</span><input type="password" value="${esc(gl.apiKey)}" data-input="apiKey" placeholder="sk-ant-…" autocomplete="off" autocapitalize="off" spellcheck="false"></label>
        <label class="field"><span>Model</span><select data-change="model">${window.AI.MODELS.map(m => `<option value="${m.id}" ${gl.model === m.id ? 'selected' : ''}>${esc(m.label)}</option>`).join('')}</select></label>
        <div class="row-btns"><button class="btn" data-act="ai-test">Test connection</button><button class="btn ghost" data-act="open-url" data-url="https://console.anthropic.com/settings/keys">Get a key</button></div><p class="tiny" id="aiStatus"></p></section>
      <section><h2>Daily routine</h2>
        <label class="field inline"><span>Daily goal (points)</span><input type="number" min="5" max="500" value="${s.goal}" data-input="goal"></label>
        <label class="field inline"><span>New cards per day</span><input type="number" min="0" max="100" value="${s.newPerDay}" data-input="newPerDay"></label>
        <p class="tiny">Points: 2 per review, 1–3 per drill answer, 5 for checked writing. 30 a day is about 10 minutes.</p></section>
      <section><h2>Share</h2><div class="row-btns"><a class="btn" href="#/shareapp">📲 Share the app</a></div></section>
      <section><h2>Data</h2><div class="row-btns"><a class="btn" href="#/backup">Backup and export</a></div></section>
      <p class="tiny center">Λέξεις · ${A.LANG.name} · ${A.dict.length} dictionary words</p>`;
  };
  A.inputs.apiKey = v => { A.global.apiKey = v.trim(); A.saveGlobal(); };
  A.inputs.goal = v => { A.db.settings.goal = Math.max(5, Math.min(500, +v || 30)); A.save(); };
  A.inputs.newPerDay = v => { A.db.settings.newPerDay = Math.max(0, Math.min(100, +v || 0)); A.save(); };
  A.changes.model = el => { A.global.model = el.value; A.saveGlobal(); };
  A.acts['ai-test'] = async function () {
    const st = A.$('#aiStatus'); st.textContent = 'Testing…';
    try { const r = await A.ask({ system: `Reply with one short ${A.LANG.name} greeting.`, messages: [{ role: 'user', content: 'Hello!' }], maxTokens: 40 }); st.textContent = '✓ Connected. Claude says: ' + r; }
    catch (e) { st.textContent = '✕ ' + (e.message === 'NO_KEY' ? 'Paste your key first.' : e.message); }
  };
  A.routes.backup = function () {
    const db = A.db, safe = Object.assign({}, db, { settings: Object.assign({}, db.settings, { apiKey: '' }) });
    const json = JSON.stringify(safe);
    const csv = db.words.map(w => [A.plainHead(w), w.meaning, (w.examples[0] || {}).text || '', (w.tags || []).join(' ')].map(x => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\n');
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Backup and export</h1><p class="muted">Your words live on this phone. Copy a backup now and then and keep it somewhere safe, such as a note or an email to yourself. (Your API key is left out.)</p></header>
      <section><h2>Backup</h2><textarea class="code" readonly rows="4">${esc(json)}</textarea><div class="row-btns"><button class="btn primary" data-act="copy" data-what="json">Copy backup</button></div></section>
      <section><h2>Restore</h2><textarea class="code" rows="4" id="restore" placeholder="Paste a backup here"></textarea><div class="row-btns"><button class="btn" data-act="restore" data-mode="merge">Add to my words</button><button class="btn danger" data-act="restore" data-mode="replace">Replace everything</button></div></section>
      <section><h2>Export for Anki</h2><p class="tiny">CSV: ${A.LANG.name}, meaning, example, tags.</p><div class="row-btns"><button class="btn" data-act="copy" data-what="csv">Copy CSV</button></div></section>
      <section><h2>Start over</h2><button class="btn danger ghost" data-act="wipe">Delete all words and progress</button></section>`;
    A._export = { json, csv };
  };
  A.acts.copy = function (el) {
    const txt = A._export[el.dataset.what];
    (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => A.toast('Copied'), () => { const ta = A.$('textarea.code'); ta.value = txt; ta.select(); try { document.execCommand('copy'); A.toast('Copied'); } catch (e) { A.toast('Select the text and copy it'); } });
  };
  A.acts.restore = function (el) {
    let data; try { data = JSON.parse(A.$('#restore').value); } catch (e) { return A.toast('That is not a valid backup'); }
    if (!data || !Array.isArray(data.words)) return A.toast('That is not a valid backup');
    if (el.dataset.mode === 'replace') { localStorage.setItem(A.KEY, JSON.stringify(data)); A.load(); }
    else data.words.forEach(w => { if (!A.db.words.some(x => x.id === w.id)) A.db.words.push(w); });
    A.save(); A.resetIndex(); A.toast('Backup restored'); A.go('#/words');
  };
  A.acts.wipe = () => A.sheet(`<h2>Delete everything?</h2><p class="muted">All ${A.db.words.length} words and your progress will be removed from this phone. Copy a backup first if you might want them.</p><div class="row-btns"><button class="btn danger" data-act="wipe-yes">Delete everything</button><button class="btn ghost" data-act="sheet-close">Cancel</button></div>`);
  A.acts['wipe-yes'] = () => { localStorage.removeItem(A.KEY); A.load(); A.save(); A.resetIndex(); A.closeSheet(); A.toast('All data deleted'); A.go('#/today'); };

  // ---------------- SHARE THE APP ----------------
  const shareText = () => `Here's Λέξεις, our language app for Greek, Spanish and French 🐙\n\nDownload it here: ${A.APK_URL}\n\nOpen the downloaded file to install. If Android asks, allow installs from your browser or files app. After that it updates itself.`;
  A.routes.shareapp = function () {
    const t = encodeURIComponent(shareText());
    A.view().innerHTML = `<header class="top"><a class="back" href="#/learn">Learn</a><h1>Share the app</h1><p class="muted">Send Λέξεις to the family. It works for Greek, Spanish and French, and each person picks their language when they first open it.</p></header>
      <section class="share-qr"><img src="share-qr.svg" alt="QR code for the download link" onerror="this.parentNode.classList.add('noqr')"><p class="tiny">Scan with the other phone's camera to download.</p></section>
      <div class="share-grid">
        <button class="share-btn wa" data-act="open-url" data-url="https://wa.me/?text=${t}"><span>💬</span>WhatsApp</button>
        <button class="share-btn sms" data-act="open-url" data-url="sms:?body=${t}"><span>✉️</span>Text message</button>
        <button class="share-btn mail" data-act="open-url" data-url="mailto:?subject=${encodeURIComponent('Λέξεις: our language app')}&body=${t}"><span>📧</span>Email</button>
        <button class="share-btn copy" data-act="copy-link"><span>🔗</span>Copy link</button>
      </div>
      <section class="callout"><p><strong>Installing on their phone</strong></p><ol class="steps"><li>Open the link and download <b>Lexeis.apk</b>.</li><li>Tap the file to install. If Android blocks it, tap <b>Settings</b> and allow this source; on Samsung, turn off <b>Auto Blocker</b> first.</li><li>Open Λέξεις and pick a language. After that it updates itself.</li></ol></section>
      <p class="tiny center" style="word-break:break-all">${esc(A.APK_URL)}</p>`;
  };
  A.navFor.shareapp = 'learn';
  A.acts['copy-link'] = () => {
    const txt = shareText();
    (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => A.toast('Link and instructions copied'), () => {
      const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); A.toast('Link and instructions copied'); } catch (e) { A.toast('Copy failed'); } ta.remove();
    });
  };

  // ---------------- BOOT & EVENTS ----------------
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-act]'); if (!el) return;
    const fn = A.acts[el.dataset.act]; if (!fn) return;
    if (el.tagName === 'A' && el.dataset.act !== 'flash-stop' && el.dataset.act !== 'art-stop' && el.dataset.act !== 'sheet-close-go') e.preventDefault();
    fn(el, e);
  });
  document.addEventListener('submit', e => { e.preventDefault(); const f = e.target, fn = A.forms[f.dataset.form]; if (fn) fn(f, new FormData(f)); });
  document.addEventListener('input', e => { const k = e.target.dataset.input; if (k && A.inputs[k]) A.inputs[k](e.target.value, e.target); if (e.target.matches('.chat-input textarea')) { e.target.style.height = 'auto'; e.target.style.height = Math.min(140, e.target.scrollHeight) + 'px'; } });
  document.addEventListener('change', e => { const k = e.target.dataset.change; if (k && A.changes[k]) A.changes[k](e.target); if (e.target.dataset.pp) A.changes.pp(e.target); });
  document.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && e.target.matches('.chat-input textarea')) { e.preventDefault(); e.target.form.requestSubmit(); } });

  A.load();
  window.addEventListener('hashchange', A.render);
  if (window.__lexeisPending) { const t = window.__lexeisPending; window.__lexeisPending = null; window.__lexeisShare(t); } else A.render();
  window.__lexeis = A;
})();

