/* Core: storage, word model, spaced repetition, content, lookup, UI helpers, router. */
(function () {
  'use strict';
  const LANG = window.LANG, G = window[LANG.engine];
  const KEY = LANG.code === 'el' ? 'lexeis.v1' : 'lexeis.v1.' + LANG.code;
  const DAY = 86400000;
  const A = window.App = { G, LANG, DAY, routes: {} };

  A.$ = (s, r) => (r || document).querySelector(s);
  A.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  A.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  A.today = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
  A.dayKey = t => { const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  A.dayIndex = () => Math.floor((A.today() + 12 * 3600000) / DAY);
  A.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  A.shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  A.pick = a => a[Math.floor(Math.random() * a.length)];
  A.seeded = seed => () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };

  // ---------- storage ----------
  A.loadGlobal = function () {
    try { A.global = JSON.parse(localStorage.getItem('lexeis.global')) || {}; } catch (e) { A.global = {}; }
    A.global = Object.assign({ lang: LANG.code, apiKey: '', model: 'claude-sonnet-5-5' }, A.global);
  };
  A.saveGlobal = function () { try { localStorage.setItem('lexeis.global', JSON.stringify(A.global)); } catch (e) { /* ignore */ } };
  A.KEY = KEY;
  A.load = function () {
    A.loadGlobal();
    let db;
    try { db = JSON.parse(localStorage.getItem(KEY)); } catch (e) { db = null; }
    if (!db || !Array.isArray(db.words)) db = { words: [], inbox: [] };
    db.inbox = db.inbox || []; db.stats = db.stats || {};
    db.stats.cats = db.stats.cats || {}; db.stats.days = db.stats.days || {}; db.stats.best = db.stats.best || {};
    const st0 = (LANG.stages || []).find(x => x.id === ((db.settings || {}).stage || LANG.defaultStage));
    const aud = (st0 && st0.audience) || LANG.audience;
    db.settings = Object.assign({ newPerDay: aud === 'kid' ? 8 : 15, goal: aud === 'kid' ? 20 : 30 }, db.settings || {});
    if (db.settings.apiKey && !A.global.apiKey) { A.global.apiKey = db.settings.apiKey; A.global.model = db.settings.model || A.global.model; }
    delete db.settings.apiKey; delete db.settings.model;
    A.global.lang = LANG.code; A.saveGlobal();
    db.lessons = db.lessons || {}; db.readings = db.readings || {}; db.chat = db.chat || [];
    A.db = db;
    A.applyStage();
  };
  // stages (levels) gate content and tenses for languages that have them
  A.applyStage = function () {
    const st = (LANG.stages || []).find(x => x.id === (A.db.settings.stage || LANG.defaultStage)) || null;
    A.stageInfo = st;
    if (!A._baseLang) A._baseLang = { learner: LANG.learner, audience: LANG.audience, tutorTopics: LANG.tutorTopics, writingPrompts: LANG.writingPrompts };
    const b = A._baseLang;
    LANG.learner = (st && st.learner) || b.learner;
    LANG.audience = (st && st.audience) || b.audience;
    LANG.tutorTopics = (st && st.tutorTopics) || b.tutorTopics;
    LANG.writingPrompts = (st && st.writingPrompts) || b.writingPrompts;
  };
  A.stageLevel = () => A.stageInfo ? A.stageInfo.dict : 99;
  A.stageDict = () => A.stageInfo ? A.dict.filter(e => e.level <= A.stageInfo.dict) : A.dict;
  A.stageTenses = () => (A.stageInfo && A.stageInfo.tenses) || G.TENSES;
  A.unlocked = lvl => !A.stageInfo || (lvl || 1) <= A.stageInfo.id;
  A.save = function () { try { localStorage.setItem(KEY, JSON.stringify(A.db)); } catch (e) { A.toast('Could not save: storage is full'); } };
  A.findWord = id => A.db.words.find(w => w.id === id);
  A.findByLemma = l => A.db.words.find(w => G.strip(w.lemma) === G.strip(l));

  // ---------- word model ----------
  A.newWord = fields => Object.assign({
    id: A.uid(), lemma: '', article: '', pos: 'other', gender: '', paradigm: null, group: null,
    meaning: '', note: '', examples: [], tags: [], ov: {}, cells: {}, irregular: false,
    srs: {}, created: Date.now(), source: ''
  }, fields);

  A.tableFor = function (w, all) {
    const cells = w.cells || {};
    const mkRow = (key, label, auto, prefix) => {
      const edited = cells[key] != null && cells[key] !== auto;
      return { key, label, auto, value: cells[key] != null ? cells[key] : auto, edited, prefix: prefix || '' };
    };
    if (w.pos === 'noun') {
      const g = A.genderOf(w);
      const auto = w.paradigm ? G.declineWith(w.lemma, w.paradigm) || {} : {};
      const art = G.ARTICLES[g] || { sg: ['', '', '', ''], pl: ['', '', '', ''] };
      if (!w.paradigm && !Object.keys(cells).length) return null;
      return { kind: 'noun', sections: ['sg', 'pl'].map(n => ({ title: n === 'sg' ? 'Singular' : 'Plural', rows: G.CASES.map((c, i) => mkRow(n + '.' + c, G.CASE_LABEL[c], auto[n + '.' + c] || '', n === 'sg' && LANG.code !== 'el' ? A.art(w.lemma, g) : art[n][i])) })) };
    }
    if (w.pos === 'adj') {
      const a = G.declineAdj(w.lemma);
      if (!a && !Object.keys(cells).length) return null;
      const sections = [];
      [['m', 'Masculine'], ['f', 'Feminine'], ['n', 'Neuter']].filter(([g]) => G.GENDERS.includes(g)).forEach(([g, t]) => ['sg', 'pl'].forEach(n => sections.push({
        title: t + ' ' + (n === 'sg' ? 'singular' : 'plural'), gender: g, num: n,
        rows: G.CASES.map((c, i) => mkRow(g + '.' + n + '.' + c, G.CASE_LABEL[c], a && a[g] ? a[g][n + '.' + c] : '', LANG.code === 'el' ? G.ARTICLES[g][n][i] : ''))
      })));
      return { kind: 'adj', sections };
    }
    if (w.pos === 'verb') {
      const c = G.conjugate(w.lemma, w.group, w.ov);
      if (!c) return null;
      const allowed = all ? G.TENSES : A.stageTenses();
      return { kind: 'verb', hidden: G.TENSES.filter(t => c.tenses[t] && !allowed.includes(t)).length, sections: G.TENSES.filter(t => c.tenses[t] && allowed.includes(t)).map(t => ({
        title: G.TENSE_LABEL[t], tense: t, conf: c.conf[t],
        rows: c.tenses[t].map((v, i) => mkRow(t + '.' + i, LANG.pronounInForm ? '' : G.PERSONS[i], v)).filter(r => r.value)
      })) };
    }
    return null;
  };
  A.allRows = (w, all) => { const t = A.tableFor(w, all); return t ? t.sections.flatMap(s => s.rows.map(r => Object.assign({ section: s }, r))) : []; };
  A.isIrregular = w => !!(w.irregular || Object.keys(w.cells || {}).length || (w.ov && (w.ov.aorist || w.ov.future || w.ov.imperfect)));
  A.genderOf = w => w.pos === 'noun' ? (w.gender || G.ART_TO_G[w.article] || '') : '';
  A.art = (lemma, g) => g ? (G.art ? G.art(lemma, g) : G.G_TO_ART[g]) : '';
  A.artJoin = (lemma, g) => { const a = A.art(lemma, g); return a ? (a.endsWith("'") ? a : a + ' ') : ''; };
  A.emo = w => w && w.emoji ? `<span class="emo">${w.emoji}</span>` : '';
  A.headword = w => { const g = A.genderOf(w), a = A.art(w.lemma, g); return A.emo(w) + (a ? `<span class="art g-${g}">${a}</span>${a.endsWith("'") ? '' : ' '}` : '') + `<span class="lemma">${A.esc(w.lemma)}</span>`; };
  A.plainHead = w => A.artJoin(w.lemma, A.genderOf(w)) + w.lemma;
  A.entryHead = e => A.artJoin(e.lemma, e.gender) + e.lemma;

  // ---------- spaced repetition ----------
  A.cardTypes = function (w) {
    const t = [];
    if (w.meaning) { t.push('mean'); t.push('recall'); }
    if (w.pos === 'noun' && A.genderOf(w)) t.push('gender');
    if (A.tableFor(w)) t.push('form');
    if (A.clozeFor(w)) t.push('cloze');
    return t;
  };
  A.schedule = function (card, grade) {
    card = Object.assign({ ivl: 0, ease: 2.5, reps: 0, lapses: 0 }, card);
    const now = Date.now();
    if (grade === 0) { card.lapses++; card.ease = Math.max(1.3, card.ease - 0.2); card.ivl = 0; card.reps = 0; card.due = now + 10 * 60000; card.failed = now; }
    else {
      if (grade === 1) { card.ivl = Math.max(1, Math.round((card.ivl || 1) * 1.2)); card.ease = Math.max(1.3, card.ease - 0.15); }
      else if (grade === 2) card.ivl = card.reps === 0 ? 1 : card.reps === 1 ? 3 : Math.round(card.ivl * card.ease);
      else { card.ivl = card.reps === 0 ? 4 : Math.round(Math.max(card.ivl, 1) * card.ease * 1.3); card.ease += 0.15; }
      card.reps++; card.due = A.today() + card.ivl * DAY + 4 * 3600000;
    }
    card.last = now;
    return card;
  };
  A.previewIvl = (card, g) => { if (g === 0) return '10m'; const d = A.schedule(card, g).ivl; return d < 30 ? d + 'd' : d < 365 ? Math.round(d / 30) + 'mo' : (d / 365).toFixed(1) + 'y'; };
  A.dueQueue = function () {
    const now = Date.now(), due = [], fresh = [];
    A.db.words.forEach(w => A.cardTypes(w).forEach(t => { const s = w.srs[t]; if (!s) fresh.push({ w, t }); else if (s.due <= now + 7200000) due.push({ w, t }); }));
    const introduced = (A.db.stats.days[A.dayKey()] || {}).new || 0;
    const room = Math.max(0, A.db.settings.newPerDay - introduced);
    const order = { mean: 0, gender: 1, recall: 2, cloze: 3, form: 4 };
    fresh.sort((a, b) => (a.w.created - b.w.created) || (order[a.t] - order[b.t]));
    return { due: A.shuffle(due), fresh: fresh.slice(0, room), freshTotal: fresh.length };
  };
  A.bumpDay = function (field, n) {
    const d = A.db.stats.days[A.dayKey()] = A.db.stats.days[A.dayKey()] || { reviews: 0, new: 0, correct: 0, xp: 0 };
    d[field] = (d[field] || 0) + (n == null ? 1 : n);
  };
  A.xp = n => { A.bumpDay('xp', n || 1); };
  A.todayXp = () => (A.db.stats.days[A.dayKey()] || {}).xp || 0;
  A.recordCat = function (cat, ok) { const c = A.db.stats.cats[cat] = A.db.stats.cats[cat] || { n: 0, c: 0 }; c.n++; if (ok) c.c++; };
  A.streak = function () {
    let s = 0, t = A.today();
    const active = k => { const d = A.db.stats.days[k]; return d && ((d.xp || 0) > 0 || (d.reviews || 0) > 0); };
    if (!active(A.dayKey(t))) t -= DAY;
    while (active(A.dayKey(t))) { s++; t -= DAY; }
    return s;
  };
  A.nextDueText = function () {
    let m = Infinity;
    A.db.words.forEach(w => Object.values(w.srs).forEach(s => { if (s.due < m) m = s.due; }));
    if (m === Infinity) return 'once you add words';
    const d = Math.round((m - A.today()) / DAY);
    return d <= 0 ? 'later today' : d === 1 ? 'tomorrow' : `in ${d} days`;
  };

  // ---------- cloze / questions ----------
  A.clozeFor = function (w) {
    const ex = (w.examples || []).find(e => e.text);
    if (!ex) return null;
    const forms = new Set([G.strip(w.lemma)]);
    A.allRows(w, true).forEach(r => r.value && r.value.split(' ').forEach(x => x.length > 1 && x !== 'θα' && !G.PERSONS.includes(x) && forms.add(G.strip(x))));
    const tokens = ex.text.split(/(\s+|[.,;!?·«»"()]+)/);
    const idx = tokens.findIndex(tok => tok && forms.has(G.strip(tok)));
    if (idx < 0) return null;
    return { before: tokens.slice(0, idx).join(''), answer: tokens[idx], after: tokens.slice(idx + 1).join('') };
  };
  A.CAT_LABEL = {
    'noun:sg.gen': 'Nouns: genitive singular', 'noun:sg.acc': 'Nouns: accusative singular', 'noun:sg.voc': 'Nouns: vocative',
    'noun:pl.nom': 'Nouns: nominative plural', 'noun:pl.gen': 'Nouns: genitive plural', 'noun:pl.acc': 'Nouns: accusative plural',
    'verb:present': 'Verbs: present', 'verb:imperfect': 'Verbs: imperfect', 'verb:aorist': 'Verbs: aorist', 'verb:future': 'Verbs: future',
    'verb:futcont': 'Verbs: future continuous', 'verb:perfect': 'Verbs: perfect', 'verb:imperative': 'Verbs: imperative',
    'gender:m': 'Gender: masculine nouns', 'gender:f': 'Gender: feminine nouns', 'gender:n': 'Gender: neuter nouns',
    'adj:forms': 'Adjectives: forms', 'meaning': `Meaning (${LANG.name} to English)`, 'recall': `Recall (English to ${LANG.name})`, 'cloze': 'Words in context',
    'verb:preterite': 'Verbs: preterite', 'verb:conditional': 'Verbs: conditional', 'verb:passe': 'Verbs: passé composé', 'verb:futproche': 'Verbs: near future', 'verb:imparfait': 'Verbs: imparfait', 'noun:pl.nom': 'Nouns: plurals', 'reading': 'Reading', 'writing': 'Writing',
    'vocab': 'Vocabulary quizzes', 'phrase': 'Phrases', 'scramble': 'Word order', 'dictation': 'Dictation', 'translate': 'Translation', 'grammar': 'Grammar quizzes'
  };
  A.catOf = (w, r) => w.pos === 'verb' ? 'verb:' + r.key.split('.')[0] : w.pos === 'adj' ? 'adj:forms' : 'noun:' + r.key;
  A.formQuestion = function (w, filter) {
    let rows = A.allRows(w, true).filter(r => r.value && r.key !== 'sg.nom' && r.key !== 'present.0' && r.key !== 'm.sg.nom');
    if (w.pos === 'noun') rows = rows.filter(r => !r.key.endsWith('.voc') || r.key === 'sg.voc');
    if (w.pos === 'adj') rows = rows.filter(r => !r.key.endsWith('.voc'));
    if (w.pos === 'verb') { const tl = (filter && filter.tenses) || A.stageTenses(); rows = rows.filter(r => tl.includes(r.key.split('.')[0])); }
    if (filter && filter.irregularCells) { const ed = rows.filter(r => r.edited); if (ed.length) rows = ed; }
    if (!rows.length) return null;
    const weighted = [];
    rows.forEach(r => {
      const st = A.db.stats.cats[A.catOf(w, r)];
      const acc = st && st.n >= 3 ? st.c / st.n : 0.7;
      const wgt = 1 + (1 - acc) * 4 + (r.edited ? 2 : 0);
      for (let i = 0; i < Math.round(wgt); i++) weighted.push(r);
    });
    const r = A.pick(weighted);
    let prompt;
    if (w.pos === 'verb') { const [t, i] = r.key.split('.'); prompt = { head: w.lemma, detail: `${G.TENSE_LABEL[t]} · ${G.PERSONS[+i]} (${G.PERSON_EN[+i]})` }; }
    else if (w.pos === 'noun' && LANG.code !== 'el') { const [n] = r.key.split('.'); prompt = { head: A.plainHead(w), detail: n === 'pl' ? 'Plural (more than one)' : 'Singular', prefix: n === 'pl' ? G.ARTICLES[A.genderOf(w)].pl[0] : '' }; }
    else if (w.pos === 'adj') { const [g, n, c] = r.key.split('.'); prompt = { head: w.lemma, detail: `${{ m: 'Masculine', f: 'Feminine', n: 'Neuter' }[g]} · ${G.CASE_LABEL[c]} ${n === 'sg' ? 'singular' : 'plural'}` }; }
    else { const [n, c] = r.key.split('.'); prompt = { head: A.plainHead(w), detail: `${G.CASE_LABEL[c]} ${n === 'sg' ? 'singular' : 'plural'}`, prefix: r.prefix }; }
    return { row: r, prompt, cat: A.catOf(w, r), w };
  };
  A.checkAnswer = function (given, expected) {
    const clean = s => G.norm(s).replace(/^θα\s+/, '').replace(/[.,;!?·«»"¿¡]/g, '').replace(/\s+/g, ' ').trim()
      .replace(LANG.pronounInForm ? /^(je |j'|tu |il\/elle |il |elle |nous |vous |ils\/elles |ils |elles )/ : /^$/, '');
    const g = clean(given), e = clean(expected);
    const alts = e.split(/\s*\/\s*/);
    if (alts.includes(g)) return 'right';
    const tail = s => s.split(' ').slice(-1)[0];
    if (alts.some(a => tail(a) === g && a.split(' ').length === 2 && /^(έχω|έχεις|έχει|έχουμε|έχετε|έχουν)$/.test(a.split(' ')[0]))) return 'right';
    if (alts.some(a => G.sameExceptAccent(a, g))) return 'accent';
    if (LANG.code !== 'el' && alts.some(a => G.sameExceptAccent(a.replace(/^(he|has|ha|hemos|habéis|han) /, ''), g))) return 'accent';
    return 'wrong';
  };
  // word-level diff for sentences: returns html of the expected text with missed words marked
  A.diffWords = function (given, expected) {
    const norm = s => G.strip(s).replace(/[.,;!?·«»"]/g, '');
    const have = norm(given).split(/\s+/);
    return expected.split(/\s+/).map(w => have.includes(norm(w)) ? A.esc(w) : `<mark>${A.esc(w)}</mark>`).join(' ');
  };
  A.similarity = function (a, b) {
    const s = G.strip(a).replace(/[^\p{L}\s]/gu, '').trim(), t = G.strip(b).replace(/[^\p{L}\s]/gu, '').trim();
    if (!s.length && !t.length) return 1;
    const m = Array.from({ length: s.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= t.length; j++) m[0][j] = j;
    for (let i = 1; i <= s.length; i++) for (let j = 1; j <= t.length; j++) m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (s[i - 1] === t[j - 1] ? 0 : 1));
    return 1 - m[s.length][t.length] / Math.max(s.length, t.length);
  };

  // ---------- content ----------
  A.parseDict = function () {
    const out = []; let level = 1, topic = '';
    const seen = new Set();
    (window.LANG_DICT_RAW || '').split('\n').forEach(line => {
      line = line.trim(); if (!line) return;
      if (line[0] === '#') { const m = line.match(/^#(\d)\s+(.*)$/); if (m) { level = +m[1]; topic = m[2]; } return; }
      const [lemma, type, meaning, extra] = line.split('|');
      if (seen.has(lemma + '|' + type)) return; seen.add(lemma + '|' + type);
      const e = { lemma, type, meaning, level, topic };
      const isEmoji = extra && !/[\p{L}]/u.test(extra);
      if (isEmoji) e.emoji = extra;
      if (['m', 'f', 'n'].includes(type)) { e.pos = 'noun'; e.gender = type; }
      else if (type === 'v') { e.pos = 'verb'; if (extra && !isEmoji) { if (LANG.code === 'el') { const [ao, fu] = extra.split(';'); e.ov = {}; if (ao) e.ov.aorist = ao; if (fu && !/^θα /.test(fu)) e.ov.future = fu; } else e.ov = { stem: extra }; } }
      else if (type === 'a') e.pos = 'adj';
      else e.pos = 'other';
      e.tag = type;
      out.push(e);
    });
    return out;
  };
  A.dict = A.parseDict();
  A.phrases = (function () {
    const out = []; let topic = '', stage = 1;
    (window.LANG_PHRASES_RAW || '').split('\n').forEach(line => {
      line = line.trim(); if (!line) return;
      if (line[0] === '#') { const m = line.match(/^#(\d)?\s*(.*)$/); stage = m[1] ? +m[1] : 1; topic = m[2]; return; }
      const [gr, en] = line.split('|'); out.push({ gr, en, topic, stage });
    });
    return out;
  })();
  A.grammar = window.LANG_GRAMMAR || [];
  A.readings = window.LANG_READINGS || [];
  A.tips = window.LANG_TIPS || [];

  // dictionary entry → word fields
  A.entryToWord = function (e, extra) {
    const multi = /\s/.test(e.lemma) && LANG.code === 'el';
    const a = G.analyse(e.lemma, { pos: e.pos === 'noun' && multi ? 'other' : e.pos, gender: e.gender || undefined });
    return A.newWord(Object.assign({
      lemma: e.lemma, pos: a.pos, gender: e.gender || a.gender || '', article: e.gender ? A.art(e.lemma, e.gender) : '',
      paradigm: a.paradigm || null, group: a.group || null, meaning: e.meaning, ov: e.ov ? Object.assign({}, e.ov) : {}, emoji: e.emoji || '',
      irregular: !!(e.ov && (e.ov.aorist || e.ov.stem)), tags: e.topic ? [e.topic.split(' ')[0].toLowerCase()] : [], source: 'Dictionary'
    }, extra || {}));
  };

  // ---------- lookup index: any inflected form → entries ----------
  let index = null;
  A.buildIndex = function () {
    if (index) return index;
    index = new Map();
    const add = (form, ref) => {
      form.split(/\s*\/\s*/).forEach(f => {
        const keys = [G.strip(f.replace(/^θα\s+/, '').replace(/^(έχω|έχεις|έχει|έχουμε|έχετε|έχουν)\s+/, ''))];
        if (/\s/.test(f.trim())) keys.push(G.strip(f.trim().split(/\s+/).pop()));
        if (/^j'/.test(f)) keys.push(G.strip(f.slice(2).split(/\s+/)[0]));
        keys.forEach(k => { if (!k) return; const arr = index.get(k) || []; if (!arr.includes(ref)) arr.push(ref); index.set(k, arr); });
      });
    };
    const addWord = (w, ref) => {
      add(w.lemma, ref);
      try { A.allRows(w, true).forEach(r => r.value && add(r.value, ref)); } catch (e) { /* skip */ }
    };
    A.dict.forEach(e => addWord(A.entryToWord(e), { kind: 'dict', e }));
    A.db.words.forEach(w => addWord(w, { kind: 'mine', id: w.id }));
    return index;
  };
  A.resetIndex = () => { index = null; };
  A.lookupForm = function (token) {
    const k = G.strip(token.replace(/[.,;!?·«»"()¿¡]/g, '').replace(/^(l|d|j|m|t|s|n|qu)'/i, ''));
    const idx = A.buildIndex();
    let hits = idx.get(k) || [];
    // try without final apostrophe forms and common clitic contractions
    if (!hits.length && k.length > 3) hits = idx.get(k.replace(/'$/, '')) || [];
    return hits;
  };
  A.searchDict = function (q) {
    const s = G.strip(q.trim());
    if (!s) return [];
    const exact = [], starts = [], contains = [];
    A.dict.forEach(e => {
      const l = G.strip(e.lemma), m = e.meaning.toLowerCase();
      if (l === s) exact.push(e);
      else if (l.startsWith(s)) starts.push(e);
      else if (m.split(/[,;()\s]+/).includes(s) || (s.length > 2 && m.includes(s))) contains.push(e);
    });
    const forms = A.lookupForm(q).filter(h => h.kind === 'dict').map(h => h.e).filter(e => !exact.includes(e));
    return Array.from(new Set(exact.concat(forms, starts, contains))).slice(0, 40);
  };

  // ---------- daily picks ----------
  A.wordsOfDay = function () {
    const rnd = A.seeded(A.dayIndex() * 7919);
    const lv = A.stageLevel();
    const pool = A.stageDict().filter(e => (e.level >= (LANG.audience === 'adult' ? 2 : 1)) && (lv > 50 || e.level >= Math.max(1, lv - 1)) && (e.pos !== 'other' || LANG.audience === 'kid') && !A.findByLemma(e.lemma));
    const pool1 = pool.length >= 3 ? pool : A.dict;
    const out = [];
    for (let i = 0; out.length < 3 && i < 50; i++) { const e = pool1[Math.floor(rnd() * pool1.length)]; if (!out.includes(e)) out.push(e); }
    return out;
  };
  A.stagePhrases = () => A.phrases.filter(p => A.unlocked(p.stage));
  A.phraseOfDay = function () { const sp = A.stagePhrases(); const p0 = sp.filter(x => /Idioms|Feelings|Opinions/.test(x.topic)); const p = p0.length ? p0 : sp; return p[A.dayIndex() % p.length]; };
  A.tipOfDay = () => { const t = A.stageInfo && A.stageInfo.id === 1 ? A.tips.slice(0, 8) : A.tips; return t[A.dayIndex() % t.length]; };
  A.irregularOfDay = function () {
    const v = A.stageDict().filter(e => e.pos === 'verb' && ((e.ov && (e.ov.aorist || e.ov.stem)) || (G.guessVerbGroup(e.lemma) === 'IRR')));
    const e = v[(A.dayIndex() * 3) % (v.length || 1)];
    if (!e) return null;
    let line = '';
    if (LANG.code === 'el') line = e.ov.aorist + (e.ov.future ? ' → θα ' + e.ov.future : '');
    else { const c = G.conjugate(e.lemma, null, e.ov || {}); if (c) { const T = c.tenses, pk = T.preterite ? 'preterite' : 'passe', past = A.stageTenses().includes(pk) ? T[pk] : null; line = past ? [T.present[0], past[0]].join(' → ') : T.present.slice(0, 3).join(', '); } }
    return { lemma: e.lemma, meaning: e.meaning, line };
  };
  A.troubleWords = function () {
    return A.db.words.map(w => ({ w, lapses: Object.values(w.srs).reduce((s, c) => s + (c.lapses || 0), 0), last: Math.max(0, ...Object.values(w.srs).map(c => c.failed || 0)) }))
      .filter(x => x.lapses > 0).sort((a, b) => b.last - a.last || b.lapses - a.lapses).slice(0, 3).map(x => x.w);
  };

  // ---------- speech ----------
  let tts = null;
  // native plugins are registered exactly once and shared (registering the same name twice throws)
  const plugins = {};
  A.plugin = function (name) {
    const cap = window.Capacitor;
    if (!(cap && cap.isNativePlatform && cap.isNativePlatform())) return null;
    if (plugins[name] !== undefined) return plugins[name];
    let p = null;
    try { p = (cap.Plugins && cap.Plugins[name]) || cap.registerPlugin(name); } catch (e) { p = (cap.Plugins && cap.Plugins[name]) || null; }
    plugins[name] = p;
    return p;
  };
  tts = A.plugin('TextToSpeech');
  A.speak = function (text, rate) {
    if (tts) { tts.speak({ text, lang: LANG.tts, rate: rate || 0.9 }).catch(() => web(text, rate)); return; }
    web(text, rate);
  };
  function web(text, rate) {
    try { const u = new SpeechSynthesisUtterance(text); u.lang = LANG.tts; u.rate = rate || 0.9; speechSynthesis.cancel(); speechSynthesis.speak(u); }
    catch (e) { A.toast('Speech is not available on this device'); }
  }
  // open links outside the app (browser, WhatsApp, SMS, email): a normal link click is handed to Android as an intent
  A.openUrl = function (url) {
    const a = document.createElement('a'); a.href = url; a.rel = 'noopener';
    if (!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform())) a.target = '_blank';
    document.body.appendChild(a); a.click(); a.remove();
  };
  A.APK_URL = 'https://raw.githubusercontent.com/jonefti/lexeis-updates/main/apk/Lexeis.apk';

  // ---------- UI helpers ----------
  let toastTimer;
  A.toast = function (msg) {
    const t = A.$('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
  };
  A.sheet = function (html) {
    const s = A.$('#sheet');
    s.innerHTML = `<div class="sheet-backdrop" data-act="sheet-close"></div><div class="sheet-panel" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div>`;
    s.hidden = false;
    requestAnimationFrame(() => s.classList.add('open'));
  };
  A.closeSheet = function () { const s = A.$('#sheet'); s.classList.remove('open'); setTimeout(() => { s.hidden = true; s.innerHTML = ''; }, 200); };
  A.go = h => { if (location.hash === h) A.render(); else location.hash = h; };
  A.view = () => A.$('#view');
  A.ring = function (value, max, size, label) {
    const r = (size - 10) / 2, c = 2 * Math.PI * r, p = Math.min(1, value / max);
    return `<svg class="ring" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img" aria-label="${A.esc(label || '')}">
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" class="ring-bg"/>
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" class="ring-fg" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - p)}" transform="rotate(-90 ${size / 2} ${size / 2})"/></svg>`;
  };
  A.aiReady = () => !!A.global.apiKey;
  A.ask = function (opts) { return window.AI.call(Object.assign({ key: A.global.apiKey, model: A.global.model }, opts)); };
  A.needKeyCard = () => `<div class="callout"><p><strong>Add your Claude API key to use this.</strong> It's free to create; you pay Anthropic only for what you use, usually a few pence a day.</p>
    <ol class="steps"><li>Open console.anthropic.com and sign in.</li><li>Go to API keys → Create key, and add some credit under Billing.</li><li>Paste the key in Settings here.</li></ol>
    <div class="row-btns"><a class="btn primary" href="#/settings">Open Settings</a><button class="btn" data-act="open-url" data-url="https://console.anthropic.com/settings/keys">Get a key</button></div></div>`;

  // tappable text: every Greek word becomes a button that opens the lookup sheet
  A.tappable = function (text) {
    const re = new RegExp(LANG.wordRe.source, 'g');
    let out = '', last = 0, m;
    text = String(text || '');
    while ((m = re.exec(text))) { out += A.esc(text.slice(last, m.index)) + `<button class="tw" data-act="lookup" data-t="${A.esc(m[0])}">${A.esc(m[0])}</button>`; last = m.index + m[0].length; }
    return out + A.esc(text.slice(last));
  };

  // ---------- router ----------
  A.navFor = { today: 'today', words: 'words', dict: 'words', entry: 'words', word: 'words', edit: 'words', add: 'add', inbox: 'today', share: 'today', review: 'today',
    practice: 'practice', flash: 'practice', articles: 'practice', forms: 'practice', scramble: 'practice', dictation: 'practice', translate: 'practice', vocab: 'practice', aitest: 'practice',
    learn: 'learn', grammar: 'learn', lesson: 'learn', phrases: 'learn', reading: 'learn', read: 'learn', writing: 'learn', tutor: 'learn', progress: 'learn', settings: 'learn', backup: 'learn', suggest: 'learn' };
  A.render = function () {
    const h = location.hash || '#/today';
    const parts = h.slice(2).split('/');
    const route = parts[0] || 'today';
    const arg = parts.slice(1).map(decodeURIComponent).join('/');
    A.$$('.nav a').forEach(a => a.classList.toggle('on', a.dataset.nav === (A.navFor[route] || 'today')));
    document.body.dataset.route = route;
    const sh = A.$('#sheet'); if (sh && !sh.hidden) { sh.classList.remove('open'); sh.hidden = true; sh.innerHTML = ''; }
    window.scrollTo(0, 0);
    const fn = A.routes[route] || A.routes.today;
    fn(arg);
  };
})();
