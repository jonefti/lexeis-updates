/* Native phone features: Android back button, reminders (local notifications), text-to-speech checks, speech recognition. */
(function () {
  'use strict';
  const A = window.App, esc = A.esc;
  const cap = window.Capacitor;
  const native = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  const plug = name => A.plugin(name);
  const App = plug('App'), LN = plug('LocalNotifications'), SR = plug('SpeechRecognition'), TTS = plug('TextToSpeech');
  A.isNative = native;

  // ---------- back button ----------
  if (App) {
    App.addListener('backButton', () => {
      if (A.closeCelebration && A.closeCelebration()) return;
      const sh = document.getElementById('sheet');
      if (sh && !sh.hidden) { A.closeSheet(); return; }
      const h = location.hash || '#/today';
      if (h === '#/today' || h === '#/' || h === '') { App.minimizeApp(); return; }
      if (A._navDepth > 0) history.back(); else A.go('#/today');
    });
  }
  // track in-app navigation depth so back never leaves the app by accident
  A._navDepth = 0;
  let lastHash = location.hash;
  window.addEventListener('hashchange', () => {
    if (A._goingBack) { A._goingBack = false; A._navDepth = Math.max(0, A._navDepth - 1); }
    else A._navDepth++;
    lastHash = location.hash;
  });
  const _back = history.back.bind(history);
  history.back = function () { A._goingBack = true; _back(); };
  window.addEventListener('popstate', () => { /* handled in hashchange */ });

  // ---------- reminders ----------
  const DEF = { reminders: false, time: '18:30', streakSaver: true };
  A.remSettings = () => Object.assign({}, DEF, (A.global && A.global.rem) || {});
  const TITLES = {
    el: ['Ώρα για ελληνικά! 🇬🇷', 'Okto σε περιμένει 🐙', 'Πέντε λεπτά ελληνικά;'],
    es: ['¡Hora de español! 🇪🇸', 'Okto te espera 🐙', '¿Cinco minutos de español?'],
    fr: ['C\'est l\'heure du français ! 🇫🇷', 'Okto t\'attend 🐙', 'Cinq minutes de français ?']
  };
  const BODIES = ['Your words are waiting. A quick review keeps them fresh.', 'Five minutes today keeps your streak alive 🔥', 'Can you beat your flash test score today? ⚡', 'Okto has new words of the day for you 🐙', 'Little and often is how words stick.'];
  function at(dayOffset, hhmm) { const [h, m] = hhmm.split(':').map(Number); const d = new Date(A.today() + dayOffset * A.DAY); d.setHours(h, m, 0, 0); return d; }
  A.reschedule = async function () {
    if (!LN) return;
    try {
      const pend = await LN.getPending();
      const ids = (pend.notifications || []).map(n => ({ id: n.id })).filter(n => n.id >= 1000 && n.id < 1300);
      if (ids.length) await LN.cancel({ notifications: ids });
      const r = A.remSettings();
      if (!r.reminders) return;
      const code = A.LANG.code, titles = TITLES[code] || TITLES.el, now = Date.now(), done = A.doneToday && A.doneToday();
      const list = [];
      for (let d = 0; d < 7; d++) {
        if (d === 0 && done) continue;
        const t = at(d, r.time);
        if (t.getTime() > now + 60000) list.push({ id: 1000 + d, title: titles[(A.dayIndex() + d) % titles.length], body: BODIES[(A.dayIndex() + d) % BODIES.length], schedule: { at: t, allowWhileIdle: true }, smallIcon: 'ic_stat_lexeis', iconColor: '#1F4FE0' });
        if (r.streakSaver) {
          const t2 = at(d, '20:45');
          const s = A.streak ? A.streak() : 0;
          if (t2.getTime() > now + 60000 && t2 > t && (d > 0 || !done)) list.push({ id: 1100 + d, title: s >= 2 ? `🔥 Save your ${d === 0 ? s : s + d}-day streak!` : '🔥 Start a streak today!', body: 'Just a few minutes before midnight keeps it going.', schedule: { at: t2, allowWhileIdle: true }, smallIcon: 'ic_stat_lexeis', iconColor: '#E5355B' });
        }
      }
      if (list.length) await LN.schedule({ notifications: list });
    } catch (e) { console.log('reschedule failed', e && e.message); }
  };
  A.enableReminders = async function (on) {
    A.global.rem = Object.assign(A.remSettings(), { reminders: on });
    A.saveGlobal();
    if (on && LN) {
      try {
        let p = await LN.checkPermissions();
        if (p.display !== 'granted') p = await LN.requestPermissions();
        if (p.display !== 'granted') { A.global.rem.reminders = false; A.saveGlobal(); A.toast('Notifications are blocked. Allow them in Android settings → Apps → Λέξεις.'); return false; }
      } catch (e) { /* ignore */ }
    }
    if (on && !LN) A.toast('Reminders work in the installed app');
    await A.reschedule();
    return on;
  };
  A.testReminder = async function () {
    if (!LN) return A.toast('Reminders work in the installed app');
    await A.enableReminders(true);
    await LN.schedule({ notifications: [{ id: 1299, title: (TITLES[A.LANG.code] || TITLES.el)[0], body: 'This is what your reminder looks like 🐙', schedule: { at: new Date(Date.now() + 5000) }, smallIcon: 'ic_stat_lexeis', iconColor: '#1F4FE0' }] });
    A.toast('A test reminder will arrive in 5 seconds');
  };

  // ---------- text to speech ----------
  let ttsChecked = false;
  A.speak = async function (text, rate) {
    if (TTS) {
      try {
        if (!ttsChecked) {
          ttsChecked = true;
          const r = await TTS.isLanguageSupported({ lang: A.LANG.tts }).catch(() => ({ supported: true }));
          if (r && r.supported === false) return voiceHelp();
        }
        await TTS.speak({ text, lang: A.LANG.tts, rate: rate || 0.9, pitch: 1, volume: 1, category: 'ambient' });
        return;
      } catch (e) { return voiceHelp(e && e.message); }
    }
    try { const u = new SpeechSynthesisUtterance(text); u.lang = A.LANG.tts; u.rate = rate || 0.9; speechSynthesis.cancel(); speechSynthesis.speak(u); }
    catch (e) { if (native) voiceHelp('speech engine not found'); else A.toast('Speech is not available in this browser'); }
  };
  function voiceHelp(msg) {
    A.sheet(`<h2>Install the ${esc(A.LANG.name)} voice</h2><p class="muted">Your phone needs a ${esc(A.LANG.name)} voice to read words aloud.${msg ? ' (' + esc(msg) + ')' : ''}</p>
      <ol class="steps"><li>Open Android <b>Settings</b> and search for <b>Text-to-speech</b>.</li><li>Choose <b>Speech Services by Google</b> as the engine, then tap ⚙️ → <b>Install voice data</b>.</li><li>Download <b>${esc(A.LANG.name)}</b>, then come back and tap Listen again.</li></ol>
      <div class="row-btns">${TTS ? '<button class="btn primary" data-act="tts-install">Open voice settings</button>' : ''}<button class="btn ghost" data-act="sheet-close">OK</button></div>`);
    ttsChecked = false;
  }
  A.acts['tts-install'] = async () => { try { await TTS.openInstall(); } catch (e) { A.toast('Open Settings → Text-to-speech manually'); } };

  // ---------- speech recognition ----------
  A.canListen = () => !!SR || !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  A.listen = async function (prompt) {
    if (SR) {
      const av = await SR.available().catch(() => ({ available: false }));
      if (!av.available) throw new Error('Speech recognition isn\'t available. Install or update the Google app.');
      let p = await SR.checkPermissions().catch(() => ({ speechRecognition: 'prompt' }));
      if (p.speechRecognition !== 'granted') p = await SR.requestPermissions();
      if (p.speechRecognition !== 'granted') throw new Error('Allow microphone access to use speaking practice.');
      const r = await SR.start({ language: A.LANG.tts, maxResults: 5, prompt: prompt || 'Speak now', partialResults: false, popup: true });
      return (r && r.matches) || [];
    }
    const W = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!W) throw new Error('Speaking practice works in the installed app.');
    return new Promise((res, rej) => {
      const rec = new W(); rec.lang = A.LANG.tts; rec.maxAlternatives = 5; rec.interimResults = false;
      rec.onresult = e => res(Array.from(e.results[0]).map(x => x.transcript));
      rec.onerror = e => rej(new Error(e.error)); rec.onend = () => res([]);
      rec.start();
    });
  };
  A.bestMatch = function (matches, target) {
    let best = { text: '', score: 0 };
    (matches || []).forEach(m => { const s = A.similarity(m, target); if (s > best.score) best = { text: m, score: s }; });
    return best;
  };

  // ---------- speaking practice ----------
  let spk = null;
  A.routes.speak = function () {
    if (!spk || spk.done) {
      const kid = A.LANG.audience === 'kid';
      const pool = (A.stagePhrases ? A.stagePhrases() : A.phrases).filter(p => p.gr.split(/\s+/).length <= (kid ? 6 : 12));
      const mine = A.db.words.filter(w => w.meaning && w.lemma.length > 1);
      const useWord = mine.length >= 5 && Math.random() < 0.4;
      const w = useWord ? A.pick(mine) : null, p = useWord ? null : A.pick(pool);
      spk = { target: w ? A.plainHead(w) : p.gr, en: w ? w.meaning : p.en, emoji: w && w.emoji, mode: spk ? spk.mode : 'read', done: false, n: spk ? spk.n : 0, right: spk ? spk.right : 0 };
    }
    const s = spk;
    A.view().innerHTML = `<header class="top"><a class="back" href="#/practice">Practice</a><h1>Speak</h1></header>
      <div class="seg"><button class="${s.mode === 'read' ? 'on' : ''}" data-act="spk-mode" data-m="read">Read it out</button><button class="${s.mode === 'recall' ? 'on' : ''}" data-act="spk-mode" data-m="recall">From English</button></div>
      <article class="card speak-card">
        <p class="cue">${s.mode === 'read' ? 'Say this out loud' : 'Say this in ' + esc(A.LANG.name)}</p>
        ${s.emoji ? `<div class="emo big">${s.emoji}</div>` : ''}
        ${s.mode === 'read' ? `<p class="speak-target" lang="${A.LANG.code}">${esc(s.target)}</p><p class="muted">${esc(s.en)}</p>` : `<p class="en-prompt big">${esc(s.en)}</p>`}
        <button class="mic-btn" data-act="spk-go" aria-label="Start speaking">🎙️</button>
        <div class="row-btns center"><button class="btn sm" data-act="speak" data-t="${esc(s.target)}">🔊 Hear it</button><button class="btn sm ghost" data-act="spk-next">Skip</button></div>
        <div class="answer" id="spkRes" hidden></div>
      </article>
      ${s.n ? `<p class="flash-score">${s.right} / ${s.n} said well</p>` : ''}`;
  };
  A.acts['spk-mode'] = el => { spk.mode = el.dataset.m; A.routes.speak(); };
  A.acts['spk-next'] = () => { spk.done = true; A.routes.speak(); };
  A.acts['spk-go'] = async function () {
    const box = A.$('#spkRes'); box.hidden = false; box.innerHTML = '<p class="muted thinking">Listening…</p>';
    try {
      const m = await A.listen(spk.mode === 'read' ? spk.target : spk.en);
      const b = A.bestMatch(m, spk.target);
      const pct = Math.round(b.score * 100), ok = b.score >= 0.8;
      spk.n++; if (ok) spk.right++;
      A.db.stats.spoken = (A.db.stats.spoken || 0) + 1;
      A.recordCat('speaking', ok); A.xp(ok ? 3 : 1); A.save();
      box.innerHTML = `<p class="verdict ${ok ? 'ok' : b.score > 0.55 ? 'mid' : 'bad'}">${ok ? pick(['Perfect! 🎉', 'Great pronunciation!', 'Spot on!']) : b.score > 0.55 ? 'Close! Try again' : 'Not quite. Listen and try again'} · ${pct}%</p>
        <p class="tiny">I heard: <b lang="${A.LANG.code}">${esc(b.text || '…')}</b></p>${!ok ? `<p class="card-ex" lang="${A.LANG.code}">${A.diffWords(b.text, spk.target)}</p>` : ''}
        <div class="row-btns"><button class="btn primary" data-act="spk-next">Next</button>${!ok ? '<button class="btn" data-act="spk-go">Try again</button>' : ''}</div>`;
    } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message || 'Could not hear you. Try again.')}</p>`; }
  };
  const pick = a => a[Math.floor(Math.random() * a.length)];
  A.navFor.speak = 'practice';

  // mic for typed answers and chat: fills the nearest text box
  A.acts['mic-fill'] = async function (el) {
    const box = el.closest('form').querySelector('input[name], textarea');
    try { const m = await A.listen(); if (m[0]) { box.value = m[0]; box.dispatchEvent(new Event('input', { bubbles: true })); box.focus(); A.db.stats.spoken = (A.db.stats.spoken || 0) + 1; A.save(); } }
    catch (e) { A.toast(e.message); }
  };

  if (native) setTimeout(() => A.reschedule && A.reschedule(), 3000);
})();
