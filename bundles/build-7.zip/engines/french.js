/* French grammar engine (beginner level): gender, plurals, adjective agreement, common tenses. Same interface as greek.js. */
(function (global) {
  'use strict';
  const lower = s => (s || '').toLocaleLowerCase('fr').replace(/’/g, "'");
  const strip = s => lower(s).replace(/œ/g, 'oe').replace(/æ/g, 'ae').normalize('NFD').replace(/[̀-ͯ]/g, '');
  const norm = s => lower(s).trim().replace(/\s+/g, ' ');
  const sameExceptAccent = (a, b) => strip(a) === strip(b);
  const vowelStart = w => /^[aeiouyhàâéèêëîïôûœ]/i.test(w) && !/^(haricot|héros|hibou|homard|hamster|hockey|huit|haut|hache|honte|hâte)/i.test(w);

  // ---------- nouns ----------
  const ARTICLES = { m: { sg: ['le'], pl: ['les'] }, f: { sg: ['la'], pl: ['les'] } };
  const CASES = ['nom'];
  const CASE_LABEL = { nom: 'Form' };
  const G_TO_ART = { m: 'le', f: 'la' };
  const ART_TO_G = { le: 'm', la: 'f', un: 'm', une: 'f' };
  const GENDERS = ['m', 'f'];
  const art = (lemma, g) => (vowelStart(lemma) ? "l'" : G_TO_ART[g] || '');
  const IRR_PL = { œil: 'yeux', ciel: 'cieux', madame: 'mesdames', monsieur: 'messieurs', bijou: 'bijoux', caillou: 'cailloux', chou: 'choux', genou: 'genoux', hibou: 'hiboux', jouet: 'jouets', pneu: 'pneus', bleu: 'bleus' };
  function plural(w) {
    const l = lower(w).trim();
    if (IRR_PL[l]) return IRR_PL[l];
    if (/\s/.test(l)) { const [h, ...t] = l.split(' '); return plural(h) + ' ' + t.join(' '); }
    if (/[sxz]$/.test(l)) return l;
    if (/(eau|au|eu)$/.test(l)) return l + 'x';
    if (/al$/.test(l) && !['bal', 'festival', 'carnaval', 'chacal', 'récital'].includes(l)) return l.slice(0, -2) + 'aux';
    return l + 's';
  }
  const PARADIGMS = { m: { g: 'm', label: 'le / un (masculine)' }, f: { g: 'f', label: 'la / une (feminine)' } };
  function guessNoun(lemma, gender) {
    const l = lower(lemma);
    let g = 'm', conf = 'mid';
    if (/(aison|chanson|leçon)$/.test(l)) { g = 'f'; conf = 'high'; }
    else if (/(tion|sion|té|ette|ure|ance|ence|ade|ie|ée|ise|elle|esse|ine|ière|eur)$/.test(l) && !/(eur)$/.test(l)) { g = 'f'; conf = 'high'; }
    else if (/(ment|age|eau|isme|ier|et|on|oir|ail|eil|eur)$/.test(l)) { g = 'm'; conf = 'high'; }
    else if (/e$/.test(l)) { g = 'f'; conf = 'low'; }
    if (gender) { if (gender !== g) conf = 'low'; g = gender; }
    return { key: g, gender: g, conf };
  }
  function declineWith(lemma) { return { 'sg.nom': lower(lemma), 'pl.nom': plural(lemma) }; }

  // ---------- adjectives ----------
  const ADJ_F = { beau: 'belle', nouveau: 'nouvelle', vieux: 'vieille', blanc: 'blanche', long: 'longue', gentil: 'gentille', gros: 'grosse', bas: 'basse', fou: 'folle', doux: 'douce', faux: 'fausse', frais: 'fraîche', sec: 'sèche', grec: 'grecque', public: 'publique', favori: 'favorite', roux: 'rousse' };
  function fem(l) {
    if (ADJ_F[l]) return ADJ_F[l];
    if (/e$/.test(l)) return l;
    if (/eux$/.test(l)) return l.slice(0, -1) + 'se';
    if (/if$/.test(l)) return l.slice(0, -1) + 've';
    if (/er$/.test(l)) return l.slice(0, -2) + 'ère';
    if (/(on|el|en|il)$/.test(l)) return l + l.slice(-1) + 'e';
    if (/et$/.test(l)) return l + 'te';
    if (/eur$/.test(l)) return l.slice(0, -1) + 'se';
    return l + 'e';
  }
  const INV = ['marron', 'orange', 'super', 'cool', 'chic', 'sympa'];
  function declineAdj(lemma) {
    const l = lower(lemma);
    if (INV.includes(l)) return { m: { 'sg.nom': l, 'pl.nom': l }, f: { 'sg.nom': l, 'pl.nom': l } };
    const f = fem(l);
    const mp = l === 'beau' ? 'beaux' : l === 'nouveau' ? 'nouveaux' : /(s|x)$/.test(l) ? l : /al$/.test(l) ? l.slice(0, -2) + 'aux' : l + 's';
    return { m: { 'sg.nom': l, 'pl.nom': mp }, f: { 'sg.nom': f, 'pl.nom': f + 's' } };
  }

  // ---------- verbs ----------
  const PERSONS = ['je', 'tu', 'il/elle', 'nous', 'vous', 'ils/elles'];
  const PERSON_EN = ['I', 'you', 'he/she', 'we', 'you (all/polite)', 'they'];
  const GROUPS = { ER: '-er (parler)', IR: '-ir (finir)', RE: '-re (vendre)', IRR: 'Irregular' };
  const TENSES = ['present', 'passe', 'futproche', 'imparfait', 'future', 'imperative'];
  const TENSE_LABEL = { present: 'Present', passe: 'Passé composé (past)', futproche: 'Near future (aller + …)', imparfait: 'Imparfait (was / used to)', future: 'Future', imperative: 'Commands' };
  const AVOIR = ['ai', 'as', 'a', 'avons', 'avez', 'ont'], ETRE = ['suis', 'es', 'est', 'sommes', 'êtes', 'sont'], ALLER = ['vais', 'vas', 'va', 'allons', 'allez', 'vont'];
  const IRR = {
    être: { present: ETRE, pp: 'été', fut: 'ser', imp: 'ét', impv: ['sois', 'soyez'] },
    avoir: { present: AVOIR, pp: 'eu', fut: 'aur', impv: ['aie', 'ayez'] },
    aller: { present: ALLER, pp: 'allé', fut: 'ir', etre: true, impv: ['va', 'allez'] },
    faire: { present: ['fais', 'fais', 'fait', 'faisons', 'faites', 'font'], pp: 'fait', fut: 'fer' },
    dire: { present: ['dis', 'dis', 'dit', 'disons', 'dites', 'disent'], pp: 'dit' },
    venir: { present: ['viens', 'viens', 'vient', 'venons', 'venez', 'viennent'], pp: 'venu', fut: 'viendr', etre: true },
    devenir: { present: ['deviens', 'deviens', 'devient', 'devenons', 'devenez', 'deviennent'], pp: 'devenu', fut: 'deviendr', etre: true },
    prendre: { present: ['prends', 'prends', 'prend', 'prenons', 'prenez', 'prennent'], pp: 'pris' },
    apprendre: { present: ['apprends', 'apprends', 'apprend', 'apprenons', 'apprenez', 'apprennent'], pp: 'appris' },
    comprendre: { present: ['comprends', 'comprends', 'comprend', 'comprenons', 'comprenez', 'comprennent'], pp: 'compris' },
    pouvoir: { present: ['peux', 'peux', 'peut', 'pouvons', 'pouvez', 'peuvent'], pp: 'pu', fut: 'pourr' },
    vouloir: { present: ['veux', 'veux', 'veut', 'voulons', 'voulez', 'veulent'], pp: 'voulu', fut: 'voudr' },
    devoir: { present: ['dois', 'dois', 'doit', 'devons', 'devez', 'doivent'], pp: 'dû', fut: 'devr' },
    savoir: { present: ['sais', 'sais', 'sait', 'savons', 'savez', 'savent'], pp: 'su', fut: 'saur' },
    voir: { present: ['vois', 'vois', 'voit', 'voyons', 'voyez', 'voient'], pp: 'vu', fut: 'verr' },
    mettre: { present: ['mets', 'mets', 'met', 'mettons', 'mettez', 'mettent'], pp: 'mis' },
    lire: { present: ['lis', 'lis', 'lit', 'lisons', 'lisez', 'lisent'], pp: 'lu' },
    écrire: { present: ['écris', 'écris', 'écrit', 'écrivons', 'écrivez', 'écrivent'], pp: 'écrit' },
    boire: { present: ['bois', 'bois', 'boit', 'buvons', 'buvez', 'boivent'], pp: 'bu' },
    dormir: { present: ['dors', 'dors', 'dort', 'dormons', 'dormez', 'dorment'], pp: 'dormi' },
    partir: { present: ['pars', 'pars', 'part', 'partons', 'partez', 'partent'], pp: 'parti', etre: true },
    sortir: { present: ['sors', 'sors', 'sort', 'sortons', 'sortez', 'sortent'], pp: 'sorti', etre: true },
    courir: { present: ['cours', 'cours', 'court', 'courons', 'courez', 'courent'], pp: 'couru', fut: 'courr' },
    ouvrir: { present: ['ouvre', 'ouvres', 'ouvre', 'ouvrons', 'ouvrez', 'ouvrent'], pp: 'ouvert' },
    connaître: { present: ['connais', 'connais', 'connaît', 'connaissons', 'connaissez', 'connaissent'], pp: 'connu' },
    croire: { present: ['crois', 'crois', 'croit', 'croyons', 'croyez', 'croient'], pp: 'cru' },
    recevoir: { present: ['reçois', 'reçois', 'reçoit', 'recevons', 'recevez', 'reçoivent'], pp: 'reçu', fut: 'recevr' },
    envoyer: { present: ['envoie', 'envoies', 'envoie', 'envoyons', 'envoyez', 'envoient'], pp: 'envoyé', fut: 'enverr' },
    acheter: { present: ['achète', 'achètes', 'achète', 'achetons', 'achetez', 'achètent'], fut: 'achèter' },
    appeler: { present: ['appelle', 'appelles', 'appelle', 'appelons', 'appelez', 'appellent'], fut: 'appeller' },
    préférer: { present: ['préfère', 'préfères', 'préfère', 'préférons', 'préférez', 'préfèrent'] },
    naître: { present: ['nais', 'nais', 'naît', 'naissons', 'naissez', 'naissent'], pp: 'né', etre: true },
    mourir: { present: ['meurs', 'meurs', 'meurt', 'mourons', 'mourez', 'meurent'], pp: 'mort', fut: 'mourr', etre: true }
  };
  const ETRE_VERBS = ['arriver', 'rester', 'tomber', 'entrer', 'rentrer', 'monter', 'descendre', 'retourner', 'revenir', 'passer'];

  function guessVerbGroup(lemma) {
    const l = lower(lemma).replace(/^(se |s')/, '');
    if (IRR[l]) return 'IRR';
    if (l.endsWith('er')) return 'ER';
    if (l.endsWith('ir')) return 'IR';
    if (l.endsWith('re')) return 'RE';
    return null;
  }
  const elide = (p, f) => p === 'je' && /^[aeiouyhéèêàâîôû]/i.test(f) ? "j'" + f : p + ' ' + f;

  function conjugate(lemma, grp, ov) {
    const raw = lower(lemma).trim();
    const refl = /^(se |s')/.test(raw);
    const inf = raw.replace(/^(se |s')/, '');
    const irr = IRR[inf] || {};
    const g = (grp && grp !== 'IRR') ? grp : inf.endsWith('er') ? 'ER' : inf.endsWith('ir') ? 'IR' : inf.endsWith('re') ? 'RE' : null;
    if (!g) return null;
    const stem = inf.slice(0, -2);
    let pres;
    if (irr.present) pres = irr.present.slice();
    else if (g === 'ER') {
      pres = ['e', 'es', 'e', 'ons', 'ez', 'ent'].map(e => stem + e);
      if (/g$/.test(stem)) pres[3] = stem + 'eons';
      if (/c$/.test(stem)) pres[3] = stem.slice(0, -1) + 'çons';
    } else if (g === 'IR') pres = ['is', 'is', 'it', 'issons', 'issez', 'issent'].map(e => stem + e);
    else pres = ['s', 's', '', 'ons', 'ez', 'ent'].map(e => stem + e);
    const pp = irr.pp || (g === 'ER' ? stem + 'é' : g === 'IR' ? stem + 'i' : stem + 'u');
    const etre = irr.etre || ETRE_VERBS.includes(inf) || refl;
    const ppShow = etre ? [pp + '(e)', pp + '(e)', pp + '(e)', pp + '(e)s', pp + '(e)s', pp + '(e)s'] : Array(6).fill(pp);
    const nousStem = irr.imp || pres[3].replace(/ons$/, '');
    const fs = irr.fut || (g === 'RE' ? inf.slice(0, -1) : inf);
    const REF = ['me', 'te', 'se', 'nous', 'vous', 'se'];
    const withRef = (i, f) => refl ? ((/^[aeiouyhéèêàâîôû]/i.test(f) && i !== 3 && i !== 4) ? REF[i].slice(0, 1) + "'" + f : REF[i] + ' ' + f) : f;
    const T = {
      present: pres.map((f, i) => elide(PERSONS[i].split('/')[0], withRef(i, f))),
      passe: (etre ? ETRE : AVOIR).map((a, i) => elide(PERSONS[i].split('/')[0], withRef(i, a) + ' ' + ppShow[i])),
      futproche: ALLER.map((a, i) => elide(PERSONS[i].split('/')[0], a + ' ' + (refl ? REF[i] + ' ' : '') + inf)),
      imparfait: ['ais', 'ais', 'ait', 'ions', 'iez', 'aient'].map((e, i) => elide(PERSONS[i].split('/')[0], withRef(i, nousStem + e))),
      future: ['ai', 'as', 'a', 'ons', 'ez', 'ont'].map((e, i) => elide(PERSONS[i].split('/')[0], withRef(i, fs + e)))
    };
    const iv = irr.impv || [g === 'ER' ? pres[0] : pres[1], pres[4]];
    T.imperative = ['', iv[0] + (refl ? '-toi' : ''), '', '', iv[1] + (refl ? '-vous' : ''), ''];
    return { group: irr.present ? 'IRR' : g, tenses: T, conf: irr.present ? { irregular: true } : {}, participle: pp };
  }

  function splitArticle(input) {
    const t = (input || '').trim().replace(/\s+/g, ' ').replace(/’/g, "'");
    let m = t.match(/^(le|la|les|un|une)\s+(.+)$/i);
    if (m) return { article: lower(m[1]), word: m[2] };
    m = t.match(/^l'(.+)$/i);
    if (m) return { article: "l'", word: m[1] };
    return { article: '', word: t };
  }
  function analyse(input, opts) {
    opts = opts || {};
    const { article, word } = splitArticle(input);
    const w = word.trim(), l = lower(w);
    let pos = opts.pos;
    if (!pos) {
      if (article) pos = 'noun';
      else if (/^(se |s')?\S+(er|ir|re)$/.test(l) && !/\s/.test(l.replace(/^(se |s')/, ''))) pos = 'verb';
      else if (!/\s/.test(w)) pos = 'noun';
      else pos = 'other';
    }
    const res = { lemma: w, article, pos };
    if (pos === 'noun') { const gn = guessNoun(w, opts.gender || ART_TO_G[article]); Object.assign(res, { gender: gn.gender, paradigm: opts.paradigm || gn.key, conf: article && article !== "l'" ? 'high' : gn.conf }); }
    if (pos === 'verb') res.group = opts.group || guessVerbGroup(w);
    return res;
  }

  global.French = { strip, lower, norm, sameExceptAccent, splitArticle, guessNoun, declineWith, declineAdj, guessVerbGroup, conjugate, analyse, plural, art,
    PARADIGMS, ARTICLES, CASES, CASE_LABEL, G_TO_ART, ART_TO_G, GENDERS, PERSONS, PERSON_EN, GROUPS, TENSES, TENSE_LABEL };
})(typeof window !== 'undefined' ? window : globalThis);
