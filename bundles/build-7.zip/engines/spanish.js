/* Spanish grammar engine: gender, plurals, adjective agreement, verb conjugation. Same interface as greek.js. */
(function (global) {
  'use strict';
  const lower = s => (s || '').toLocaleLowerCase('es');
  const strip = s => lower(s).replace(/ñ/g, '\u0001').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\u0001/g, 'ñ');
  const norm = s => lower(s).trim().replace(/\s+/g, ' ');
  const sameExceptAccent = (a, b) => strip(a) === strip(b);
  const ACC = { a: 'á', e: 'é', i: 'í', o: 'ó', u: 'ú' };
  const unacc = s => s.replace(/[áéíóú]/g, c => ({ á: 'a', é: 'e', í: 'i', ó: 'o', ú: 'u' }[c]));
  const VOW = 'aeiouáéíóú';

  // ---------- nouns ----------
  const ARTICLES = { m: { sg: ['el'], pl: ['los'] }, f: { sg: ['la'], pl: ['las'] } };
  const CASES = ['nom'];
  const CASE_LABEL = { nom: 'Form' };
  const G_TO_ART = { m: 'el', f: 'la' };
  const ART_TO_G = { el: 'm', la: 'f', los: 'm', las: 'f', un: 'm', una: 'f' };
  const GENDERS = ['m', 'f'];
  const EL_FEM = ['agua', 'águila', 'alma', 'arma', 'hambre', 'área', 'aula', 'hacha', 'hada'];
  const art = (lemma, g) => g === 'f' && EL_FEM.includes(lower(lemma)) ? 'el' : G_TO_ART[g] || '';
  const M_A = ['problema', 'tema', 'sistema', 'idioma', 'programa', 'clima', 'mapa', 'día', 'planeta', 'drama', 'poema', 'sofá', 'esquema', 'dilema', 'pijama'];
  const F_O = ['mano', 'foto', 'moto', 'radio', 'radio'];

  function plural(w) {
    const l = lower(w).trim();
    if (/\s/.test(l)) { const [h, ...t] = l.split(' '); return plural(h) + ' ' + t.join(' '); }
    if (/[sx]$/.test(l) && !/[áéíóú]s$/.test(l) && l.length > 3 && /(is|es|us|as)$/.test(l) && !/(és|ás|ís|ós|ús)$/.test(l)) return l; // lunes, crisis
    if (/z$/.test(l)) return l.slice(0, -1) + 'ces';
    if (/(ión)$/.test(l)) return l.slice(0, -3) + 'iones';
    if (/[áéíóú][ns]$/.test(l)) return unacc(l) + 'es';
    if (/[aeiouáéó]$/.test(l)) return l + 's';
    if (/[íú]$/.test(l)) return l + 'es';
    return l + 'es';
  }
  const PARADIGMS = {
    'm-o': { g: 'm', label: 'el … -o (el libro, los libros)' },
    'f-a': { g: 'f', label: 'la … -a (la casa, las casas)' },
    'm': { g: 'm', label: 'el … (other endings)' },
    'f': { g: 'f', label: 'la … (other endings)' }
  };
  function guessNoun(lemma, gender) {
    const l = lower(lemma);
    let g = '', conf = 'high';
    if (M_A.includes(l)) g = 'm';
    else if (F_O.includes(l)) g = 'f';
    else if (/(ción|sión|dad|tad|tud|umbre|ez|triz|sis|itis)$/.test(l)) g = 'f';
    else if (/a$/.test(l)) g = 'f';
    else if (/(o|or|aje|án|ón|ma)$/.test(l)) { g = 'm'; conf = /ma$/.test(l) ? 'mid' : 'high'; }
    else { g = 'm'; conf = 'mid'; }
    if (gender) { if (gender !== g) conf = 'low'; g = gender; }
    const key = g === 'm' ? (/o$/.test(l) ? 'm-o' : 'm') : (/a$/.test(l) ? 'f-a' : 'f');
    return { key, gender: g, conf };
  }
  function declineWith(lemma) { return { 'sg.nom': lower(lemma), 'pl.nom': plural(lemma) }; }

  // ---------- adjectives ----------
  const ADJ_INV = ['azul', 'verde', 'gris', 'feliz', 'fácil', 'difícil', 'joven', 'mayor', 'menor', 'mejor', 'peor', 'útil', 'genial', 'normal', 'especial', 'importante', 'grande', 'alegre', 'triste', 'interesante', 'inteligente', 'fuerte', 'caliente'];
  function declineAdj(lemma) {
    const l = lower(lemma);
    let f;
    if (/o$/.test(l)) f = l.slice(0, -1) + 'a';
    else if (/(és)$/.test(l)) f = l.slice(0, -2) + 'esa';
    else if (/(or|ón|ín|án)$/.test(l) && !ADJ_INV.includes(l)) f = unacc(l) + 'a';
    else f = l;
    const m = { 'sg.nom': l, 'pl.nom': plural(l) }, fe = { 'sg.nom': f, 'pl.nom': plural(f) };
    return { m, f: fe };
  }

  // ---------- verbs ----------
  const PERSONS = ['yo', 'tú', 'él/ella', 'nosotros', 'vosotros', 'ellos/ellas'];
  const PERSON_EN = ['I', 'you', 'he/she/you formal', 'we', 'you all', 'they'];
  const GROUPS = { AR: '-ar (hablar)', ER: '-er (comer)', IR: '-ir (vivir)', IRR: 'Irregular' };
  const TENSES = ['present', 'preterite', 'imperfect', 'future', 'conditional', 'perfect', 'imperative'];
  const TENSE_LABEL = { present: 'Present', preterite: 'Preterite (simple past)', imperfect: 'Imperfect (used to / was -ing)', future: 'Future', conditional: 'Conditional (would)', perfect: 'Present perfect (he + …)', imperative: 'Commands' };
  const HABER = ['he', 'has', 'ha', 'hemos', 'habéis', 'han'];
  const IRR = {
    ser: { present: ['soy', 'eres', 'es', 'somos', 'sois', 'son'], preterite: ['fui', 'fuiste', 'fue', 'fuimos', 'fuisteis', 'fueron'], imperfect: ['era', 'eras', 'era', 'éramos', 'erais', 'eran'], imp: ['sé', 'sed'] },
    ir: { present: ['voy', 'vas', 'va', 'vamos', 'vais', 'van'], preterite: ['fui', 'fuiste', 'fue', 'fuimos', 'fuisteis', 'fueron'], imperfect: ['iba', 'ibas', 'iba', 'íbamos', 'ibais', 'iban'], imp: ['ve', 'id'] },
    estar: { present: ['estoy', 'estás', 'está', 'estamos', 'estáis', 'están'], pret: 'estuv' },
    haber: { present: ['he', 'has', 'ha', 'hemos', 'habéis', 'han'], pret: 'hub', fut: 'habr' },
    dar: { present: ['doy', 'das', 'da', 'damos', 'dais', 'dan'], preterite: ['di', 'diste', 'dio', 'dimos', 'disteis', 'dieron'] },
    ver: { present: ['veo', 'ves', 've', 'vemos', 'veis', 'ven'], preterite: ['vi', 'viste', 'vio', 'vimos', 'visteis', 'vieron'], imperfect: ['veía', 'veías', 'veía', 'veíamos', 'veíais', 'veían'], pp: 'visto' },
    oír: { present: ['oigo', 'oyes', 'oye', 'oímos', 'oís', 'oyen'] },
    saber: { yo: 'sé', pret: 'sup', fut: 'sabr' },
    tener: { yo: 'tengo', pret: 'tuv', fut: 'tendr', imp: ['ten', 'tened'] },
    venir: { yo: 'vengo', pret: 'vin', fut: 'vendr', imp: ['ven', 'venid'] },
    poner: { yo: 'pongo', pret: 'pus', fut: 'pondr', pp: 'puesto', imp: ['pon', 'poned'] },
    salir: { yo: 'salgo', fut: 'saldr', imp: ['sal', 'salid'] },
    hacer: { yo: 'hago', pret: 'hic', fut: 'har', pp: 'hecho', imp: ['haz', 'haced'] },
    decir: { yo: 'digo', pret: 'dij', fut: 'dir', pp: 'dicho', imp: ['di', 'decid'] },
    traer: { yo: 'traigo', pret: 'traj' },
    caer: { yo: 'caigo' },
    poder: { pret: 'pud', fut: 'podr' },
    querer: { pret: 'quis', fut: 'querr' },
    andar: { pret: 'anduv' },
    conducir: { yo: 'conduzco', pret: 'conduj' },
    caber: { yo: 'quepo', pret: 'cup', fut: 'cabr' },
    escribir: { pp: 'escrito' }, abrir: { pp: 'abierto' }, volver: { pp: 'vuelto' }, romper: { pp: 'roto' }, morir: { pp: 'muerto' },
    cubrir: { pp: 'cubierto' }, descubrir: { pp: 'descubierto' }, devolver: { pp: 'devuelto' }, resolver: { pp: 'resuelto' }, freír: { pp: 'frito' }
  };
  // common stem-changers when the dictionary doesn't say
  const STEM = { pensar: 'ie', empezar: 'ie', comenzar: 'ie', cerrar: 'ie', despertar: 'ie', sentar: 'ie', querer: 'ie', entender: 'ie', perder: 'ie', preferir: 'ie', sentir: 'ie', mentir: 'ie', tener: 'ie', venir: 'ie', nevar: 'ie', recomendar: 'ie', divertir: 'ie',
    poder: 'ue', volver: 'ue', dormir: 'ue', morir: 'ue', contar: 'ue', costar: 'ue', encontrar: 'ue', recordar: 'ue', mostrar: 'ue', soñar: 'ue', almorzar: 'ue', llover: 'ue', mover: 'ue', probar: 'ue', acostar: 'ue', devolver: 'ue', resolver: 'ue', jugar: 'ue',
    pedir: 'i', servir: 'i', repetir: 'i', seguir: 'i', vestir: 'i', decir: 'i', elegir: 'i', reír: 'i', sonreír: 'i' };

  function guessVerbGroup(lemma) {
    const l = strip(lemma).replace(/se$/, '');
    if (IRR[lower(lemma).replace(/se$/, '')] && IRR[lower(lemma).replace(/se$/, '')].present) return 'IRR';
    if (l.endsWith('ar')) return 'AR'; if (l.endsWith('er')) return 'ER'; if (l.endsWith('ir')) return 'IR';
    return null;
  }
  function changeStem(stem, code) {
    if (!code) return stem;
    const from = code === 'ue' ? (stem.includes('o') ? 'o' : 'u') : 'e';
    const to = code === 'ie' ? 'ie' : code === 'ue' ? 'ue' : 'i';
    const i = stem.lastIndexOf(from);
    if (i < 0) return stem;
    return stem.slice(0, i) + to + stem.slice(i + 1);
  }
  function pretStem3(stem, code, grp) { // -ir stem changers: e→i, o→u in 3rd persons of preterite
    if (grp !== 'IR' || !code) return stem;
    const from = code === 'ue' ? 'o' : 'e', to = code === 'ue' ? 'u' : 'i';
    const i = stem.lastIndexOf(from); return i < 0 ? stem : stem.slice(0, i) + to + stem.slice(i + 1);
  }

  function conjugate(lemma, grp, ov) {
    ov = ov || {};
    const inf0 = lower(lemma).trim();
    const refl = /se$/.test(inf0) && inf0.length > 4;
    const inf = refl ? inf0.slice(0, -2) : inf0;
    const irr = IRR[inf] || {};
    const g = (grp && grp !== 'IRR') ? grp : (strip(inf).endsWith('ar') ? 'AR' : strip(inf).endsWith('er') ? 'ER' : strip(inf).endsWith('ir') ? 'IR' : null);
    if (!g) return null;
    const stem = inf.slice(0, -2);
    const code = ov.stem || STEM[inf] || '';
    const T = {}, conf = {};
    // present
    const PE = { AR: ['o', 'as', 'a', 'amos', 'áis', 'an'], ER: ['o', 'es', 'e', 'emos', 'éis', 'en'], IR: ['o', 'es', 'e', 'imos', 'ís', 'en'] }[g];
    if (irr.present) T.present = irr.present.slice();
    else {
      T.present = PE.map((e, i) => (i === 3 || i === 4 ? stem : changeStem(stem, code)) + e);
      if (irr.yo) T.present[0] = irr.yo;
      else if (/[aeiou]c(er|ir)$/.test(inf) && !['hacer', 'decir', 'mecer'].includes(inf)) T.present[0] = stem.slice(0, -1) + 'zco';
      else if (/g(er|ir)$/.test(inf)) T.present[0] = changeStem(stem, code).slice(0, -1) + 'jo';
      else if (/gu(ir)$/.test(inf)) T.present[0] = changeStem(stem, code).slice(0, -1) + 'o';
      if (/uir$/.test(inf) && !/guir$/.test(inf)) T.present = T.present.map((f, i) => i === 3 || i === 4 ? f : f.replace(/u(?=[oae])/, 'uy'));
    }
    // preterite
    if (irr.preterite) T.preterite = irr.preterite.slice();
    else if (irr.pret) {
      const s = irr.pret, j = /j$/.test(s);
      T.preterite = ['e', 'iste', 'o', 'imos', 'isteis', j ? 'eron' : 'ieron'].map(e => s + e);
      if (inf === 'hacer') T.preterite[2] = 'hizo';
    } else {
      let E = g === 'AR' ? ['é', 'aste', 'ó', 'amos', 'asteis', 'aron'] : ['í', 'iste', 'ió', 'imos', 'isteis', 'ieron'];
      const vowelStem = g !== 'AR' && /[aeo]$/.test(stem);
      if (vowelStem) E = ['í', 'íste', 'yó', 'ímos', 'ísteis', 'yeron'];
      if (/uir$/.test(inf) && !/guir$/.test(inf)) E = ['í', 'iste', 'yó', 'imos', 'isteis', 'yeron'];
      T.preterite = E.map((e, i) => ((i === 2 || i === 5) ? pretStem3(stem, code, g) : stem) + e);
      if (g === 'AR') { const yo = stem + 'é'; T.preterite[0] = yo.replace(/cé$/, 'qué').replace(/gé$/, 'gué').replace(/zé$/, 'cé'); }
    }
    // imperfect
    T.imperfect = irr.imperfect ? irr.imperfect.slice() : (g === 'AR' ? ['aba', 'abas', 'aba', 'ábamos', 'abais', 'aban'] : ['ía', 'ías', 'ía', 'íamos', 'íais', 'ían']).map(e => stem + e);
    // future & conditional
    const fs = irr.fut || unacc(inf);
    T.future = ['é', 'ás', 'á', 'emos', 'éis', 'án'].map(e => fs + e);
    T.conditional = ['ía', 'ías', 'ía', 'íamos', 'íais', 'ían'].map(e => fs + e);
    // perfect
    const pp = irr.pp || (g === 'AR' ? stem + 'ado' : (/[aeo]$/.test(stem) ? stem + 'ído' : stem + 'ido'));
    T.perfect = HABER.map(h => h + ' ' + pp);
    // imperative tú / vosotros
    const tu = irr.imp ? irr.imp[0] : T.present[2];
    const vos = irr.imp ? irr.imp[1] : inf.slice(0, -1) + 'd';
    T.imperative = ['', tu, '', '', vos, ''];
    if (refl) {
      const P = ['me', 'te', 'se', 'nos', 'os', 'se'];
      ['present', 'preterite', 'imperfect', 'future', 'conditional', 'perfect'].forEach(t => { T[t] = T[t].map((f, i) => P[i] + ' ' + f); });
      T.imperative = ['', '', '', '', '', ''];
      T.present[0] = 'me ' + T.present[0].replace(/^me /, '');
    }
    if (code || irr.yo || irr.pret || irr.preterite || irr.present) conf.irregular = true;
    return { group: irr.present ? 'IRR' : g, tenses: T, conf, participle: pp };
  }

  function splitArticle(input) {
    const t = (input || '').trim().replace(/\s+/g, ' ');
    const m = t.match(/^(el|la|los|las|un|una)\s+(.+)$/i);
    return m ? { article: lower(m[1]), word: m[2] } : { article: '', word: t };
  }
  function analyse(input, opts) {
    opts = opts || {};
    const { article, word } = splitArticle(input);
    const w = word.trim(), l = lower(w);
    let pos = opts.pos;
    if (!pos) {
      if (article) pos = 'noun';
      else if (!/\s/.test(w) && /(ar|er|ir|arse|erse|irse)$/.test(strip(l))) pos = 'verb';
      else if (!/\s/.test(w)) pos = 'noun';
      else pos = 'other';
    }
    const res = { lemma: w, article, pos };
    if (pos === 'noun') { const gn = guessNoun(w, opts.gender || ART_TO_G[article]); Object.assign(res, { gender: gn.gender, paradigm: opts.paradigm || gn.key, conf: article ? 'high' : gn.conf }); }
    if (pos === 'verb') res.group = opts.group || guessVerbGroup(w);
    return res;
  }

  global.Spanish = { strip, lower, norm, sameExceptAccent, splitArticle, guessNoun, declineWith, declineAdj, guessVerbGroup, conjugate, analyse, plural, art,
    PARADIGMS, ARTICLES, CASES, CASE_LABEL, G_TO_ART, ART_TO_G, GENDERS, PERSONS, PERSON_EN, GROUPS, TENSES, TENSE_LABEL };
})(typeof window !== 'undefined' ? window : globalThis);
