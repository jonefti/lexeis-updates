window.APP_BUILD = 5; window.APP_VERSION = '2.3.0';
