window.APP_BUILD = 9; window.APP_VERSION = '2.4.0';
