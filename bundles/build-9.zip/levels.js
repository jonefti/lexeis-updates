/* Levels (progress through stages, level-up, first-run picker), alphabet game and the daily test. */
(function () {
  'use strict';
  const A = window.App, esc = A.esc;

  // ---------- level progress ----------
  A.stageProgress = function () {
    const st = A.stageInfo; if (!st) return null;
    const words = A.dict.filter(e => e.level === st.dict);
    const known = words.filter(e => { const w = A.findByLemma(e.lemma); return w && Object.values(w.srs).some(c => (c.reps || 0) >= 1 || (c.ivl || 0) >= 1); }).length;
    const needW = Math.max(1, Math.min(words.length, 40));
    const lessons = A.grammar.filter(l => l.level === st.id);
    const passed = lessons.filter(l => { const r = A.db.lessons[l.id]; return r && r.best / r.total >= 0.8; }).length;
    const reads = A.readings.filter(r => r.stage === st.id);
    const readDone = reads.filter(r => A.db.readings[r.id]).length;
    const parts = [{ v: Math.min(1, known / needW), w: 0.6 }];
    if (lessons.length) parts.push({ v: passed / lessons.length, w: 0.3 });
    if (reads.length) parts.push({ v: readDone / reads.length, w: 0.1 });
    const tw = parts.reduce((s, p) => s + p.w, 0);
    const pct = Math.round(parts.reduce((s, p) => s + p.v * p.w, 0) / tw * 100);
    const next = (A.LANG.stages || []).find(x => x.id === st.id + 1) || null;
    return { st, pct, known, needW, passed, lessons: lessons.length, readDone, reads: reads.length, next };
  };
  A.levelCard = function () {
    const p = A.stageProgress(); if (!p) return '';
    const ready = p.pct >= 100 && p.next;
    return `<section class="stage-card ${ready ? 'ready' : ''}">
      <div class="sc-top"><span class="stage-num">${p.st.id}</span><div class="sc-info"><strong>${esc(p.st.name)}</strong><span class="xp-bar"><i style="width:${p.pct}%"></i></span><small>${p.pct}% complete · ${p.known}/${p.needW} words learnt${p.lessons ? ` · ${p.passed}/${p.lessons} lessons` : ''}${p.reads ? ` · ${p.readDone}/${p.reads} stories` : ''}</small></div></div>
      ${ready ? `<button class="btn sun wide" data-act="level-up">🎉 Ready! Move up to ${esc(p.next.name)}</button>` : p.next ? `<p class="tiny">Learn the words, pass the lessons and read the stories to unlock <b>${esc(p.next.name)}</b>.</p>` : '<p class="tiny">Top level. Keep going!</p>'}
    </section>`;
  };
  A.acts['level-up'] = function () {
    const p = A.stageProgress(); if (!p || !p.next) return;
    A.db.settings.stage = p.next.id; A.db.settings.stageAsked = true; A.save(); A.applyStage();
    A.sfx.win(); A.confetti(); A.toast(`Welcome to ${p.next.name}! New words and lessons unlocked.`); A.render();
  };

  // ---------- first-run level picker ----------
  A.needsLevelPick = () => !!(A.LANG.stages && !A.db.settings.stage && !A.db.settings.stageAsked && A.db.words.length === 0);
  A.routes.level = function () {
    A.view().innerHTML = `<section class="picker"><div class="picker-logo">${A.LANG.flag}</div><h1>What's your ${esc(A.LANG.name)} level?</h1><p class="muted">Pick where to start. You'll move up as you learn, and you can change it any time in Settings.</p>
      ${A.LANG.stages.map(st => `<button class="lang-card" data-act="pick-stage" data-s="${st.id}"><span class="lc-flag stage-num">${st.id}</span><span class="lc-text"><strong>${esc(st.name)}</strong><small>${esc(st.desc)}</small></span></button>`).join('')}</section>`;
  };
  A.acts['pick-stage'] = el => {
    A.db.settings.stage = +el.dataset.s; A.db.settings.stageAsked = true;
    const st = A.LANG.stages.find(x => x.id === +el.dataset.s);
    if (st && st.audience === 'kid') { A.db.settings.goal = 20; A.db.settings.newPerDay = 8; }
    A.save(); A.applyStage(); A.go('#/today');
  };
  const _render = A.render;
  A.render = function () {
    if (A.needsLevelPick() && !(location.hash || '').startsWith('#/level')) { location.hash = '#/level'; return; }
    _render();
  };
  A.navFor.level = 'today';

  // ---------- alphabet game ----------
  let ab = null;
  A.routes.alphabet = function () {
    const L = A.LANG.alphabet; if (!L) return A.go('#/practice');
    if (!ab || ab.done) ab = { i: 0, n: 10, right: 0, done: false, q: null };
    if (ab.i >= ab.n) {
      A.view().innerHTML = `<header class="top"><h1>${ab.right} / ${ab.n}</h1></header><section class="done-card">${A.ring(ab.right, ab.n, 120, 'Score')}<p class="muted">${ab.right >= 8 ? 'Alphabet star! ⭐' : 'Good practice. Try again to beat your score!'}</p><div class="row-btns"><button class="btn primary" data-act="ab-again">Play again</button><a class="btn" href="#/lesson/alphabet">See all letters</a></div></section>`;
      return;
    }
    if (!ab.q) {
      const it = A.pick(L), mode = Math.random() < 0.5 ? 'sound' : 'hear';
      const others = A.shuffle(L.filter(x => x !== it && x[2] !== it[2])).slice(0, 3);
      const opts = A.shuffle([it].concat(others));
      ab.q = { it, mode, opts, a: opts.indexOf(it) };
      if (mode === 'hear') setTimeout(() => A.speak(it[1], 0.8), 300);
    }
    const q = ab.q;
    A.view().innerHTML = `<div class="review"><div class="rv-top"><a class="back" href="#/practice">Stop</a><span class="rv-count">${ab.i + 1} / ${ab.n}</span></div>
      <div class="progress"><span style="width:${ab.i / ab.n * 100}%"></span></div>
      <article class="card quiz-card center">
        ${q.mode === 'sound' ? `<p class="cue">What sound does this letter make?</p><p class="ab-letter" lang="el">${esc(q.it[0])}</p>` : `<p class="cue">Listen. Which letter is it?</p><button class="mic-btn listen" data-act="ab-play" aria-label="Play">🔊</button>`}
        <div class="options ${q.mode === 'hear' ? 'grid2' : ''}">${q.opts.map((o, i) => `<button class="opt ${q.mode === 'hear' ? 'ab-opt' : ''}" data-act="ab-pick" data-i="${i}" ${q.mode === 'hear' ? 'lang="el"' : ''}>${esc(q.mode === 'sound' ? o[2] : o[0])}</button>`).join('')}</div>
        <div class="answer" hidden><p class="verdict"></p><p class="tiny">${esc(q.it[0])} is called <b lang="el">${esc(q.it[1])}</b> and sounds like <b>${esc(q.it[2])}</b>.</p></div>
      </article><button class="btn primary wide" data-act="ab-next" hidden>Next</button></div>`;
  };
  A.acts['ab-play'] = () => A.speak(ab.q.it[1], 0.8);
  A.acts['ab-pick'] = el => {
    if (ab.q.answered) return; ab.q.answered = true;
    const ok = +el.dataset.i === ab.q.a;
    A.$$('.opt').forEach((b, k) => { b.disabled = true; if (k === ab.q.a) b.classList.add('right'); if (b === el && !ok) b.classList.add('wrong'); });
    if (ok) ab.right++;
    A.recordCat('alphabet', ok); A.xp(ok ? 2 : 1); A.save();
    const a = A.$('.answer'); a.hidden = false; const v = A.$('.verdict', a); v.textContent = ok ? 'Right!' : 'Not quite'; v.className = 'verdict ' + (ok ? 'ok' : 'bad');
    A.speak(ab.q.it[1], 0.8);
    A.$('[data-act="ab-next"]').hidden = false;
  };
  A.acts['ab-next'] = () => { ab.i++; ab.q = null; A.routes.alphabet(); };
  A.acts['ab-again'] = () => { ab = null; A.routes.alphabet(); };
  A.navFor.alphabet = 'practice';
  A.CAT_LABEL.alphabet = 'Alphabet'; A.CAT_LABEL.speaking = 'Speaking'; A.CAT_LABEL.daily = 'Daily test';

  // ---------- daily test ----------
  A.dailyDone = () => (A.db.stats.daily || {})[A.dayKey()];
  A.routes.daily = function () {
    const done = A.dailyDone();
    if (done && !A._dailyRetake) {
      A.view().innerHTML = `<header class="top"><a class="back" href="#/today">Today</a><h1>Today's test</h1></header>
        <section class="done-card">${A.ring(done.score, done.total, 120, 'Score')}<p class="big-num">${done.score}/${done.total}</p><p class="muted">Done for today. A new test is ready tomorrow.</p>
        <div class="row-btns"><button class="btn" data-act="daily-again">Practice round</button><a class="btn primary" href="#/today">Back to today</a></div></section>`;
      return;
    }
    const qs = A.buildDaily();
    A.runQuiz({ title: "Today's test", questions: qs, back: '#/today', backLabel: 'Today',
      onDone: (r, t) => {
        if (!A._dailyRetake) { A.db.stats.daily = A.db.stats.daily || {}; A.db.stats.daily[A.dayKey()] = { score: r, total: t }; A.db.stats.dailyCount = (A.db.stats.dailyCount || 0) + 1; A.xp(10); A.toast('+10 bonus XP for today\'s test'); }
        A._dailyRetake = false;
      } });
  };
  A.acts['daily-again'] = () => { A._dailyRetake = true; A.routes.daily(); };
  A.navFor.daily = 'today';
  A.buildDaily = function () {
    const out = [], G = A.G;
    const add = q => { if (q && q.o && q.o.length >= 2 && q.a >= 0) out.push(q); };
    const mine = A.db.words.filter(w => w.meaning);
    const dict = A.stageDict().filter(e => e.pos !== 'other' || A.stageLevel() === 1);
    const pool = mine.concat(dict.map(e => ({ lemma: e.lemma, meaning: e.meaning, pos: e.pos, gender: e.gender || '', emoji: e.emoji, _e: e })));
    const head = w => A.artJoin(w.lemma, w.gender || A.genderOf(w)) + w.lemma;
    const distract = (correct, key, n) => { const s = new Set([correct]); let t = 0; while (s.size < (n || 4) && t++ < 80) { const x = A.pick(pool); const v = key === 'h' ? head(x) : x[key]; if (v && v !== correct) s.add(v); } return A.shuffle(Array.from(s)); };
    // 1) your own words: meaning (flash card style)
    A.shuffle(mine.slice()).slice(0, 3).forEach(w => { const o = distract(w.meaning, 'meaning'); add({ q: head(w), html: `<span class="q-sub">🃏 Your word: what does it mean?</span><br>${A.emo(w)}${esc(head(w))}`, o, a: o.indexOf(w.meaning), cat: 'daily' }); });
    // 2) recall: English → target
    for (let i = 0; i < 2; i++) { const w = A.pick(mine.length >= 4 ? mine : pool); const o = distract(head(w), 'h'); add({ q: w.meaning, html: `<span class="q-sub">Which is "${esc(w.meaning)}"?</span>`, o, a: o.indexOf(head(w)), cat: 'daily' }); }
    // 3) listening
    for (let i = 0; i < 2; i++) { const w = A.pick(pool); const o = distract(w.meaning, 'meaning'); add({ q: '', audio: head(w), html: `<span class="q-sub">🎧 Listen: what does it mean?</span>`, o, a: o.indexOf(w.meaning), cat: 'daily', ex: head(w) }); }
    // 4) gender
    const nouns = pool.filter(w => w.pos === 'noun' && (w.gender || A.genderOf(w)) && !/\s/.test(w.lemma) && !/'$/.test(A.art(w.lemma, w.gender || A.genderOf(w))));
    for (let i = 0; i < 2 && nouns.length; i++) { const w = A.pick(nouns), g = w.gender || A.genderOf(w); add({ q: w.lemma, html: `<span class="q-sub">Which article?</span><br>${A.emo(w)}${esc(w.lemma)}`, o: G.GENDERS.map(x => G.G_TO_ART[x]), a: G.GENDERS.indexOf(g), cat: 'gender:' + g }); }
    // 5) verb form
    const verbs = pool.filter(w => w.pos === 'verb');
    for (let t = 0, got = 0; t < 10 && got < 2 && verbs.length; t++) {
      let w = A.pick(verbs); if (w._e) w = A.entryToWord(w._e);
      const fq = A.formQuestion(w, { tenses: A.stageTenses().filter(x => x !== 'imperative') }); if (!fq) continue;
      const vals = Array.from(new Set(A.allRows(w).map(r => r.value).filter(v => v && v !== fq.row.value))); if (vals.length < 3) continue;
      const o = A.shuffle([fq.row.value].concat(A.shuffle(vals).slice(0, 3)));
      add({ q: fq.prompt.head, html: `<span class="q-sub">${esc(fq.prompt.detail)}</span><br>${esc(fq.prompt.head)}`, hint: fq.prompt.hint, o, a: o.indexOf(fq.row.value), cat: fq.cat }); got++;
    }
    // 6) phrases
    const ph = A.stagePhrases ? A.stagePhrases() : A.phrases;
    for (let i = 0; i < 2 && ph.length > 4; i++) { const p = A.pick(ph); const s = new Set([p.gr]); while (s.size < 4) s.add(A.pick(ph).gr); const o = A.shuffle(Array.from(s)); add({ q: p.en, html: `<span class="q-sub">💬 How do you say it?</span><br>${esc(p.en)}`, o, a: o.indexOf(p.gr), cat: 'phrase' }); }
    return A.shuffle(out).slice(0, 12);
  };
})();
