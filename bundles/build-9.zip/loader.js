/* Loads the chosen language pack, then the app. Shows a language picker on first run. */
(function () {
  'use strict';
  var g = {};
  try { g = JSON.parse(localStorage.getItem('lexeis.global')) || {}; } catch (e) { g = {}; }
  var lang = g.lang || (localStorage.getItem('lexeis.v1') ? 'el' : null);
  var PACKS = {
    el: ['content/lang-el.js', 'content/el-dict.js', 'content/el-phrases.js', 'content/el-grammar.js', 'content/el-reading.js', 'engines/greek.js'],
    es: ['content/lang-es.js', 'content/es-dict.js', 'content/es-learn.js', 'engines/spanish.js'],
    fr: ['content/lang-fr.js', 'content/fr-dict.js', 'content/fr-learn.js', 'engines/french.js']
  };
  var COMMON = ['version.js', 'ai.js', 'core.js', 'app.js', 'gamify.js', 'native.js', 'levels.js', 'app2.js', 'updater.js'];
  window.LEXEIS_LANGS = [
    { code: 'el', flag: '🇬🇷', name: 'Greek', native: 'Ελληνικά', level: 'Kids beginner to advanced' },
    { code: 'es', flag: '🇪🇸', name: 'Spanish', native: 'Español', level: 'From first lessons to GCSE' },
    { code: 'fr', flag: '🇫🇷', name: 'French', native: 'Français', level: 'Young beginner (8–11)' }
  ];
  window.setLexeisLang = function (code) {
    g.lang = code;
    try { localStorage.setItem('lexeis.global', JSON.stringify(g)); } catch (e) { /* ignore */ }
    location.hash = '#/today';
    location.reload();
  };
  if (!lang || !PACKS[lang]) {
    document.body.className = 'picker-page';
    document.getElementById('view').innerHTML = '<section class="picker"><div class="picker-logo">λ</div><h1>Which language are you learning?</h1><p class="muted">You can switch any time in Settings. Each language keeps its own words and progress.</p>' +
      window.LEXEIS_LANGS.map(function (l) { return '<button class="lang-card" onclick="setLexeisLang(\'' + l.code + '\')"><span class="lc-flag">' + l.flag + '</span><span class="lc-text"><strong>' + l.name + ' · ' + l.native + '</strong><small>' + l.level + '</small></span></button>'; }).join('') + '</section>';
    document.querySelector('.nav').style.display = 'none';
    return;
  }
  PACKS[lang].concat(COMMON).forEach(function (src) {
    var s = document.createElement('script'); s.src = src; s.async = false; document.body.appendChild(s);
  });
})();
