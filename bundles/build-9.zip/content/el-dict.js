/* Greek core dictionary. Format per line: lemma|type|meaning|extra
   type: m f n (noun gender), v verb, a adjective, adv, prep, conj, pron, x phrase/other
   extra (verbs): irregular aorist;future   ·  Section header: #level Topic (1 kids starter, 2 core, 3 intermediate, 4 advanced)
   Extra may also be an emoji (and for verbs, after it: aorist;future) */
window.LANG_DICT_RAW = `
#1 Hello!
γεια σου|x|hello, bye (to one friend)|👋
γεια σας|x|hello (to a grown-up or many)|👋
καλημέρα|x|good morning|🌅
καληνύχτα|x|good night|🌙
ευχαριστώ|x|thank you|🙏
παρακαλώ|x|please; you're welcome|😊
ναι|x|yes|✅
όχι|x|no|❌
συγγνώμη|x|sorry|😔
τι κάνεις;|x|how are you?|🙂
καλά|adv|well, fine|👍
με λένε|x|my name is|🏷️
πώς σε λένε;|x|what's your name?|❓
είμαι ... χρονών|x|I am ... years old|🎂
μπράβο|x|well done|🎉
#1 Numbers
ένα|x|one|1️⃣
δύο|x|two|2️⃣
τρία|x|three|3️⃣
τέσσερα|x|four|4️⃣
πέντε|x|five|5️⃣
έξι|x|six|6️⃣
επτά|x|seven|7️⃣
οχτώ|x|eight|8️⃣
εννιά|x|nine|9️⃣
δέκα|x|ten|🔟
έντεκα|x|eleven|
δώδεκα|x|twelve|
είκοσι|x|twenty|
εκατό|x|a hundred|💯
#1 Family
μαμά|f|mum|👩
μπαμπάς|m|dad|👨
αδερφός|m|brother|👦
αδερφή|f|sister|👧
γιαγιά|f|grandma|👵
παππούς|m|grandpa|👴
μωρό|n|baby|👶
οικογένεια|f|family|👪
φίλος|m|friend (boy)|🧒
φίλη|f|friend (girl)|🧒
#1 Animals
σκύλος|m|dog|🐶
γάτα|f|cat|🐱
ψάρι|n|fish|🐟
πουλί|n|bird|🐦
άλογο|n|horse|🐴
αγελάδα|f|cow|🐮
γουρούνι|n|pig|🐷
πρόβατο|n|sheep|🐑
κότα|f|hen|🐔
κουνέλι|n|rabbit|🐰
ποντίκι|n|mouse|🐭
λιοντάρι|n|lion|🦁
ελέφαντας|m|elephant|🐘
μαϊμού|f|monkey|🐵
χελώνα|f|tortoise|🐢
χταπόδι|n|octopus|🐙
δελφίνι|n|dolphin|🐬
πεταλούδα|f|butterfly|🦋
#1 Colours
κόκκινος|a|red|🔴
μπλε|a|blue (never changes)|🔵
πράσινος|a|green|🟢
κίτρινος|a|yellow|🟡
μαύρος|a|black|⚫
άσπρος|a|white|⚪
ροζ|a|pink (never changes)|🌸
πορτοκαλί|a|orange (never changes)|🟠
#1 Food
μήλο|n|apple|🍎
μπανάνα|f|banana|🍌
πορτοκάλι|n|orange|🍊
φράουλα|f|strawberry|🍓
καρπούζι|n|watermelon|🍉
ψωμί|n|bread|🍞
τυρί|n|cheese|🧀
αυγό|n|egg|🥚
γάλα|n|milk|🥛
νερό|n|water|💧
χυμός|m|juice|🧃
παγωτό|n|ice cream|🍦
σοκολάτα|f|chocolate|🍫
πίτσα|f|pizza|🍕
μακαρόνια|n|pasta|🍝
#1 Home & school
σπίτι|n|house, home|🏠
δωμάτιο|n|room|🚪
κρεβάτι|n|bed|🛏️
τραπέζι|n|table|🪑
καρέκλα|f|chair|🪑
πόρτα|f|door|🚪
παράθυρο|n|window|🪟
σχολείο|n|school|🏫
βιβλίο|n|book|📖
μολύβι|n|pencil|✏️
τσάντα|f|bag|🎒
μπάλα|f|ball|⚽
παιχνίδι|n|toy, game|🧸
ποδήλατο|n|bike|🚲
αυτοκίνητο|n|car|🚗
#1 Body
κεφάλι|n|head|🙂
μάτι|n|eye|👁️
μύτη|f|nose|👃
στόμα|n|mouth|👄
αυτί|n|ear|👂
χέρι|n|hand, arm|✋
πόδι|n|foot, leg|🦶
δόντι|n|tooth|🦷
#1 Nature
ήλιος|m|sun|☀️
φεγγάρι|n|moon|🌙
αστέρι|n|star|⭐
θάλασσα|f|sea|🌊
παραλία|f|beach|🏖️
δέντρο|n|tree|🌳
λουλούδι|n|flower|🌸
βροχή|f|rain|🌧️
χιόνι|n|snow|❄️
#1 First verbs
είμαι|v|to be|✨
έχω|v|to have|🤲
θέλω|v|to want|🙏
τρώω|v|to eat|🍽️|έφαγα;φάω
πίνω|v|to drink|🥤|ήπια;πιω
παίζω|v|to play|🎮
αγαπάω|v|to love|❤️
μου αρέσει|x|I like (it)|😍
βλέπω|v|to see, watch|👀|είδα;δω
πάω|x|I go|🚶
κολυμπάω|v|to swim|🏊
τρέχω|v|to run|🏃
#1 Describing
μεγάλος|a|big|🐘
μικρός|a|small|🐭
ωραίος|a|nice, lovely|🌟
καλός|a|good|👍
χαρούμενος|a|happy|😃
λυπημένος|a|sad|😢
κρύος|a|cold|🧊
ζεστός|a|hot, warm|🔥
#2 People & family
άνθρωπος|m|person, human being
άντρας|m|man, husband
γυναίκα|f|woman, wife
παιδί|n|child
αγόρι|n|boy
κορίτσι|n|girl
μωρό|n|baby
οικογένεια|f|family
γονείς|m|parents (pl. of γονιός)
μητέρα|f|mother
πατέρας|m|father
μαμά|f|mum
μπαμπάς|m|dad
γιος|m|son
κόρη|f|daughter
αδερφός|m|brother
αδερφή|f|sister
παππούς|m|grandfather
γιαγιά|f|grandmother
θείος|m|uncle
θεία|f|aunt
ξάδερφος|m|cousin (male)
ξαδέρφη|f|cousin (female)
ανιψιός|m|nephew
ανιψιά|f|niece
εγγονός|m|grandson
εγγονή|f|granddaughter
σύζυγος|m|spouse (ο/η)
πεθερά|f|mother-in-law
πεθερός|m|father-in-law
κουνιάδος|m|brother-in-law
κουνιάδα|f|sister-in-law
νονός|m|godfather
νονά|f|godmother
φίλος|m|friend (male)
φίλη|f|friend (female)
γείτονας|m|neighbour
συνάδελφος|m|colleague
κουμπάρος|m|best man, wedding sponsor
#2 Body & health
σώμα|n|body
κεφάλι|n|head
μαλλιά|n|hair (pl.)
πρόσωπο|n|face
μάτι|n|eye
αυτί|n|ear
μύτη|f|nose
στόμα|n|mouth
δόντι|n|tooth
γλώσσα|f|tongue, language
λαιμός|m|neck, throat
ώμος|m|shoulder
χέρι|n|hand, arm
δάχτυλο|n|finger
πόδι|n|foot, leg
γόνατο|n|knee
πλάτη|f|back
κοιλιά|f|belly, stomach
στομάχι|n|stomach
καρδιά|f|heart
αίμα|n|blood
δέρμα|n|skin
γιατρός|m|doctor (ο/η)
νοσοκόμα|f|nurse
νοσοκομείο|n|hospital
φαρμακείο|n|pharmacy
φάρμακο|n|medicine
πόνος|m|pain
πυρετός|m|fever
κρύωμα|n|cold (illness)
βήχας|m|cough
υγεία|f|health
άρρωστος|a|ill, sick
κουρασμένος|a|tired
πονάω|v|to hurt, ache
αρρωσταίνω|v|to fall ill|αρρώστησα;αρρωστήσω
#2 Home
σπίτι|n|house, home
διαμέρισμα|n|flat, apartment
δωμάτιο|n|room
κουζίνα|f|kitchen, cooker
σαλόνι|n|living room
μπάνιο|n|bathroom, bath, swim
κρεβατοκάμαρα|f|bedroom
μπαλκόνι|n|balcony
ταράτσα|f|roof terrace
αυλή|f|courtyard, yard
κήπος|m|garden
πόρτα|f|door
παράθυρο|n|window
τοίχος|m|wall
πάτωμα|n|floor
ταβάνι|n|ceiling
σκάλα|f|stairs, ladder
ασανσέρ|n|lift
κρεβάτι|n|bed
τραπέζι|n|table
καρέκλα|f|chair
καναπές|m|sofa
ντουλάπα|f|wardrobe
ψυγείο|n|fridge
πλυντήριο|n|washing machine
φούρνος|m|oven, bakery
κλειδί|n|key
λάμπα|f|lamp, bulb
καθρέφτης|m|mirror
κουβέρτα|f|blanket
μαξιλάρι|n|pillow
πετσέτα|f|towel
νοίκι|n|rent
ιδιοκτήτης|m|owner, landlord
#2 Food & drink
φαγητό|n|food, meal
πρωινό|n|breakfast, morning
μεσημεριανό|n|lunch
βραδινό|n|dinner
ψωμί|n|bread
νερό|n|water
κρασί|n|wine
μπίρα|f|beer
καφές|m|coffee
τσάι|n|tea
γάλα|n|milk
χυμός|m|juice
ζάχαρη|f|sugar
αλάτι|n|salt
πιπέρι|n|pepper
λάδι|n|oil, olive oil
ξίδι|n|vinegar
βούτυρο|n|butter
τυρί|n|cheese
αυγό|n|egg
κρέας|n|meat
κοτόπουλο|n|chicken
μοσχάρι|n|beef, veal
χοιρινό|n|pork
αρνί|n|lamb
ψάρι|n|fish
χταπόδι|n|octopus
καλαμάρι|n|squid
γαρίδα|f|prawn
σαλάτα|f|salad
ντομάτα|f|tomato
αγγούρι|n|cucumber
κρεμμύδι|n|onion
σκόρδο|n|garlic
πατάτα|f|potato
πιπεριά|f|pepper (vegetable)
μελιτζάνα|f|aubergine
κολοκυθάκι|n|courgette
φασόλι|n|bean
φακή|f|lentil
ρύζι|n|rice
μακαρόνια|n|pasta (pl.)
φρούτο|n|fruit
μήλο|n|apple
πορτοκάλι|n|orange
λεμόνι|n|lemon
μπανάνα|f|banana
σταφύλι|n|grape
καρπούζι|n|watermelon
πεπόνι|n|melon
σύκο|n|fig
ελιά|f|olive, olive tree
μέλι|n|honey
γιαούρτι|n|yoghurt
γλυκό|n|dessert, sweet
παγωτό|n|ice cream
πιάτο|n|plate, dish
ποτήρι|n|glass
μαχαίρι|n|knife
πιρούνι|n|fork
κουτάλι|n|spoon
λογαριασμός|m|bill, account
σερβιτόρος|m|waiter
ταβέρνα|f|taverna
μεζές|m|small dish, meze
πεινάω|v|to be hungry
διψάω|v|to be thirsty
μαγειρεύω|v|to cook
τρώω|v|to eat|έφαγα;φάω
πίνω|v|to drink|ήπια;πιω
νόστιμος|a|tasty
φρέσκος|a|fresh
#2 Time
χρόνος|m|time, year
ώρα|f|hour, time (o'clock)
λεπτό|n|minute
δευτερόλεπτο|n|second
μέρα|f|day
νύχτα|f|night
πρωί|n|morning
μεσημέρι|n|midday
απόγευμα|n|afternoon
βράδυ|n|evening
εβδομάδα|f|week
μήνας|m|month
εποχή|f|season, era
χειμώνας|m|winter
άνοιξη|f|spring
καλοκαίρι|n|summer
φθινόπωρο|n|autumn
Σαββατοκύριακο|n|weekend
γιορτή|f|celebration, name day
γενέθλια|n|birthday (pl.)
διακοπές|f|holidays (pl.)
Πάσχα|n|Easter
Χριστούγεννα|n|Christmas (pl.)
σήμερα|adv|today
αύριο|adv|tomorrow
χθες|adv|yesterday
μεθαύριο|adv|the day after tomorrow
προχθές|adv|the day before yesterday
τώρα|adv|now
μετά|adv|after, then
πριν|adv|before
νωρίς|adv|early
αργά|adv|late, slowly
πάντα|adv|always
ποτέ|adv|never, ever
συχνά|adv|often
καμιά φορά|adv|sometimes
αμέσως|adv|immediately
ακόμα|adv|still, yet, even
ήδη|adv|already
επιτέλους|adv|at last
#2 Town & travel
πόλη|f|city, town
χωριό|n|village
δρόμος|m|road, street
πλατεία|f|square
γειτονιά|f|neighbourhood
μαγαζί|n|shop
αγορά|f|market, purchase
σούπερ μάρκετ|n|supermarket
περίπτερο|n|kiosk
τράπεζα|f|bank
ταχυδρομείο|n|post office
εκκλησία|f|church
σχολείο|n|school
πανεπιστήμιο|n|university
μουσείο|n|museum
θέατρο|n|theatre
σινεμά|n|cinema
ξενοδοχείο|n|hotel
εστιατόριο|n|restaurant
γέφυρα|f|bridge
στάση|f|stop (bus)
σταθμός|m|station
αεροδρόμιο|n|airport
λιμάνι|n|port, harbour
αυτοκίνητο|n|car
λεωφορείο|n|bus
τρένο|n|train
μετρό|n|metro
ταξί|n|taxi
πλοίο|n|ship
καράβι|n|boat, ferry
αεροπλάνο|n|aeroplane
ποδήλατο|n|bicycle
μηχανή|f|motorbike, machine, engine
εισιτήριο|n|ticket
βαλίτσα|f|suitcase
διαβατήριο|n|passport
ταξίδι|n|journey, trip
κίνηση|f|traffic, movement
χάρτης|m|map
δεξιά|adv|right
αριστερά|adv|left
ευθεία|adv|straight on
κοντά|adv|near
μακριά|adv|far
απέναντι|adv|opposite
δίπλα|adv|next to
ταξιδεύω|v|to travel
φτάνω|v|to arrive|έφτασα;φτάσω
φεύγω|v|to leave|έφυγα;φύγω
οδηγώ|v|to drive
περπατάω|v|to walk
#2 Nature & weather
θάλασσα|f|sea
παραλία|f|beach
άμμος|f|sand
νησί|n|island
βουνό|n|mountain
ποτάμι|n|river
λίμνη|f|lake
δάσος|n|forest
δέντρο|n|tree
λουλούδι|n|flower
χόρτο|n|grass
πέτρα|f|stone
ουρανός|m|sky
ήλιος|m|sun
φεγγάρι|n|moon
αστέρι|n|star
σύννεφο|n|cloud
βροχή|f|rain
χιόνι|n|snow
αέρας|m|wind, air
καιρός|m|weather, time
ζέστη|f|heat
κρύο|n|cold
κύμα|n|wave
ζώο|n|animal
σκύλος|m|dog
γάτα|f|cat
πουλί|n|bird
άλογο|n|horse
αγελάδα|f|cow
πρόβατο|n|sheep
κατσίκα|f|goat
βρέχει|v|it rains|έβρεξε;βρέξει
χιονίζει|v|it snows
#2 Work & school
δουλειά|f|work, job
γραφείο|n|office, desk
εταιρεία|f|company
αφεντικό|n|boss
υπάλληλος|m|employee (ο/η)
μισθός|m|salary
συνάντηση|f|meeting
σύσκεψη|f|(business) meeting
μάθημα|n|lesson
δάσκαλος|m|teacher
δασκάλα|f|teacher (female)
καθηγητής|m|teacher, professor
μαθητής|m|pupil
φοιτητής|m|student
βιβλίο|n|book
τετράδιο|n|notebook
στυλό|n|pen
μολύβι|n|pencil
χαρτί|n|paper
εξετάσεις|f|exams (pl.)
άσκηση|f|exercise
ερώτηση|f|question
απάντηση|f|answer
λέξη|f|word
πρόταση|f|sentence, proposal
γράμμα|n|letter
υπολογιστής|m|computer
κινητό|n|mobile phone
τηλέφωνο|n|telephone
email|n|email
δουλεύω|v|to work
μαθαίνω|v|to learn|έμαθα;μάθω
διαβάζω|v|to read, study
γράφω|v|to write
#2 Everyday verbs
είμαι|v|to be|ήμουν;θα είμαι
έχω|v|to have|είχα;θα έχω
κάνω|v|to do, make|έκανα;κάνω
θέλω|v|to want|θέλησα;θελήσω
μπορώ|v|can, to be able
ξέρω|v|to know|ήξερα;θα ξέρω
πηγαίνω|v|to go|πήγα;πάω
έρχομαι|v|to come|ήρθα;έρθω
βλέπω|v|to see|είδα;δω
λέω|v|to say, tell|είπα;πω
ακούω|v|to hear, listen
μιλάω|v|to speak
ρωτάω|v|to ask
απαντάω|v|to answer
καταλαβαίνω|v|to understand|κατάλαβα;καταλάβω
δίνω|v|to give|έδωσα;δώσω
παίρνω|v|to take|πήρα;πάρω
φέρνω|v|to bring|έφερα;φέρω
βάζω|v|to put|έβαλα;βάλω
βρίσκω|v|to find|βρήκα;βρω
χάνω|v|to lose, miss|έχασα;χάσω
ψάχνω|v|to look for|έψαξα;ψάξω
ανοίγω|v|to open
κλείνω|v|to close|έκλεισα;κλείσω
αρχίζω|v|to begin
τελειώνω|v|to finish
μένω|v|to stay, live|έμεινα;μείνω
ζω|v|to live|έζησα;ζήσω
αγαπάω|v|to love
αρέσω|v|to please (μου αρέσει = I like)|άρεσα;αρέσω
μισώ|v|to hate|μίσησα;μισήσω
θυμάμαι|v|to remember|θυμήθηκα;θυμηθώ
ξεχνάω|v|to forget
σκέφτομαι|v|to think
πιστεύω|v|to believe
ελπίζω|v|to hope
περιμένω|v|to wait|περίμενα;περιμένω
βοηθάω|v|to help
ψωνίζω|v|to shop
αγοράζω|v|to buy
πουλάω|v|to sell|πούλησα;πουλήσω
πληρώνω|v|to pay
κοστίζω|v|to cost
στέλνω|v|to send|έστειλα;στείλω
παίζω|v|to play
τραγουδάω|v|to sing
χορεύω|v|to dance
κολυμπάω|v|to swim
τρέχω|v|to run
κάθομαι|v|to sit|κάθισα;καθίσω
σηκώνομαι|v|to get up|σηκώθηκα;σηκωθώ
ξυπνάω|v|to wake up
κοιμάμαι|v|to sleep|κοιμήθηκα;κοιμηθώ
πλένω|v|to wash|έπλυνα;πλύνω
ντύνομαι|v|to get dressed
βγαίνω|v|to go out|βγήκα;βγω
μπαίνω|v|to go in|μπήκα;μπω
ανεβαίνω|v|to go up|ανέβηκα;ανέβω
κατεβαίνω|v|to go down|κατέβηκα;κατέβω
γυρίζω|v|to return, turn
γίνομαι|v|to become, happen|έγινα;γίνω
συμβαίνει|v|it happens|συνέβη;συμβεί
χρειάζομαι|v|to need
προσπαθώ|v|to try
αποφασίζω|v|to decide
αλλάζω|v|to change
κλαίω|v|to cry|έκλαψα;κλάψω
γελάω|v|to laugh
φοβάμαι|v|to be afraid|φοβήθηκα;φοβηθώ
χαίρομαι|v|to be glad|χάρηκα;χαρώ
λυπάμαι|v|to be sorry|λυπήθηκα;λυπηθώ
ντρέπομαι|v|to be embarrassed|ντράπηκα;ντραπώ
#2 Describing things
μεγάλος|a|big, old (age)
μικρός|a|small, young
καλός|a|good
κακός|a|bad
ωραίος|a|nice, beautiful
όμορφος|a|beautiful
άσχημος|a|ugly, bad
καινούργιος|a|new
παλιός|a|old (things)
νέος|a|young, new
γέρος|a|old (people)
ψηλός|a|tall
κοντός|a|short
χοντρός|a|fat, thick
λεπτός|a|thin
ζεστός|a|hot, warm
κρύος|a|cold
γρήγορος|a|fast
αργός|a|slow
εύκολος|a|easy
δύσκολος|a|difficult
ακριβός|a|expensive
φτηνός|a|cheap
γεμάτος|a|full
άδειος|a|empty
ανοιχτός|a|open, light (colour)
κλειστός|a|closed
καθαρός|a|clean, clear
βρόμικος|a|dirty
ήσυχος|a|quiet, calm
χαρούμενος|a|happy
λυπημένος|a|sad
θυμωμένος|a|angry
ευτυχισμένος|a|happy, content
σοβαρός|a|serious
αστείος|a|funny
έξυπνος|a|clever
χαζός|a|silly, stupid
τεμπέλης|m|lazy (person)
σωστός|a|right, correct
λάθος|n|mistake; wrong
σημαντικός|a|important
ενδιαφέρων|a|interesting (-ουσα, -ον)
βαρετός|a|boring
διάσημος|a|famous
#2 Colours
χρώμα|n|colour
άσπρος|a|white
μαύρος|a|black
κόκκινος|a|red
πράσινος|a|green
κίτρινος|a|yellow
γαλάζιος|a|light blue
μπλε|a|blue (invariable)
γκρι|a|grey (invariable)
καφέ|a|brown (invariable)
ροζ|a|pink (invariable)
μωβ|a|purple (invariable)
πορτοκαλί|a|orange (invariable)
#2 Clothes & shopping
ρούχα|n|clothes (pl.)
πουκάμισο|n|shirt
μπλούζα|f|top, T-shirt
παντελόνι|n|trousers
φούστα|f|skirt
φόρεμα|n|dress
παπούτσι|n|shoe
κάλτσα|f|sock
σακάκι|n|jacket
παλτό|n|coat
καπέλο|n|hat
τσάντα|f|bag, handbag
πορτοφόλι|n|wallet
γυαλιά|n|glasses (pl.)
ρολόι|n|watch, clock
μέγεθος|n|size
τιμή|f|price, honour
έκπτωση|f|discount
λεφτά|n|money (pl.)
χρήματα|n|money (pl., formal)
ευρώ|n|euro
απόδειξη|f|receipt, proof
κάρτα|f|card
μετρητά|n|cash (pl.)
δοκιμάζω|v|to try (on), taste
#3 Feelings & character
συναίσθημα|n|feeling, emotion
χαρά|f|joy
λύπη|f|sorrow
φόβος|m|fear
θυμός|m|anger
αγάπη|f|love
έρωτας|m|romantic love, passion
ζήλια|f|jealousy
ντροπή|f|shame
ελπίδα|f|hope
άγχος|n|stress, anxiety
υπομονή|f|patience
περηφάνια|f|pride
μοναξιά|f|loneliness
νοσταλγία|f|nostalgia
κέφι|n|good mood, high spirits
μεράκι|n|passion, love put into something
φιλότιμο|n|sense of honour, doing right by others
χαλαρός|a|relaxed
αγχωμένος|a|stressed
ενθουσιασμένος|a|excited
απογοητευμένος|a|disappointed
ζηλιάρης|m|jealous (person)
ευγενικός|a|polite, kind
αγενής|a|rude
ντροπαλός|a|shy
περήφανος|a|proud
γενναίος|a|brave
τίμιος|a|honest
ψεύτικος|a|fake, false
ειλικρινής|a|sincere
πεισματάρης|m|stubborn (person)
γκρινιάρης|m|grumpy, a moaner
αγχώνομαι|v|to get stressed
στενοχωριέμαι|v|to get upset|στενοχωρήθηκα;στενοχωρηθώ
ενοχλώ|v|to bother, annoy
θυμώνω|v|to get angry
ηρεμώ|v|to calm down|ηρέμησα;ηρεμήσω
ερωτεύομαι|v|to fall in love|ερωτεύτηκα;ερωτευτώ
βαριέμαι|v|to be bored, can't be bothered|βαρέθηκα;βαρεθώ
νιώθω|v|to feel|ένιωσα;νιώσω
αισθάνομαι|v|to feel|αισθάνθηκα;αισθανθώ
#3 Society & news
κοινωνία|f|society
κυβέρνηση|f|government
πολιτική|f|politics, policy
εκλογές|f|elections (pl.)
νόμος|m|law
δικαίωμα|n|right (legal)
υποχρέωση|f|obligation
χώρα|f|country
κράτος|n|state
πρωθυπουργός|m|prime minister
βουλή|f|parliament
δήμος|m|municipality
δήμαρχος|m|mayor
πολίτης|m|citizen
αστυνομία|f|police
απεργία|f|strike
διαδήλωση|f|demonstration
κρίση|f|crisis
οικονομία|f|economy
φόρος|m|tax
τιμές|f|prices (pl.)
ανεργία|f|unemployment
σύνταξη|f|pension, syntax
ειδήσεις|f|news (pl.)
εφημερίδα|f|newspaper
άρθρο|n|article
δημοσιογράφος|m|journalist (ο/η)
συνέντευξη|f|interview
έρευνα|f|research, survey
πρόβλημα|n|problem
λύση|f|solution
απόφαση|f|decision
αλλαγή|f|change
ανάπτυξη|f|growth, development
περιβάλλον|n|environment
ρύπανση|f|pollution
φωτιά|f|fire
σεισμός|m|earthquake
πόλεμος|m|war
ειρήνη|f|peace
ψηφίζω|v|to vote
συζητάω|v|to discuss
#3 Abstract & thinking
ιδέα|f|idea
γνώμη|f|opinion
άποψη|f|view, point of view
σκέψη|f|thought
λόγος|m|reason, speech
αιτία|f|cause
αποτέλεσμα|n|result
σκοπός|m|aim, purpose
στόχος|m|goal, target
ευκαιρία|f|opportunity
κίνδυνος|m|danger, risk
δυνατότητα|f|possibility, ability
επιλογή|f|choice
προτίμηση|f|preference
εμπειρία|f|experience
γνώση|f|knowledge
μνήμη|f|memory
όνειρο|n|dream
αλήθεια|f|truth
ψέμα|n|lie
πραγματικότητα|f|reality
σχέση|f|relationship, relation
διαφορά|f|difference
ομοιότητα|f|similarity
μέλλον|n|future
παρελθόν|n|past
παρόν|n|present
ζωή|f|life
θάνατος|m|death
κόσμος|m|world, people
θέμα|n|topic, issue
είδος|n|kind, type
τρόπος|m|way, manner
μέρος|n|place, part
σημείο|n|point, spot
αριθμός|m|number
ποσότητα|f|quantity
ποιότητα|f|quality
προσοχή|f|attention, care
συμφωνώ|v|to agree
διαφωνώ|v|to disagree
εξηγώ|v|to explain|εξήγησα;εξηγήσω
συγκρίνω|v|to compare|σύγκρινα;συγκρίνω
υποθέτω|v|to suppose|υπέθεσα;υποθέσω
αποδεικνύω|v|to prove|απέδειξα;αποδείξω
προτείνω|v|to suggest|πρότεινα;προτείνω
επιμένω|v|to insist|επέμεινα;επιμείνω
αμφιβάλλω|v|to doubt|αμφέβαλα;αμφιβάλω
#3 Useful adverbs & linkers
επίσης|adv|also
ακόμη|adv|still, even
μάλλον|adv|probably, rather
ίσως|adv|maybe
σίγουρα|adv|surely, definitely
βέβαια|adv|of course
φυσικά|adv|naturally, of course
δυστυχώς|adv|unfortunately
ευτυχώς|adv|fortunately
πραγματικά|adv|really
σχεδόν|adv|almost
περίπου|adv|about, approximately
μόνο|adv|only
μαζί|adv|together
μόνος|a|alone (μόνος μου = by myself)
αλλιώς|adv|otherwise, differently
έτσι|adv|like this, so
κάπως|adv|somehow, somewhat
καθόλου|adv|not at all, at all
αρκετά|adv|quite, enough
πολύ|adv|very, much
λίγο|adv|a little
τόσο|adv|so (much)
μάλιστα|adv|indeed, yes (formal)
όμως|conj|however, but
αλλά|conj|but
και|conj|and, also
ή|conj|or
ούτε|conj|neither, nor
επειδή|conj|because
γιατί|conj|why, because
αφού|conj|since, after
ενώ|conj|while, whereas
όταν|conj|when
αν|conj|if
μήπως|conj|maybe, by any chance
ώστε|conj|so that
λοιπόν|conj|so, well then
δηλαδή|conj|that is, I mean
παρόλο που|conj|although
εκτός αν|conj|unless
μέχρι|prep|until
χωρίς|prep|without
με|prep|with
σε|prep|in, at, to
από|prep|from, by
για|prep|for, about
προς|prep|towards
μέσα|adv|inside
έξω|adv|outside
πάνω|adv|up, on top
κάτω|adv|down, below
μπροστά|adv|in front
πίσω|adv|behind, back
γύρω|adv|around
#3 Home life & errands
λογαριασμός ρεύματος|m|electricity bill
ρεύμα|n|electricity, current
θέρμανση|f|heating
κλιματιστικό|n|air conditioner
σκουπίδια|n|rubbish (pl.)
βρύση|f|tap
ντους|n|shower
σαπούνι|n|soap
οδοντόβουρτσα|f|toothbrush
σκούπα|f|broom, hoover
σφουγγαρίστρα|f|mop
μπουγάδα|f|laundry
σίδερο|n|iron
καθαρίζω|v|to clean
σκουπίζω|v|to sweep, wipe
μαζεύω|v|to collect, tidy up
στρώνω|v|to lay (table), make (bed)
χαλάω|v|to break down, spoil
φτιάχνω|v|to make, fix
μετακομίζω|v|to move house
νοικιάζω|v|to rent
#3 Food culture
λαϊκή|f|street market
μανάβης|m|greengrocer
χασάπης|m|butcher
φούρναρης|m|baker
ζαχαροπλαστείο|n|patisserie
συνταγή|f|recipe, prescription
υλικά|n|ingredients (pl.)
κατσαρόλα|f|saucepan
τηγάνι|n|frying pan
ταψί|n|baking tray
σούβλα|f|spit roast
ψησταριά|f|grill house
χωριάτικη|f|Greek salad
γεμιστά|n|stuffed vegetables (pl.)
σπανακόπιτα|f|spinach pie
τυρόπιτα|f|cheese pie
φασολάδα|f|bean soup
αυγολέμονο|n|egg-lemon sauce
τηγανίζω|v|to fry
ψήνω|v|to grill, bake|έψησα;ψήσω
βράζω|v|to boil
κόβω|v|to cut|έκοψα;κόψω
ανακατεύω|v|to stir, mix
γεύση|f|taste, flavour
μυρωδιά|f|smell
#3 Media & tech
οθόνη|f|screen
εφαρμογή|f|app, application
ιστοσελίδα|f|web page
διαδίκτυο|n|internet
μήνυμα|n|message
κωδικός|m|code, password
φωτογραφία|f|photo
βίντεο|n|video
ανάρτηση|f|post (social media)
σχόλιο|n|comment
ακόλουθος|m|follower
λογαριασμός|m|account, bill
κατεβάζω|v|to download, lower
ανεβάζω|v|to upload, raise
στέλνω μήνυμα|v|to text
μοιράζομαι|v|to share|μοιράστηκα;μοιραστώ
σβήνω|v|to delete, switch off|έσβησα;σβήσω
ανάβω|v|to switch on, light|άναψα;ανάψω
φορτίζω|v|to charge
#3 Leisure
ελεύθερος χρόνος|m|free time
χόμπι|n|hobby
μουσική|f|music
τραγούδι|n|song
συναυλία|f|concert
ταινία|f|film
σειρά|f|series, turn, row
παράσταση|f|performance
γήπεδο|n|stadium, pitch
αγώνας|m|match, struggle
ομάδα|f|team, group
μπάλα|f|ball
ποδόσφαιρο|n|football
γυμναστήριο|n|gym
βόλτα|f|stroll, walk, ride
εκδρομή|f|excursion
πανηγύρι|n|village festival
ξενύχτι|n|staying up all night
γλέντι|n|party, celebration
νίκη|f|victory
ήττα|f|defeat
κερδίζω|v|to win, earn
χάνω|v|to lose
γυμνάζομαι|v|to work out|γυμνάστηκα;γυμναστώ
διασκεδάζω|v|to have fun
ξεκουράζομαι|v|to rest|ξεκουράστηκα;ξεκουραστώ
#4 Expressive & advanced
ανησυχία|f|worry
αδιαφορία|f|indifference
ευθύνη|f|responsibility
συνέπεια|f|consequence, consistency
προτεραιότητα|f|priority
προκατάληψη|f|prejudice
αντίληψη|f|perception
επιρροή|f|influence
προσδοκία|f|expectation
απαίτηση|f|demand
συμβιβασμός|m|compromise
παρεξήγηση|f|misunderstanding
διάθεση|f|mood, disposition
έμπνευση|f|inspiration
πρόκληση|f|challenge, provocation
πρωτοβουλία|f|initiative
εμπιστοσύνη|f|trust
αυτοπεποίθηση|f|self-confidence
ταυτότητα|f|identity, ID card
παράδοση|f|tradition, delivery
κληρονομιά|f|heritage, inheritance
φαινόμενο|n|phenomenon
πλεονέκτημα|n|advantage
μειονέκτημα|n|disadvantage
γεγονός|n|event, fact
περιστατικό|n|incident
κατάσταση|f|situation
συνθήκες|f|conditions (pl.)
εντύπωση|f|impression
αίσθηση|f|sense, sensation
λεπτομέρεια|f|detail
προθεσμία|f|deadline
συμφέρον|n|interest (benefit)
ελάττωμα|n|flaw, defect
προτέρημα|n|virtue, strength
πείσμα|n|stubbornness
φιλοξενία|f|hospitality
μπελάς|m|hassle, trouble
χάλι|n|mess, sorry state
κόλπο|n|trick
καημός|m|longing, sorrow
νταλκάς|m|heartache, yearning
πεζός|a|pedestrian, prosaic
αξιόπιστος|a|reliable
απαραίτητος|a|necessary
αναμενόμενος|a|expected
απρόβλεπτος|a|unpredictable
αμήχανος|a|awkward
διακριτικός|a|discreet
επίμονος|a|persistent
ευαίσθητος|a|sensitive
ιδιότροπος|a|fussy, capricious
απότομος|a|abrupt, steep
αδιάφορος|a|indifferent
δίκαιος|a|fair, just
άδικος|a|unfair
πρόθυμος|a|willing
υπεύθυνος|a|responsible
ανεύθυνος|a|irresponsible
ενοχλητικός|a|annoying
συγκινητικός|a|moving, touching
εκπληκτικός|a|amazing
απίστευτος|a|unbelievable
τρομερός|a|terrible, tremendous
φανταστικός|a|fantastic, imaginary
τεράστιος|a|huge
ελάχιστος|a|minimal
πιθανός|a|likely
αδύνατος|a|impossible, weak, thin
απαγορεύεται|v|it is forbidden|απαγορεύτηκε;απαγορευτεί
επιτρέπεται|v|it is allowed|επιτράπηκε;επιτραπεί
αξίζει|v|it is worth|άξιζε;αξίζει
πρόκειται|v|it is about to / it concerns|επρόκειτο;θα πρόκειται
εξαρτάται|v|it depends|εξαρτήθηκε;εξαρτηθεί
φαίνεται|v|it seems|φάνηκε;φανεί
εκφράζω|v|to express
αντιμετωπίζω|v|to face, deal with
αναρωτιέμαι|v|to wonder|αναρωτήθηκα;αναρωτηθώ
αποφεύγω|v|to avoid|απέφυγα;αποφύγω
απολαμβάνω|v|to enjoy|απόλαυσα;απολαύσω
εκμεταλλεύομαι|v|to take advantage of|εκμεταλλεύτηκα;εκμεταλλευτώ
παραδέχομαι|v|to admit|παραδέχτηκα;παραδεχτώ
παραπονιέμαι|v|to complain|παραπονέθηκα;παραπονεθώ
γκρινιάζω|v|to moan, nag
καυχιέμαι|v|to boast|καυχήθηκα;καυχηθώ
συγχωρώ|v|to forgive|συγχώρεσα;συγχωρέσω
υπόσχομαι|v|to promise|υποσχέθηκα;υποσχεθώ
εμπιστεύομαι|v|to trust|εμπιστεύτηκα;εμπιστευτώ
αναβάλλω|v|to postpone|ανέβαλα;αναβάλω
ακυρώνω|v|to cancel
επιβεβαιώνω|v|to confirm
προσφέρω|v|to offer|πρόσφερα;προσφέρω
απευθύνομαι|v|to address, turn to|απευθύνθηκα;απευθυνθώ
αφορά|v|it concerns|αφορούσε;αφορά
συνειδητοποιώ|v|to realise|συνειδητοποίησα;συνειδητοποιήσω
καταφέρνω|v|to manage (to do)|κατάφερα;καταφέρω
πετυχαίνω|v|to succeed, hit, bump into|πέτυχα;πετύχω
αποτυγχάνω|v|to fail|απέτυχα;αποτύχω
παρατάω|v|to give up, abandon|παράτησα;παρατήσω
τσακώνομαι|v|to argue, quarrel|τσακώθηκα;τσακωθώ
κοροϊδεύω|v|to mock, fool
πειράζω|v|to tease, bother (δεν πειράζει = never mind)
χαλαρώνω|v|to relax
ξεσπάω|v|to burst out|ξέσπασα;ξεσπάσω
#4 Colloquial & Instagram Greek
ρε|x|hey, mate (very informal)
μωρέ|x|come on, oh (informal)
έλα|x|come on, hello (on the phone)
άντε|x|come on, go on
ωχ|x|oh no
μπράβο|x|well done
βρε|x|hey, oh (affectionate)
πωπώ|x|wow, oh dear
γιατί όχι|x|why not
τέλεια|adv|perfect, great
φοβερός|a|awesome, terrible
τρελός|a|crazy
γαμάτος|a|awesome (vulgar slang)
χάλια|adv|awful, terribly
κουλ|a|cool (invariable)
τζάμπα|adv|for free, for nothing
μάγκας|m|cool guy, tough guy
φάση|f|phase; vibe, situation (slang)
πλάκα|f|fun, joke; slab
κολλητός|m|best mate
γκόμενα|f|girlfriend (slang)
γκόμενος|m|boyfriend (slang)
μπέσα|f|trust, loyalty, word of honour
τσαμπουκάς|m|aggro, attitude
καψούρα|f|crush, infatuation
ψώνιο|n|purchase; show-off (person)
χαβαλές|m|messing about, laughs
κουτσομπολιό|n|gossip
κάνω πλάκα|x|I'm joking
δεν πειράζει|x|never mind, it's ok
τι λες;|x|what are you saying? really?
σιγά μην|x|as if, yeah right
έχει πλάκα|x|it's fun, it's funny
δεν παίζεται|x|it's unbelievable (so good)
πάμε|x|let's go
καλή φάση|x|good vibe
`;
