/* Everyday Greek: common sentences by situation. Format: Greek|English  ·  # Topic */
window.LANG_PHRASES_RAW = `
#1 Hello (kids)
Γεια σου!|Hello! / Bye!
Με λένε Μαρία.|My name is Maria.
Πώς σε λένε;|What's your name?
Είμαι δέκα χρονών.|I'm ten years old.
Τι κάνεις; Καλά, ευχαριστώ.|How are you? Fine, thanks.
Καληνύχτα, μαμά!|Good night, mum!
#1 Me and my things
Έχω έναν σκύλο.|I have a dog.
Έχω μία αδερφή.|I have one sister.
Μου αρέσει το παγωτό.|I like ice cream.
Δεν μου αρέσει το γάλα.|I don't like milk.
Το αγαπημένο μου χρώμα είναι το μπλε.|My favourite colour is blue.
Θέλω νερό, παρακαλώ.|I want water, please.
#1 Playing
Πάμε να παίξουμε!|Let's go and play!
Σειρά σου!|Your turn!
Κέρδισα!|I won!
Έλα εδώ!|Come here!
Πάμε στην παραλία;|Shall we go to the beach?
#3 Greetings & small talk
Καλημέρα! Τι κάνεις;|Good morning! How are you?
Καλά, εσύ;|Fine, and you?
Όλα καλά;|Everything ok?
Τι γίνεται;|What's up?
Πώς πάει;|How's it going?
Χάρηκα πολύ.|Nice to meet you.
Από πού είσαι;|Where are you from?
Πόσο καιρό μένεις στην Ελλάδα;|How long have you lived in Greece?
Τα λέμε αργότερα.|See you later.
Καλή συνέχεια!|Have a good rest of your day!
Καλό βράδυ.|Have a good evening.
Καληνύχτα και όνειρα γλυκά.|Good night and sweet dreams.
Να 'σαι καλά!|Thanks, bless you! (lit. be well)
Χρόνια πολλά!|Happy birthday / name day / holidays!
Καλό μήνα!|Happy new month!
Καλή όρεξη!|Enjoy your meal!
Στην υγειά σου!|Cheers! / Bless you!
Περαστικά!|Get well soon!
Καλό ταξίδι!|Have a good trip!
Συγχαρητήρια!|Congratulations!
#3 Being polite
Ευχαριστώ πολύ.|Thank you very much.
Παρακαλώ.|Please / You're welcome.
Συγγνώμη, δεν κατάλαβα.|Sorry, I didn't understand.
Μπορείς να το πεις πιο αργά;|Can you say it more slowly?
Τι σημαίνει αυτή η λέξη;|What does this word mean?
Πώς το λένε αυτό στα ελληνικά;|What do you call this in Greek?
Με συγχωρείτε, μπορώ να ρωτήσω κάτι;|Excuse me, can I ask something?
Δεν πειράζει.|Never mind / It doesn't matter.
Τίποτα!|Not at all! (reply to thanks)
Με όλη μου την καρδιά.|With all my heart.
Έχεις δίκιο.|You're right.
Δεν έχεις άδικο.|You have a point.
#3 Café & restaurant
Ένα τραπέζι για τέσσερις, παρακαλώ.|A table for four, please.
Μπορούμε να δούμε τον κατάλογο;|Can we see the menu?
Τι μας προτείνετε;|What do you recommend?
Θα ήθελα έναν φρέντο εσπρέσο σκέτο.|I'd like a freddo espresso, no sugar.
Έναν ελληνικό μέτριο, παρακαλώ.|A Greek coffee, medium sweet, please.
Είναι πολύ νόστιμο!|It's very tasty!
Μπορούμε να έχουμε λίγο νερό;|Can we have some water?
Τον λογαριασμό, παρακαλώ.|The bill, please.
Κερνάω εγώ.|It's on me.
Θα τα πούμε μισά μισά;|Shall we split it?
Είμαι χορτοφάγος.|I'm vegetarian.
Έχει γλουτένη μέσα;|Does it contain gluten?
Δεν τρώω κρέας.|I don't eat meat.
Μια μερίδα πατάτες για το τραπέζι.|A portion of chips for the table.
#3 Shopping
Πόσο κάνει αυτό;|How much is this?
Πόσο κοστίζει;|How much does it cost?
Μπορώ να το δοκιμάσω;|Can I try it on?
Το έχετε σε άλλο χρώμα;|Do you have it in another colour?
Έχετε μεγαλύτερο νούμερο;|Do you have a bigger size?
Απλώς κοιτάζω, ευχαριστώ.|Just looking, thanks.
Θα το πάρω.|I'll take it.
Μπορώ να πληρώσω με κάρτα;|Can I pay by card?
Μου δίνετε απόδειξη;|Can I have a receipt?
Ένα κιλό ντομάτες, παρακαλώ.|A kilo of tomatoes, please.
Είναι φρέσκο;|Is it fresh?
#3 Getting around
Πού είναι η στάση του λεωφορείου;|Where is the bus stop?
Πώς πάω στο κέντρο;|How do I get to the centre?
Είναι μακριά από εδώ;|Is it far from here?
Στρίψτε δεξιά στο φανάρι.|Turn right at the traffic lights.
Πάτε ευθεία και μετά αριστερά.|Go straight on and then left.
Ένα εισιτήριο για Πειραιά, παρακαλώ.|A ticket to Piraeus, please.
Τι ώρα φεύγει το πλοίο;|What time does the ferry leave?
Έχει κίνηση σήμερα.|There's traffic today.
Χάθηκα.|I'm lost.
Μπορείτε να μου δείξετε στον χάρτη;|Can you show me on the map?
Σταματήστε εδώ, παρακαλώ.|Stop here, please.
#3 Plans & invitations
Τι κάνεις το Σάββατο;|What are you doing on Saturday?
Πάμε για καφέ;|Shall we go for a coffee?
Θέλεις να βγούμε απόψε;|Do you want to go out tonight?
Τι ώρα να έρθω;|What time should I come?
Ας βρεθούμε στις οχτώ.|Let's meet at eight.
Θα σε πάρω τηλέφωνο αργότερα.|I'll call you later.
Δεν μπορώ, έχω κανονίσει κάτι.|I can't, I've arranged something.
Ίσως την άλλη εβδομάδα.|Maybe next week.
Θα αργήσω λίγο, συγγνώμη.|I'll be a bit late, sorry.
Σε περιμένω έξω.|I'm waiting for you outside.
Τι λες, πάμε;|What do you say, shall we go?
#3 Opinions & conversation
Νομίζω ότι έχεις δίκιο.|I think you're right.
Κατά τη γνώμη μου...|In my opinion...
Δεν συμφωνώ καθόλου.|I don't agree at all.
Εξαρτάται.|It depends.
Μου φαίνεται λίγο περίεργο.|It seems a bit strange to me.
Δεν ξέρω τι να πω.|I don't know what to say.
Για να είμαι ειλικρινής...|To be honest...
Δεν το περίμενα αυτό.|I didn't expect that.
Αλήθεια; Σοβαρά;|Really? Seriously?
Τι εννοείς;|What do you mean?
Δηλαδή;|Meaning? / Like what?
Ας πούμε ότι...|Let's say that...
Με άλλα λόγια...|In other words...
Από τη μια... από την άλλη...|On the one hand... on the other...
Δεν έχει σημασία.|It doesn't matter.
Μου αρέσει πολύ αυτή η ιδέα.|I really like this idea.
#3 Feelings
Είμαι πτώμα σήμερα.|I'm dead tired today.
Βαριέμαι τρομερά.|I'm terribly bored.
Έχω άγχος για αύριο.|I'm stressed about tomorrow.
Χαίρομαι πολύ για σένα!|I'm really happy for you!
Λυπάμαι πολύ.|I'm very sorry.
Μου λείπεις.|I miss you.
Μου έλειψες!|I missed you!
Μη στενοχωριέσαι.|Don't be upset.
Ηρέμησε, όλα θα πάνε καλά.|Calm down, everything will be fine.
Έχω κέφια σήμερα.|I'm in a great mood today.
Δεν έχω όρεξη για τίποτα.|I'm not in the mood for anything.
Τα νεύρα μου!|I'm so annoyed!
#3 At home & family
Τι θα φάμε σήμερα;|What are we eating today?
Στρώσε το τραπέζι, σε παρακαλώ.|Lay the table, please.
Έφτασα σπίτι.|I'm home.
Πού έβαλες τα κλειδιά;|Where did you put the keys?
Κλείσε το φως.|Turn off the light.
Άνοιξε το παράθυρο, κάνει ζέστη.|Open the window, it's hot.
Έλα να φας!|Come and eat!
Μην ξεχάσεις να πάρεις ψωμί.|Don't forget to get bread.
Τηλεφώνησε στη γιαγιά σου.|Call your grandmother.
Πήγαινε για ύπνο, είναι αργά.|Go to bed, it's late.
Ξύπνα, θα αργήσεις!|Wake up, you'll be late!
#3 Work
Έχω πολλή δουλειά σήμερα.|I have a lot of work today.
Είμαι σε σύσκεψη, θα σε πάρω μετά.|I'm in a meeting, I'll call you after.
Μπορούμε να το συζητήσουμε αύριο;|Can we discuss it tomorrow?
Πότε είναι η προθεσμία;|When is the deadline?
Σου έστειλα email.|I sent you an email.
Θα το κοιτάξω και θα σου πω.|I'll look at it and let you know.
Πήρα άδεια για μια εβδομάδα.|I took a week off.
#3 Health & problems
Δεν νιώθω καλά.|I don't feel well.
Με πονάει το κεφάλι μου.|I have a headache.
Πρέπει να πάω στον γιατρό.|I need to go to the doctor.
Έχω πυρετό από χθες.|I've had a fever since yesterday.
Χάλασε το αυτοκίνητο.|The car broke down.
Έχασα το κινητό μου.|I lost my mobile.
Βοήθεια!|Help!
Καλέστε ασθενοφόρο!|Call an ambulance!
#3 Idioms
Τα κατάφερες!|You did it!
Έφαγα πόρτα.|I got rejected (lit. I ate a door).
Μου τη σπάει.|It gets on my nerves.
Κάνει τον Κινέζο.|He's playing dumb (lit. he's acting Chinese).
Στο φτερό.|On the go, in a rush (lit. on the wing).
Έχει τον νου του.|He's paying attention.
Τα έκανε θάλασσα.|He made a mess of it (lit. made it sea).
Έλα ντε!|Come on now! / Tell me about it!
Ό,τι να 'ναι.|Whatever / random rubbish.
Κόψε κάτι.|Tone it down (lit. cut something).
Πήρε τα βουνά.|He went crazy (lit. took to the mountains).
Μου έρχεται να...|I feel like (doing)...
Δεν μου καίγεται καρφί.|I couldn't care less (lit. not a nail burns for me).
Κάθε εμπόδιο για καλό.|Every obstacle is for the good.
Σιγά σιγά.|Slowly, little by little.
Υπομονή!|Be patient!
`;
