/* Language pack settings: Greek, from complete beginner (kids) to advanced (adult). Stages gate content. */
window.LANG = {
  code: 'el', name: 'Greek', native: 'Ελληνικά', flag: '🇬🇷', tts: 'el-GR', engine: 'Greek', audience: 'adult',
  hello: h => h < 12 ? 'Καλημέρα' : h < 18 ? 'Καλησπέρα' : 'Καλό βράδυ',
  dateLocale: 'el-GR',
  wordRe: /[\u0370-\u03FF\u1F00-\u1FFF]+/g,
  lookupUrl: w => 'https://en.wiktionary.org/wiki/' + encodeURIComponent(w) + '#Greek',
  addPlaceholder: 'e.g. η οδός, γράφω, ωραίος',
  writePlaceholder: 'Γράψε στα ελληνικά…',
  chatPlaceholder: 'Γράψε κάτι…',
  chatHello: 'Γεια σου! Pick a topic or just say hello in Greek.',
  topicStart: t => `Ας μιλήσουμε για: ${t}. Ξεκίνα εσύ.`,
  learner: 'The learner is an English-speaking adult at intermediate/advanced (B1–B2) level in Modern Greek. They struggle most with vocabulary retention, noun gender, declension, conjugation and irregular verbs. Use natural, everyday spoken Modern Greek, including common colloquial expressions.',
  tutorTopics: ['Free chat', 'My day', 'Food & cooking', 'Travel in Greece', 'Family', 'Work', 'Films & series', 'Football', 'Plans for the weekend', 'Greek news', 'Role-play: at a taverna', 'Role-play: at the doctor'],
  writingPrompts: ['Describe your perfect Sunday in Greece.', 'Write a message to a friend inviting them to dinner on Friday.', 'What did you do last weekend? Use the aorist.', 'Describe someone in your family: looks and character.', 'Write a short review of a restaurant or café you like.', 'What are your plans for next summer? Use θα.', 'Write a complaint email to a hotel about a noisy room.', 'Tell a funny story that happened to you.', 'Do you prefer the city or the village? Why?', 'Write a reply to an Instagram post about Greek food.', 'Explain how to make your favourite dish.', 'What would you change about where you live?'],
  formExample: 'πήγαμε or γυναικών',
  dictLevels: ['', 'kids starter', 'core', 'intermediate', 'advanced'],
  defaultStage: 4,
  alphabet: [['Α α', 'άλφα', 'a'], ['Β β', 'βήτα', 'v'], ['Γ γ', 'γάμμα', 'gh / y'], ['Δ δ', 'δέλτα', 'th (this)'], ['Ε ε', 'έψιλον', 'e'], ['Ζ ζ', 'ζήτα', 'z'], ['Η η', 'ήτα', 'ee'], ['Θ θ', 'θήτα', 'th (think)'], ['Ι ι', 'γιώτα', 'ee'], ['Κ κ', 'κάππα', 'k'], ['Λ λ', 'λάμδα', 'l'], ['Μ μ', 'μι', 'm'], ['Ν ν', 'νι', 'n'], ['Ξ ξ', 'ξι', 'ks'], ['Ο ο', 'όμικρον', 'o'], ['Π π', 'πι', 'p'], ['Ρ ρ', 'ρο', 'r'], ['Σ σ ς', 'σίγμα', 's'], ['Τ τ', 'ταυ', 't'], ['Υ υ', 'ύψιλον', 'ee'], ['Φ φ', 'φι', 'f'], ['Χ χ', 'χι', 'h (throaty)'], ['Ψ ψ', 'ψι', 'ps'], ['Ω ω', 'ωμέγα', 'o']],
  stages: [
    { id: 1, name: 'Kids starter', desc: 'Complete beginner: alphabet, first words', dict: 1, audience: 'kid', tenses: ['present'],
      learner: 'The learner is a child (about 8–12) who is a complete beginner in Greek and may still be learning the Greek alphabet (A1). Use very short, simple Greek sentences in the present tense with basic words (greetings, family, animals, colours, food, numbers). Give very simple, friendly English explanations and lots of encouragement. Keep everything playful and age-appropriate, and never ask for personal details such as their address, school name or surname.',
      tutorTopics: ['Say hello', 'My family', 'Animals', 'Colours', 'Food I like', 'Numbers', 'At the beach', 'A story together'],
      writingPrompts: ['Write your name and age in Greek.', 'Write 3 animals you like.', 'Who is in your family?', 'What food do you like?', 'What colour is your bag?'] },
    { id: 2, name: 'Kids explorer', desc: 'Reads Greek, building everyday words', dict: 2, audience: 'kid', tenses: ['present', 'aorist', 'future'],
      learner: 'The learner is a child (about 9–13) learning Greek at A1–A2 level who can read the alphabet. Use short, simple, everyday Greek, mostly present tense with some simple past (aorist) and future with θα. Very simple, encouraging English explanations. Keep content playful and age-appropriate and never ask for personal details.',
      tutorTopics: ['My day', 'School', 'Holidays in Greece', 'Food', 'Sport & games', 'Animals', 'A story together', 'Role-play: at the shop'] },
    { id: 3, name: 'Intermediate', desc: 'Adult B1: everyday conversation', dict: 3, audience: 'adult', tenses: ['present', 'imperfect', 'aorist', 'future', 'futcont', 'perfect', 'imperative'] },
    { id: 4, name: 'Advanced', desc: 'Adult B2+: everything, all tenses', dict: 4, audience: 'adult', tenses: ['present', 'imperfect', 'aorist', 'future', 'futcont', 'perfect', 'imperative'] }
  ]
};
