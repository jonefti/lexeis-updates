/* Greek grammar engine: gender guessing, noun/adjective declension, verb conjugation.
   Rule-based guesses; every form can be overridden by the user. */
(function (global) {
  'use strict';

  const TO_PLAIN = { 'ά': 'α', 'έ': 'ε', 'ή': 'η', 'ί': 'ι', 'ό': 'ο', 'ύ': 'υ', 'ώ': 'ω', 'ΐ': 'ϊ', 'ΰ': 'ϋ' };
  const TO_ACC = { 'α': 'ά', 'ε': 'έ', 'η': 'ή', 'ι': 'ί', 'ο': 'ό', 'υ': 'ύ', 'ω': 'ώ', 'ϊ': 'ΐ', 'ϋ': 'ΰ' };
  const VOWELS = 'αεηιουωϊϋ';
  const DIPH = ['αι', 'ει', 'οι', 'υι', 'ου', 'αυ', 'ευ', 'ηυ'];

  const lower = s => (s || '').toLocaleLowerCase('el').replace(/ς(?=\S)/g, 'σ');
  const strip = s => Array.from(lower(s)).map(c => TO_PLAIN[c] || c).join('');
  const finalSigma = s => s.replace(/σ(?=$|[\s.,;!?·)])/g, 'ς');

  // vowel groups on a word: [{start,end,acc}] (end exclusive)
  function groups(word) {
    const w = Array.from(lower(word));
    const out = [];
    let i = 0;
    while (i < w.length) {
      const c = w[i];
      const p = TO_PLAIN[c] || c;
      if (VOWELS.includes(p)) {
        let end = i + 1;
        const n = w[i + 1];
        if (n) {
          const pn = TO_PLAIN[n] || n;
          const pair = p + pn;
          // a diphthong if listed, second is not diaeresis, and the first letter is not accented
          if (DIPH.includes(pair) && n !== 'ϊ' && n !== 'ϋ' && n !== 'ΐ' && n !== 'ΰ' && !TO_PLAIN[c]) end = i + 2;
        }
        const acc = w.slice(i, end).some(ch => TO_PLAIN[ch] && ch !== 'ϊ' && ch !== 'ϋ');
        out.push({ start: i, end, acc });
        i = end;
      } else i++;
    }
    return out;
  }
  function stressIdx(word) { return groups(word).findIndex(g => g.acc); }

  // put stress on group idx (>=0 from start, <0 from end). Monosyllables get no accent.
  function stress(plainWord, idx) {
    const w = Array.from(strip(plainWord));
    const gs = groups(w.join(''));
    if (gs.length <= 1) return finalSigma(w.join(''));
    let k = idx < 0 ? gs.length + idx : idx;
    k = Math.max(0, Math.min(gs.length - 1, k));
    const g = gs[k];
    let pos = g.end - 1;
    // αυ/ευ: accent on the first vowel when followed by... no: modern Greek writes αύ/εύ. keep last.
    w[pos] = TO_ACC[w[pos]] || w[pos];
    return finalSigma(w.join(''));
  }
  const nGroups = w => groups(w).length;

  // Build a form: stem (plain) + ending (plain), with a stress rule.
  // rule: number (index from start), 'keep' (base index), 'final','penult','ante',
  // 'notAnte' (base antepenult or earlier -> penult, else keep), 'E' (first vowel of ending),
  // 'stemLast' (last vowel group of stem)
  function form(stem, ending, rule, base) {
    const plain = strip(stem) + strip(ending);
    const n = nGroups(plain);
    let idx;
    if (typeof rule === 'number') idx = rule;
    else switch (rule) {
      case 'keep': idx = base.s; break;
      case 'final': idx = -1; break;
      case 'penult': idx = -2; break;
      case 'ante': idx = -3; break;
      case 'notAnte': idx = base.e <= -3 ? -2 : base.s; break;
      case 'E': idx = nGroups(strip(stem)); break;
      case 'stemLast': idx = nGroups(strip(stem)) - 1; break;
      default: idx = base.s;
    }
    if (idx >= n) idx = n - 1;
    return stress(plain, idx);
  }

  function baseInfo(lemma) {
    const gs = groups(lemma);
    let s = gs.findIndex(g => g.acc);
    if (s < 0) s = gs.length - 1;
    return { s, e: s - gs.length, n: gs.length };
  }

  // ---------- nouns ----------
  const ARTICLES = {
    m: { sg: ['ο', 'του', 'τον', ''], pl: ['οι', 'των', 'τους', ''] },
    f: { sg: ['η', 'της', 'την', ''], pl: ['οι', 'των', 'τις', ''] },
    n: { sg: ['το', 'του', 'το', ''], pl: ['τα', 'των', 'τα', ''] }
  };
  const CASES = ['nom', 'gen', 'acc', 'voc'];
  const CASE_LABEL = { nom: 'Nominative', gen: 'Genitive', acc: 'Accusative', voc: 'Vocative' };
  const ART_TO_G = { 'ο': 'm', 'η': 'f', 'το': 'n', 'οι': 'm', 'τα': 'n' };
  const G_TO_ART = { m: 'ο', f: 'η', n: 'το' };

  // paradigms: ending removed from lemma, then [ending, rule] for sg nom..voc, pl nom..voc
  const P = {
    'm-os': { g: 'm', label: 'ο -ος (φίλος, άνθρωπος)', cut: 'ος',
      sg: [['ος', 'keep'], ['ου', 'notAnte'], ['ο', 'keep'], ['ε', 'keep']],
      pl: [['οι', 'keep'], ['ων', 'notAnte'], ['ους', 'notAnte'], ['οι', 'keep']] },
    'm-as': { g: 'm', label: 'ο -ας (πατέρας, άντρας)', cut: 'ας',
      sg: [['ας', 'keep'], ['α', 'keep'], ['α', 'keep'], ['α', 'keep']],
      pl: [['ες', 'keep'], ['ων', 'GENPL_AS'], ['ες', 'keep'], ['ες', 'keep']] },
    'm-as-ades': { g: 'm', label: 'ο -άς/-άδες (ψαράς)', cut: 'ας',
      sg: [['ας', 'final'], ['α', 'final'], ['α', 'final'], ['α', 'final']],
      pl: [['αδες', 'penult'], ['αδων', 'penult'], ['αδες', 'penult'], ['αδες', 'penult']] },
    'm-is': { g: 'm', label: 'ο -ης (ναύτης)', cut: 'ης',
      sg: [['ης', 'keep'], ['η', 'keep'], ['η', 'keep'], ['η', 'keep']],
      pl: [['ες', 'keep'], ['ων', 'final'], ['ες', 'keep'], ['ες', 'keep']] },
    'm-is-ox': { g: 'm', label: 'ο -ής (μαθητής)', cut: 'ης',
      sg: [['ης', 'final'], ['η', 'final'], ['η', 'final'], ['η', 'final']],
      pl: [['ες', 'final'], ['ων', 'final'], ['ες', 'final'], ['ες', 'final']] },
    'm-es': { g: 'm', label: 'ο -ές/-έδες (καφές)', cut: 'ες',
      sg: [['ες', 'final'], ['ε', 'final'], ['ε', 'final'], ['ε', 'final']],
      pl: [['εδες', 'penult'], ['εδων', 'penult'], ['εδες', 'penult'], ['εδες', 'penult']] },
    'm-eas': { g: 'm', label: 'ο -έας (συγγραφέας)', cut: 'εας',
      sg: [['εας', 'penult'], ['εα', 'penult'], ['εα', 'penult'], ['εα', 'penult']],
      pl: [['εις', 'final'], ['εων', 'penult'], ['εις', 'final'], ['εις', 'final']] },
    'm-ous': { g: 'm', label: 'ο -ούς (παππούς)', cut: 'ους',
      sg: [['ους', 'final'], ['ου', 'final'], ['ου', 'final'], ['ου', 'final']],
      pl: [['ουδες', 'penult'], ['ουδων', 'penult'], ['ουδες', 'penult'], ['ουδες', 'penult']] },
    'f-a': { g: 'f', label: 'η -α (θάλασσα, ώρα)', cut: 'α',
      sg: [['α', 'keep'], ['ας', 'keep'], ['α', 'keep'], ['α', 'keep']],
      pl: [['ες', 'keep'], ['ων', 'final'], ['ες', 'keep'], ['ες', 'keep']] },
    'f-i': { g: 'f', label: 'η -η (νίκη, φωνή)', cut: 'η',
      sg: [['η', 'keep'], ['ης', 'keep'], ['η', 'keep'], ['η', 'keep']],
      pl: [['ες', 'keep'], ['ων', 'final'], ['ες', 'keep'], ['ες', 'keep']] },
    'f-i-eis': { g: 'f', label: 'η -η/-εις (λέξη, πόλη)', cut: 'η',
      sg: [['η', 'keep'], ['ης', 'keep'], ['η', 'keep'], ['η', 'keep']],
      pl: [['εις', 'notAnte'], ['εων', 'ante'], ['εις', 'notAnte'], ['εις', 'notAnte']] },
    'f-os': { g: 'f', label: 'η -ος (οδός, μέθοδος)', cut: 'ος',
      sg: [['ος', 'keep'], ['ου', 'notAnte'], ['ο', 'keep'], ['ε', 'keep']],
      pl: [['οι', 'keep'], ['ων', 'notAnte'], ['ους', 'notAnte'], ['οι', 'keep']] },
    'n-o': { g: 'n', label: 'το -ο (βιβλίο, πρόσωπο)', cut: 'ο',
      sg: [['ο', 'keep'], ['ου', 'notAnte'], ['ο', 'keep'], ['ο', 'keep']],
      pl: [['α', 'keep'], ['ων', 'notAnte'], ['α', 'keep'], ['α', 'keep']] },
    'n-i': { g: 'n', label: 'το -ι (παιδί, σπίτι)', cut: 'ι',
      sg: [['ι', 'keep'], ['ιου', 'final'], ['ι', 'keep'], ['ι', 'keep']],
      pl: [['ια', 'NPL_I'], ['ιων', 'final'], ['ια', 'NPL_I'], ['ια', 'NPL_I']] },
    'n-ma': { g: 'n', label: 'το -μα (γράμμα, όνομα)', cut: 'α',
      sg: [['α', 'keep'], ['ατος', 'ante'], ['α', 'keep'], ['α', 'keep']],
      pl: [['ατα', 'ante'], ['ατων', 'penult'], ['ατα', 'ante'], ['ατα', 'ante']] },
    'n-os': { g: 'n', label: 'το -ος (δάσος, λάθος)', cut: 'ος',
      sg: [['ος', 'keep'], ['ους', 'notAnte'], ['ος', 'keep'], ['ος', 'keep']],
      pl: [['η', 'notAnte'], ['ων', 'final'], ['η', 'notAnte'], ['η', 'notAnte']] },
    'n-imo': { g: 'n', label: 'το -ιμο (γράψιμο)', cut: 'ο',
      sg: [['ο', 'keep'], ['ατος', 'ante'], ['ο', 'keep'], ['ο', 'keep']],
      pl: [['ατα', 'ante'], ['ατων', 'penult'], ['ατα', 'ante'], ['ατα', 'ante']] }
  };

  function splitArticle(input) {
    const t = (input || '').trim().replace(/\s+/g, ' ');
    const m = t.match(/^(ο|η|το|ὁ|ἡ|τὸ|οι|τα)\s+(.+)$/i);
    if (m) return { article: lower(m[1]), word: m[2] };
    return { article: '', word: t };
  }

  // guess paradigm for a noun from lemma (+ optional gender)
  function guessNoun(lemma, gender) {
    const p = strip(lemma);
    const ox = baseInfo(lemma).e === -1 && nGroups(lemma) > 1;
    const ends = s => p.endsWith(s);
    let key = null, conf = 'high';
    if (gender === 'f' && ends('ος')) key = 'f-os';
    else if (gender === 'n' && ends('ος')) key = 'n-os';
    else if (ends('ος')) { key = 'm-os'; conf = 'mid'; }
    else if (ends('εας')) key = 'm-eas';
    else if (ends('ας')) key = ox ? 'm-as-ades' : 'm-as';
    else if (ends('ης')) key = ox ? 'm-is-ox' : 'm-is';
    else if (ends('ες') && ox) key = 'm-es';
    else if (ends('ους') && ox) key = 'm-ous';
    else if (ends('ιμο')) key = 'n-imo';
    else if (ends('μα')) key = 'n-ma';
    else if (ends('α')) key = 'f-a';
    else if (ends('η')) key = (!ox && /(σ|ξ|ψ)η$/.test(p)) ? 'f-i-eis' : 'f-i';
    else if (ends('ο')) key = 'n-o';
    else if (ends('ι')) key = 'n-i';
    if (!key) return { key: null, gender: gender || '', conf: 'none' };
    let g = P[key].g;
    if (gender && gender !== g) return { key: null, gender, conf: 'none' };
    if (key === 'm-as' && nGroups(p) === 2) conf = conf === 'high' ? 'high' : conf;
    return { key, gender: g, conf };
  }

  function declineWith(lemma, key) {
    const par = P[key];
    if (!par) return null;
    const base = baseInfo(lemma);
    const plain = strip(lemma);
    const cut = par.cut;
    const stem = plain.endsWith(cut) ? plain.slice(0, plain.length - cut.length) : plain;
    const mk = ([end, rule]) => {
      if (rule === 'GENPL_AS') rule = base.n === 2 ? 'final' : 'notAnte';
      if (rule === 'NPL_I') rule = base.e === -1 ? 'final' : 'keep';
      return form(stem, end, rule, base);
    };
    const out = {};
    CASES.forEach((c, i) => { out['sg.' + c] = mk(par.sg[i]); out['pl.' + c] = mk(par.pl[i]); });
    out['sg.nom'] = finalSigma(lower(lemma)); // keep lemma exactly as written
    return out;
  }

  // ---------- adjectives (-ος -η/-α -ο) ----------
  function declineAdj(lemma) {
    const p = strip(lemma);
    if (!p.endsWith('ος')) return null;
    const base = baseInfo(lemma);
    const stem = p.slice(0, -2);
    const useA = /[αειουω]$/.test(stem) || /ι$/.test(stem);
    const m = declineWith(lemma, 'm-os');
    const femLemma = form(stem, useA ? 'α' : 'η', 'keep', base);
    const f = declineWith(femLemma, useA ? 'f-a' : 'f-i');
    f['pl.gen'] = m['pl.gen'];
    const neutLemma = form(stem, 'ο', 'keep', base);
    const n = declineWith(neutLemma, 'n-o');
    n['sg.gen'] = m['sg.gen']; n['pl.gen'] = m['pl.gen'];
    return { m, f, n };
  }

  // ---------- verbs ----------
  const PERSONS = ['εγώ', 'εσύ', 'αυτός', 'εμείς', 'εσείς', 'αυτοί'];
  const PERSON_EN = ['I', 'you', 'he/she', 'we', 'you (pl)', 'they'];
  const GROUPS = {
    A: 'A (-ω: γράφω)',
    AC: 'A, vowel stem (λέω, ακούω)',
    B1: 'B1 (-άω/-ώ: αγαπάω)',
    B2: 'B2 (-ώ/-είς: μπορώ)',
    PA: 'Passive -ομαι (έρχομαι)',
    PB: 'Passive -άμαι (κοιμάμαι)',
    PC: 'Passive -ούμαι (θεωρούμαι)',
    IRR: 'Irregular'
  };

  function guessVerbGroup(lemma) {
    const p = strip(lemma);
    if (['ειμαι', 'εχω', 'ξερω'].includes(p)) return 'IRR';
    if (p.endsWith('ομαι')) return 'PA';
    if (p.endsWith('αμαι') || p.endsWith('ιεμαι')) return 'PB';
    if (p.endsWith('ουμαι')) return 'PC';
    if (p.endsWith('αω')) return 'B1';
    if (/(αυ|ευ)ω$/.test(p)) return 'A';
    if (/(ουω|αιω|[αεοω]ω)$/.test(p)) return 'AC';
    if (/ώ$/.test(lower(lemma))) return 'B2';
    if (p.endsWith('ω')) return 'A';
    return null;
  }

  function presStem(lemma, grp) {
    const p = strip(lemma);
    switch (grp) {
      case 'A': case 'AC': return p.slice(0, -1);
      case 'B1': return p.endsWith('αω') ? p.slice(0, -2) : p.slice(0, -1);
      case 'B2': return p.slice(0, -1);
      case 'PA': return p.slice(0, -4);
      case 'PB': return p.endsWith('ιεμαι') ? p.slice(0, -4) : p.slice(0, -4);
      case 'PC': return p.slice(0, -5);
    }
    return p;
  }

  const B1_AOR = { 'γελ': 'γελασ', 'πειν': 'πεινασ', 'ξεχν': 'ξεχασ', 'περν': 'περασ', 'κρεμ': 'κρεμασ',
    'χαλ': 'χαλασ', 'διψ': 'διψασ', 'σπ': 'σπασ', 'φορ': 'φορεσ', 'μπορ': 'μπορεσ', 'καλ': 'καλεσ',
    'πον': 'πονεσ', 'κερν': 'κερασ', 'τραβ': 'τραβηξ', 'πηδ': 'πηδηξ', 'βουτ': 'βουτηξ', 'ρουφ': 'ρουφηξ',
    'φυσ': 'φυσηξ', 'βαρ': 'βαρεσ', 'αρκ': 'αρκεσ', 'πετ': 'πεταξ', 'κυλ': 'κυλησ' };

  // guess active aorist stem (plain) + confidence
  function guessAorStem(lemma, grp) {
    const st = presStem(lemma, grp);
    if (grp === 'B1' || grp === 'B2') {
      if (B1_AOR[st]) return { stem: B1_AOR[st], conf: 'high' };
      return { stem: st + 'ησ', conf: grp === 'B2' ? 'mid' : 'high' };
    }
    if (grp === 'AC') return { stem: st + 'σ', conf: 'low' };
    if (grp === 'PA' || grp === 'PB' || grp === 'PC') return null;
    const R = [
      [/(φτ|πτ|φ|π|β)$/, 'ψ', 'high'], [/ευ$/, 'εψ', 'high'], [/αυ$/, 'αψ', 'high'],
      [/αιζ$/, 'αιξ', 'high'], [/(γγ|γ|χν|χ|κ|σσ|ττ)$/, 'ξ', 'mid'],
      [/(αλλαζ|κοιταζ|φωναζ|σφαζ|βυζ|τριζ|σφυριζ)$/, null, 'mid'],
      [/ζ$/, 'σ', 'mid'], [/θ$/, 'σ', 'mid'], [/ων$/, 'ωσ', 'high'],
      [/σκ$/, 'ξ', 'low'], [/ν$/, 'σ', 'low']
    ];
    for (const [re, rep, conf] of R) {
      if (re.test(st)) {
        if (rep === null) return { stem: st.slice(0, -1) + 'ξ', conf };
        return { stem: st.replace(re, rep), conf };
      }
    }
    return { stem: st + 'σ', conf: 'low' };
  }

  // past-tense forms with antepenult stress and syllabic augment when needed
  const PAST_END = ['α', 'ες', 'ε', 'αμε', 'ατε', 'αν'];
  function pastForms(stem, endings, augmentable) {
    endings = endings || PAST_END;
    return endings.map(e => {
      let w = strip(stem) + e;
      if (nGroups(w) < 3 && augmentable && !VOWELS.includes(w[0])) w = 'ε' + w;
      return stress(w, -3);
    });
  }

  // derive past forms from a user-given 1sg (e.g. ήρθα, έφυγα, είπα)
  function pastFrom1sg(first) {
    const f = lower(first).trim();
    if (!f.endsWith('α')) return null;
    let st = strip(f).slice(0, -1);
    const aug = /^έ[^αεηιουωάέήίόύώ]/.test(f);
    let core = st, canAug = false;
    if (aug) { core = st.slice(1); canAug = true; }
    const forms = PAST_END.map(e => {
      let w = core + e;
      if (canAug && nGroups(w) < 3) w = 'ε' + w;
      return stress(w, -3);
    });
    forms[0] = f;
    return forms;
  }

  // future/subjunctive persons from a 1sg (γράψω, πω, έρθω, αγαπήσω)
  function futFrom1sg(first) {
    const f = lower(first).trim().replace(/^θα\s+/, '');
    if (!/[ωώ]$/.test(f)) return null;
    const st = strip(f).slice(0, -1);
    const endStress = /ώ$/.test(f) || nGroups(f) === 1;
    const E = endStress ? ['ω', 'εις', 'ει', 'ουμε', 'ειτε', 'ουν'] : ['ω', 'εις', 'ει', 'ουμε', 'ετε', 'ουν'];
    const fs = E.map(e => endStress ? form(st, e, 'E') : form(st, e, 'stemLast'));
    fs[0] = f;
    return { forms: fs, perfectPart: endStress ? form(st, 'ει', 'E') : form(st, 'ει', 'stemLast') };
  }

  const TENSES = ['present', 'imperfect', 'aorist', 'future', 'futcont', 'perfect', 'imperative'];
  const TENSE_LABEL = {
    present: 'Present', imperfect: 'Imperfect (past continuous)', aorist: 'Aorist (simple past)',
    future: 'Future (θα + aorist)', futcont: 'Future continuous (θα + present)',
    perfect: 'Perfect (έχω + …)', imperative: 'Imperative'
  };
  const ECHO = ['έχω', 'έχεις', 'έχει', 'έχουμε', 'έχετε', 'έχουν'];

  // ov: {imperfect, aorist, future} 1sg overrides
  const SPECIAL = {
    'ειμαι': { group: 'IRR', tenses: {
      present: ['είμαι', 'είσαι', 'είναι', 'είμαστε', 'είστε', 'είναι'],
      imperfect: ['ήμουν', 'ήσουν', 'ήταν', 'ήμασταν', 'ήσασταν', 'ήταν'],
      future: ['θα είμαι', 'θα είσαι', 'θα είναι', 'θα είμαστε', 'θα είστε', 'θα είναι'],
      imperative: ['', 'να είσαι', '', '', 'να είστε', ''] }, conf: {} },
    'εχω': { group: 'IRR', tenses: {
      present: ['έχω', 'έχεις', 'έχει', 'έχουμε', 'έχετε', 'έχουν'],
      imperfect: ['είχα', 'είχες', 'είχε', 'είχαμε', 'είχατε', 'είχαν'],
      future: ['θα έχω', 'θα έχεις', 'θα έχει', 'θα έχουμε', 'θα έχετε', 'θα έχουν'],
      imperative: ['', 'έχε', '', '', 'έχετε', ''] }, conf: {} },
    'ξερω': { group: 'IRR', tenses: {
      present: ['ξέρω', 'ξέρεις', 'ξέρει', 'ξέρουμε', 'ξέρετε', 'ξέρουν'],
      imperfect: ['ήξερα', 'ήξερες', 'ήξερε', 'ξέραμε', 'ξέρατε', 'ήξεραν'],
      future: ['θα ξέρω', 'θα ξέρεις', 'θα ξέρει', 'θα ξέρουμε', 'θα ξέρετε', 'θα ξέρουν'] }, conf: {} }
  };
  function conjugate(lemma, grp, ov) {
    ov = ov || {};
    const sp = SPECIAL[strip(lemma)];
    if (sp) return JSON.parse(JSON.stringify(sp));
    if (grp === 'IRR') grp = null;
    grp = grp || guessVerbGroup(lemma);
    if (!grp) return null;
    const base = baseInfo(lemma);
    const st = presStem(lemma, grp);
    const T = {};
    const conf = {};
    // present
    let pres;
    switch (grp) {
      case 'A': pres = ['ω', 'εις', 'ει', 'ουμε', 'ετε', 'ουν'].map(e => form(st, e, 'keep', base)); break;
      case 'AC': pres = ['ω', 'ς', 'ει', 'με', 'τε', 'νε'].map(e => form(st, e, 'keep', base)); break;
      case 'B1': pres = ['αω', 'ας', 'αει', 'αμε', 'ατε', 'ανε'].map(e => form(st, e, 'E')); break;
      case 'B2': pres = ['ω', 'εις', 'ει', 'ουμε', 'ειτε', 'ουν'].map(e => form(st, e, 'E')); break;
      case 'PA': pres = [['ομαι', 'ante'], ['εσαι', 'ante'], ['εται', 'ante'], ['ομαστε', 'E'], ['εστε', 'ante'], ['ονται', 'ante']].map(([e, r]) => form(st, e, r)); break;
      case 'PB': pres = ['αμαι', 'ασαι', 'αται', 'ομαστε', 'αστε', 'ουνται'].map(e => form(st, e, 'E')); break;
      case 'PC': pres = ['ουμαι', 'εισαι', 'ειται', 'ουμαστε', 'ειστε', 'ουνται'].map(e => form(st, e, 'E')); break;
    }
    pres[0] = finalSigma(lower(lemma));
    T.present = pres;
    const passive = grp[0] === 'P';
    // imperfect
    if (ov.imperfect && pastFrom1sg(ov.imperfect)) T.imperfect = pastFrom1sg(ov.imperfect);
    else if (grp === 'A') T.imperfect = pastForms(st, null, true);
    else if (grp === 'AC') { T.imperfect = pastForms(st + 'γ', null, true); conf.imperfect = 'mid'; }
    else if (grp === 'B1' || grp === 'B2') T.imperfect = ['ουσα', 'ουσες', 'ουσε', 'ουσαμε', 'ουσατε', 'ουσαν'].map(e => form(st, e, 'E'));
    else if (grp === 'PC') T.imperfect = ['ουμουν', 'ουσουν', 'ουνταν', 'ουμασταν', 'ουσασταν', 'ουνταν'].map(e => form(st, e, 'E'));
    else T.imperfect = ['ομουν', 'οσουν', 'οταν', 'ομασταν', 'οσασταν', 'ονταν'].map(e => form(st, e, 'E'));
    if (ov.imperfect && T.imperfect) T.imperfect[0] = lower(ov.imperfect);
    // aorist
    let aorStem = null;
    if (ov.aorist && pastFrom1sg(ov.aorist)) { T.aorist = pastFrom1sg(ov.aorist); }
    else if (!passive) {
      const g = guessAorStem(lemma, grp);
      aorStem = g.stem; conf.aorist = g.conf;
      T.aorist = pastForms(aorStem, null, true);
    } else {
      // passive aorist guess: σκέφτομαι -> σκέφτηκα, χρειάζομαι -> χρειάστηκα, ντύνομαι -> ντύθηκα
      let s = st;
      if (/ζ$/.test(s)) s = s.slice(0, -1) + 'στ';
      else if (/ν$/.test(s)) s = s.slice(0, -1) + 'θ';
      else if (grp === 'PB' || grp === 'PC') s = s + 'ηθ';
      aorStem = s + 'η';
      conf.aorist = 'low';
      T.aorist = pastForms(aorStem + 'κ', null, false);
    }
    // future
    let perfPart;
    const fut = ov.future ? futFrom1sg(ov.future) : null;
    if (fut) { T.future = fut.forms; perfPart = fut.perfectPart; }
    else if (ov.aorist) {
      // derive future from overridden aorist: drop augment, stress like present
      const f1 = pastFrom1sg(ov.aorist);
      let s = strip(f1[3]).replace(/αμε$/, '');
      if (passive) {
        s = s.replace(/ηκ$/, '');
        T.future = ['ω', 'εις', 'ει', 'ουμε', 'ειτε', 'ουν'].map(e => form(s, e, 'E'));
        perfPart = form(s, 'ει', 'E');
      } else {
        T.future = ['ω', 'εις', 'ει', 'ουμε', 'ετε', 'ουν'].map(e => form(s, e, 'stemLast'));
        perfPart = form(s, 'ει', 'stemLast');
      }
      conf.future = 'mid';
    } else if (passive) {
      const s = aorStem.replace(/η$/, '');
      T.future = ['ω', 'εις', 'ει', 'ουμε', 'ειτε', 'ουν'].map(e => form(s, e, 'E'));
      perfPart = form(s, 'ει', 'E');
      conf.future = 'low';
    } else {
      T.future = ['ω', 'εις', 'ει', 'ουμε', 'ετε', 'ουν'].map(e => form(aorStem, e, 'stemLast'));
      perfPart = form(aorStem, 'ει', 'stemLast');
      conf.future = conf.aorist;
    }
    T.future = T.future.map(x => 'θα ' + x);
    T.futcont = T.present.map(x => 'θα ' + x);
    T.perfect = ECHO.map(x => x + ' ' + perfPart);
    // imperative (aorist): sg + pl
    if (!passive && aorStem) {
      T.imperative = ['', form(aorStem, 'ε', 'ante'), '', '', form(aorStem, 'τε', 'stemLast'), ''];
      conf.imperative = conf.aorist;
    } else if (!passive && T.future) {
      const s = strip(T.future[3]).replace(/^θα\s+/, '').replace(/ουμε$/, '');
      T.imperative = ['', form(s, 'ε', 'ante'), '', '', form(s, 'τε', 'stemLast'), ''];
      conf.imperative = 'low';
    }
    return { group: grp, tenses: T, conf };
  }

  // ---------- public helpers ----------
  function analyse(input, opts) {
    opts = opts || {};
    const { article, word } = splitArticle(input);
    const w = word.trim();
    let pos = opts.pos;
    const single = !/\s/.test(w);
    if (!pos) {
      if (article) pos = 'noun';
      else if (single && guessVerbGroup(w) && /(ω|ώ|μαι)$/.test(lower(w))) pos = 'verb';
      else if (single && /(ος|ός)$/.test(lower(w))) pos = 'noun';
      else if (single && guessNoun(w).key) pos = 'noun';
      else pos = 'other';
    }
    const gender = opts.gender || ART_TO_G[article] || '';
    const res = { lemma: w, article, pos };
    if (pos === 'noun') {
      const g = guessNoun(w, gender);
      res.gender = g.gender; res.paradigm = opts.paradigm || g.key; res.conf = g.conf;
    } else if (pos === 'verb') {
      res.group = opts.group || guessVerbGroup(w);
    }
    return res;
  }

  function sameExceptAccent(a, b) {
    return strip(a).replace(/ς/g, 'σ') === strip(b).replace(/ς/g, 'σ');
  }
  function norm(s) { return finalSigma(lower(s).trim().replace(/\s+/g, ' ')); }

  global.Greek = {
    strip, lower, stress, stressIdx, groups, splitArticle, guessNoun, declineWith, declineAdj,
    guessVerbGroup, conjugate, analyse, sameExceptAccent, norm, pastFrom1sg, futFrom1sg,
    PARADIGMS: P, ARTICLES, CASES, CASE_LABEL, G_TO_ART, ART_TO_G, PERSONS, PERSON_EN,
    GROUPS, TENSES, TENSE_LABEL,
    TENSE_HINT: {
      present: { what: 'Now, or something you do regularly', ex: ['I write', 'you write', 'he/she writes', 'we write', 'you (all) write', 'they write'] },
      imperfect: { what: 'Past, but ongoing or repeated (was …ing / used to)', ex: ['I was writing', 'you were writing', 'he/she was writing', 'we were writing', 'you were writing', 'they were writing'] },
      aorist: { what: 'Past, happened once and finished', ex: ['I wrote', 'you wrote', 'he/she wrote', 'we wrote', 'you wrote', 'they wrote'] },
      future: { what: 'Future, one time (θα + simple form)', ex: ['I will write', 'you will write', 'he/she will write', 'we will write', 'you will write', 'they will write'] },
      futcont: { what: 'Future, ongoing or regularly', ex: ['I will be writing', 'you will be writing', 'he/she will be writing', 'we will be writing', 'you will be writing', 'they will be writing'] },
      perfect: { what: 'Has/have done (έχω + …)', ex: ['I have written', 'you have written', 'he/she has written', 'we have written', 'you have written', 'they have written'] },
      imperative: { what: 'A command', ex: ['', 'write! (to one person)', '', '', 'write! (to several people, or politely)', ''] }
    },
    CASE_HINT: { nom: 'the subject: who or what does it', gen: '"of" or \'s: whose it is', acc: 'the object, and after most prepositions (σε, με, για…)', voc: 'calling someone: "Hey, …!"' },
    GENDERS: ['m', 'f', 'n'], art: (lemma, g) => G_TO_ART[g] || ''
  };
})(typeof window !== 'undefined' ? window : globalThis);
