window.APP_BUILD = 6; window.APP_VERSION = '2.3.1';
