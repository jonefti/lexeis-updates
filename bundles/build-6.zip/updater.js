/* Over-the-air updates: downloads new app versions (everything except native code) from the public updates repo. */
(function () {
  'use strict';
  const A = window.App;
  const FEED = 'https://raw.githubusercontent.com/jonefti/lexeis-updates/main/latest.json';
  let U = null;
  try { if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) U = window.Capacitor.registerPlugin('CapacitorUpdater'); } catch (e) { U = null; }
  const build = window.APP_BUILD || 0;
  let pending = null, busy = false;

  async function check(manual) {
    if (!U) { if (manual) A.toast('Updates work in the installed app'); return; }
    if (busy) return; busy = true;
    try {
      const res = await fetch(FEED + '?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) throw new Error('feed');
      const j = await res.json();
      if (!(j.build > build)) { if (manual) A.toast('You have the latest version'); return; }
      const native = +(localStorage.getItem('lexeis.nativeBuild') || 0);
      if (j.minNative && native && native < j.minNative) {
        A.sheet(`<h2>New version needs a reinstall</h2><p class="muted">This update changes the app itself, so it can't install over the air. Download the new APK and install it over this one; your words are kept.</p><div class="row-btns"><button class="btn primary" data-act="open-url" data-url="${A.esc(j.apk || '')}">Download APK</button><button class="btn ghost" data-act="sheet-close">Later</button></div>`);
        return;
      }
      if (manual) A.toast('Downloading update…');
      const bundle = await U.download({ url: j.url, version: String(j.build) });
      pending = bundle;
      A.sheet(`<h2>Update ready ✨</h2><p class="muted">${A.esc(j.notes || 'A new version of the app is ready.')}</p><div class="row-btns"><button class="btn primary" data-act="upd-now">Restart now</button><button class="btn ghost" data-act="upd-later">Next time</button></div>`);
    } catch (e) {
      if (manual) A.toast('Could not check for updates. Are you online?');
    } finally { busy = false; }
  }
  A.acts['upd-now'] = async () => { if (!pending) return; A.save(); try { await U.set({ id: pending.id }); } catch (e) { A.toast('Update failed: ' + e.message); } };
  A.acts['upd-later'] = async () => { if (!pending) return; try { await U.next({ id: pending.id }); } catch (e) { /* ignore */ } A.closeSheet(); A.toast('It will update next time you open the app'); };
  A.checkUpdates = () => check(true);

  if (U) {
    U.notifyAppReady().catch(() => {});
    U.current().then(c => { if (c && c.bundle && c.bundle.id === 'builtin') localStorage.setItem('lexeis.nativeBuild', String(build)); }).catch(() => {});
    setTimeout(() => check(false), 4000);
  }
})();
