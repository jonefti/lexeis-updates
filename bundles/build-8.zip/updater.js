/* Over-the-air updates: downloads new app versions (everything except native code) from the public updates repo. */
(function () {
  'use strict';
  const A = window.App;
  const FEED = 'https://raw.githubusercontent.com/jonefti/lexeis-updates/main/latest.json';
  let U = null;
  U = A.plugin ? A.plugin('CapacitorUpdater') : null;
  const build = window.APP_BUILD || 0;
  let pending = null, busy = false;

  function status(msg, ok) {
    try { localStorage.setItem('lexeis.updStatus', JSON.stringify({ at: Date.now(), msg, ok: !!ok })); } catch (e) { /* ignore */ }
    const el = document.getElementById('updStatus'); if (el) el.textContent = msg;
  }
  A.updateStatus = () => { try { const s = JSON.parse(localStorage.getItem('lexeis.updStatus')); return s ? new Date(s.at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) + ': ' + s.msg : 'Not checked yet'; } catch (e) { return 'Not checked yet'; } };
  function offerApk(j, why) {
    A.sheet(`<h2>New version available</h2><p class="muted">${A.esc(why)}</p><p class="muted">Download the latest version and install it over this one; your words are kept.</p><div class="row-btns"><button class="btn primary" data-act="open-url" data-url="${A.esc((j && j.apk) || A.APK_URL)}">Download the latest version</button><button class="btn ghost" data-act="sheet-close">Later</button></div>`);
  }
  async function check(manual) {
    if (!U) { if (manual) A.toast('Updates work in the installed app'); status('Updater not available in this version'); return; }
    if (busy) return; busy = true;
    let j = null, step = 'reading the update feed';
    try {
      const res = await fetch(FEED + '?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) throw new Error('feed returned HTTP ' + res.status);
      j = await res.json();
      if (!(j.build > build)) { status(`Up to date (build ${build})`, true); if (manual) A.toast('You have the latest version'); return; }
      const native = +(localStorage.getItem('lexeis.nativeBuild') || 0);
      if (j.minNative && native && native < j.minNative) { status(`Build ${j.build} needs a reinstall`); offerApk(j, 'This update changes the app itself, so it needs a quick reinstall.'); return; }
      step = 'downloading build ' + j.build;
      if (manual) A.toast('Downloading update…');
      const bundle = await U.download({ url: j.url, version: String(j.build) });
      pending = bundle;
      status(`Build ${j.build} downloaded, ready to install`, true);
      A.sheet(`<h2>Update ready ✨</h2><p class="muted">${A.esc(j.notes || 'A new version of the app is ready.')}</p><div class="row-btns"><button class="btn primary" data-act="upd-now">Restart now</button><button class="btn ghost" data-act="upd-later">Next time</button></div>`);
    } catch (e) {
      const msg = `Failed while ${step}: ${(e && (e.message || e.errorMessage || e.code)) || String(e)}`;
      status(msg);
      if (manual) { if (j && j.build > build) offerApk(j, msg); else A.toast(msg); }
    } finally { busy = false; }
  }
  A.acts['upd-now'] = async () => { if (!pending) return; A.save(); status('Installing build ' + pending.version); try { await U.set({ id: pending.id }); } catch (e) { status('Install failed: ' + (e && e.message)); offerApk(null, 'Install failed: ' + (e && e.message)); } };
  A.acts['upd-later'] = async () => { if (!pending) return; try { await U.next({ id: pending.id }); } catch (e) { /* ignore */ } A.closeSheet(); A.toast('It will update next time you open the app'); };
  A.checkUpdates = () => check(true);

  if (U) {
    U.notifyAppReady().catch(() => {});
    U.current().then(c => { if (c && c.bundle && c.bundle.id === 'builtin') localStorage.setItem('lexeis.nativeBuild', String(build)); }).catch(() => {});
    setTimeout(() => check(false), 4000);
  }
})();
