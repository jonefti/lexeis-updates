/* Views: today, words & dictionary, add/edit, word page, review, inbox, share */
(function () {
  'use strict';
  const A = window.App, G = A.G, esc = A.esc;
  A.acts = {}; A.forms = {}; A.changes = {}; A.inputs = {};

  // ---------------- TODAY ----------------
  A.routes.today = function () {
    const db = A.db, q = A.dueQueue();
    const n = q.due.length + q.fresh.length;
    const xp = A.todayXp(), goal = db.settings.goal, s = A.streak();
    const now = new Date();
    const date0 = now.toLocaleDateString(A.LANG.dateLocale, { weekday: 'long', day: 'numeric', month: 'long' }); const date = date0.charAt(0).toLocaleUpperCase() + date0.slice(1);
    const wod = A.wordsOfDay();
    const trouble = A.troubleWords();
    const irr = A.irregularOfDay();
    const ph = A.phraseOfDay();
    A.view().innerHTML = `
      <header class="hero">
        <div class="hero-text">
          <span class="hero-chips"><a class="lang-chip" href="#/settings" aria-label="Change language">${A.LANG.flag} ${esc(A.LANG.name)} ▾</a><a class="lang-chip gear" href="#/settings" aria-label="Settings">⚙️ Settings</a></span>
          <p class="hero-date">${esc(date)}</p>
          <h1>${esc(A.LANG.hello(now.getHours()))}</h1>
          <p class="hero-sub">${xp >= goal ? 'Daily goal reached. Ωραία!' : `${goal - xp} points to today's goal`}</p>
        </div>
        <a class="hero-ring" href="#/progress" aria-label="Today's progress">${A.ring(xp, goal, 92, 'Daily goal')}<span class="ring-num">${Math.min(xp, 999)}<small>/${goal}</small></span></a>
        <div class="meander" aria-hidden="true"></div>
      </header>
      <section class="review-cta ${n ? '' : 'done'}">
        ${db.words.length === 0 ? `
          <div><p class="cta-title">Start your word book</p><p class="cta-sub">Save a word of the day below, search the dictionary, or add something you just heard.</p></div>
          <a class="btn sun" href="#/words/dict">Open dictionary</a>
        ` : n ? `
          <div><p class="cta-title"><span class="big-num">${n}</span> to review</p><p class="cta-sub">${q.due.length} due · ${q.fresh.length} new</p></div>
          <a class="btn sun" href="#/review">Start</a>
        ` : `
          <div><p class="cta-title">Reviews done ✓</p><p class="cta-sub">Next due ${A.nextDueText()}. Keep going with a flash test.</p></div>
          <a class="btn sun" href="#/flash">Flash test</a>
        `}
      </section>
      <a class="streak-strip ${A.doneToday() ? 'lit' : ''}" href="#/badges">
        <span class="flame">${A.doneToday() ? '🔥' : s ? '🔥' : '🌑'}<b>${s}</b></span>
        <span class="week">${A.weekDots().map(d => `<span class="wd ${d.state}"><i>${d.state === 'done' ? '✓' : d.state === 'frozen' ? '🧊' : ''}</i><small>${d.label}</small></span>`).join('')}</span>
        <span class="lvl-pill">Lv ${A.levelInfo().level}</span>
      </a>
      <div class="mascot"><span class="m-face">${A.mascot.e}</span><p class="m-bubble">${esc(A.mascot.line())}</p></div>
      ${!A.remSettings().reminders && !A.global.remDismissed && A.db.words.length ? `<div class="rem-card"><span>🔔</span><p><strong>Get a daily reminder?</strong><br><small>Okto will nudge you so you don't lose your streak.</small></p><button class="btn sm primary" data-act="rem-on">Turn on</button><button class="icon-btn sm" data-act="rem-dismiss" aria-label="No thanks">✕</button></div>` : ''}


      <section>
        <div class="sec-head"><h2>Words of the day</h2><button class="linkish" data-act="speak-wod">Listen</button></div>
        <div class="wod-row">${wod.map(e => `
          <article class="wod g-tile-${e.gender || (e.pos === 'verb' ? 'v' : 'a')}">
            <button class="wod-main" data-act="open-entry" data-l="${esc(e.lemma)}">
              <span class="wod-art">${e.emoji ? `<span class="wod-emo">${e.emoji}</span>` : ''}${e.gender ? A.art(e.lemma, e.gender) : e.pos === 'verb' ? 'verb' : e.pos === 'adj' ? 'adj.' : ''}</span>
              <span class="wod-word" lang="${A.LANG.code}">${esc(e.lemma)}</span>
              <span class="wod-mean">${esc(e.meaning)}</span>
            </button>
            <button class="wod-add" data-act="add-entry" data-l="${esc(e.lemma)}" aria-label="Add ${esc(e.lemma)} to my words">+ Add</button>
          </article>`).join('')}</div>
      </section>

      <section>
        <h2>Remember today</h2>
        <ul class="remember">
          <li class="rm tip"><span class="rm-ico">💡</span><div><p class="rm-k">Grammar tip</p><p lang="${A.LANG.code}">${esc(A.tipOfDay())}</p></div></li>
          ${trouble.length ? `<li class="rm"><span class="rm-ico">🎯</span><div><p class="rm-k">Words you keep missing</p><p class="rm-words">${trouble.map(w => `<a href="#/word/${w.id}" lang="${A.LANG.code}">${A.headword(w)}</a> <span class="muted">${esc(w.meaning)}</span>`).join('<br>')}</p></div></li>` : ''}
          ${irr ? `<li class="rm"><span class="rm-ico">⚡</span><div><p class="rm-k">Irregular verb</p><p lang="${A.LANG.code}"><button class="linkish strong" data-act="open-entry" data-l="${esc(irr.lemma)}">${esc(irr.lemma)}</button> → ${esc(irr.line)} <span class="muted">${esc(irr.meaning)}</span></p></div></li>` : ''}
          ${ph ? `<li class="rm"><span class="rm-ico">💬</span><div><p class="rm-k">Say it today</p><p lang="${A.LANG.code}"><button class="linkish strong" data-act="speak" data-t="${esc(ph.gr)}">${esc(ph.gr)}</button><br><span class="muted">${esc(ph.en)}</span></p></div></li>` : ''}
        </ul>
      </section>

      <section class="capture">
        <h2>Quick capture</h2>
        <form data-form="capture" class="capture-form">
          <input name="text" placeholder="A word you just heard or read" autocomplete="off" autocapitalize="off" lang="${A.LANG.code}" required>
          <input name="ctx" placeholder="The sentence or where (optional)" autocomplete="off" lang="${A.LANG.code}">
          <button class="btn primary" type="submit">Save to inbox</button>
        </form>
        ${db.inbox.length ? `<a class="inbox-link" href="#/inbox"><strong>${db.inbox.length}</strong> in your inbox, waiting to be filed</a>` : ''}
      </section>

      <section class="quick-grid">
        <a href="#/flash" class="qtile t-sea"><span class="qt-ico">⚡</span><span>Flash test</span></a>
        <a href="#/read/${A.readings[A.dayIndex() % Math.max(1, A.readings.length)]?.id || ''}" class="qtile t-olive"><span class="qt-ico">📖</span><span>Today's read</span></a>
        <a href="#/grammar" class="qtile t-pom"><span class="qt-ico">🧩</span><span>Grammar</span></a>
        <a href="#/tutor" class="qtile t-sun"><span class="qt-ico">✨</span><span>Talk with Claude</span></a>
      </section>`;
  };
  A.acts['speak-wod'] = () => A.speak(A.wordsOfDay().map(e => A.entryHead(e)).join('. '));
  A.forms.capture = function (f, fd) {
    const text = (fd.get('text') || '').trim(); if (!text) return;
    A.db.inbox.push({ id: A.uid(), text, context: (fd.get('ctx') || '').trim(), source: 'Quick capture', created: Date.now() });
    A.save(); A.toast('Saved to inbox'); A.render();
  };

  // ---------------- WORDS & DICTIONARY ----------------
  let wordFilter = 'all', wordSearch = '';
  A.routes.words = function (arg) {
    const mode = arg === 'dict' ? 'dict' : 'mine';
    const filters = [['all', 'All']].concat(G.GENDERS.map(g => [g, G.G_TO_ART[g]])).concat([ ['verb', 'Verbs'], ['adj', 'Adjectives'], ['irr', 'Irregular'], ['other', 'Phrases']]);
    A.view().innerHTML = `
      <header class="top"><h1>Words</h1></header>
      <div class="seg big" role="tablist">
        <a href="#/words" class="${mode === 'mine' ? 'on' : ''}" role="tab">My words <span class="pill">${A.db.words.length}</span></a>
        <a href="#/words/dict" class="${mode === 'dict' ? 'on' : ''}" role="tab">Dictionary <span class="pill">${A.dict.length}</span></a>
      </div>
      <input class="search" type="search" placeholder="${mode === 'dict' ? `Search ${A.LANG.name} (any form) or English` : 'Search your words'}" value="${esc(wordSearch)}" data-input="search" lang="${A.LANG.code}" autocapitalize="off">
      ${mode === 'mine' ? `<div class="chips">${filters.map(([k, l]) => `<button class="chip ${wordFilter === k ? 'on' : ''} ${['m', 'f', 'n'].includes(k) ? 'g-' + k : ''}" data-act="filter" data-f="${k}">${l}</button>`).join('')}</div>` : `<p class="tiny">Type any form, like ${esc(A.LANG.formExample || '')}, and it finds the dictionary word.</p>`}
      <ul class="list words" id="wordlist"></ul>`;
    A.view().dataset.mode = mode;
    fillWords();
  };
  function fillWords() {
    const el = A.$('#wordlist'); if (!el) return;
    const mode = A.view().dataset.mode;
    if (mode === 'dict') {
      const res = wordSearch.trim() ? A.searchDict(wordSearch) : topicList();
      if (Array.isArray(res) && res.length && res[0].topicHeader !== undefined) { el.innerHTML = res.map(t => `<li class="topic-head">${esc(t.topicHeader)}</li>` + t.items.map(dictRow).join('')).join(''); return; }
      el.innerHTML = res.length ? res.map(dictRow).join('') : `<li class="empty">Not in the dictionary.<div class="row-btns"><button class="btn sm" data-act="ask-lookup" data-t="${esc(wordSearch)}">✨ Ask Claude</button><button class="btn sm" data-act="open-url" data-url="${esc(A.LANG.lookupUrl(wordSearch.trim()))}">Wiktionary</button><a class="btn sm" href="#/add/${encodeURIComponent(wordSearch.trim())}">Add it myself</a></div></li>`;
      return;
    }
    const s = G.strip(wordSearch.trim());
    const list = A.db.words.filter(w => {
      if (wordFilter === 'verb' && w.pos !== 'verb') return false;
      if (wordFilter === 'adj' && w.pos !== 'adj') return false;
      if (wordFilter === 'other' && w.pos !== 'other') return false;
      if (['m', 'f', 'n'].includes(wordFilter) && A.genderOf(w) !== wordFilter) return false;
      if (wordFilter === 'irr' && !A.isIrregular(w)) return false;
      if (s && !G.strip(w.lemma).includes(s) && !G.strip(w.meaning).includes(s) && !(w.tags || []).some(t => G.strip(t).includes(s))) return false;
      return true;
    }).sort((a, b) => b.created - a.created);
    el.innerHTML = list.length ? list.map(w => `
      <li><a class="word-row g-bar-${A.genderOf(w) || 'x'}" href="#/word/${w.id}">
        <span class="wr-head">${A.headword(w)}${A.isIrregular(w) ? '<span class="irr-dot" title="Irregular"></span>' : ''}</span>
        <span class="wr-mean">${esc(w.meaning)}</span></a></li>`).join('')
      : `<li class="empty">${A.db.words.length ? 'No words match.' : 'No words yet. Add from the dictionary, the words of the day, or tap +.'}</li>`;
  }
  function topicList() {
    const topics = [];
    A.dict.forEach(e => { let t = topics.find(x => x.topicHeader === e.topic); if (!t) topics.push(t = { topicHeader: e.topic, items: [] }); if (t.items.length < 6) t.items.push(e); });
    return topics;
  }
  function dictRow(e) {
    const mine = A.findByLemma(e.lemma);
    return `<li><div class="word-row dict g-bar-${e.gender || 'x'}">
      <button class="dr-main" data-act="open-entry" data-l="${esc(e.lemma)}"><span class="wr-head">${e.emoji ? `<span class="emo">${e.emoji}</span>` : ''}${e.gender ? `<span class="art g-${e.gender}">${A.artJoin(e.lemma, e.gender)}</span>` : ''}<span class="lemma">${esc(e.lemma)}</span> <span class="pos-tag">${posLabel(e)}</span></span><span class="wr-mean">${esc(e.meaning)}</span></button>
      ${mine ? `<a class="dr-add on" href="#/word/${mine.id}" aria-label="In your words">✓</a>` : `<button class="dr-add" data-act="add-entry" data-l="${esc(e.lemma)}" aria-label="Add">+</button>`}
    </div></li>`;
  }
  const posLabel = e => ({ noun: '', verb: 'verb', adj: 'adj', other: e.tag === 'adv' ? 'adv' : e.tag === 'conj' ? 'conj' : e.tag === 'prep' ? 'prep' : '' }[e.pos] || '');
  A.inputs.search = v => { wordSearch = v; fillWords(); };
  A.acts.filter = el => { wordFilter = el.dataset.f; A.render(); };
  const entryByLemma = l => A.dict.find(e => e.lemma === l);
  A.acts['open-entry'] = el => A.go('#/entry/' + encodeURIComponent(el.dataset.l));
  A.acts['add-entry'] = function (el) {
    const e = entryByLemma(el.dataset.l); if (!e) return;
    if (A.findByLemma(e.lemma)) return A.toast('Already in your words');
    const w = A.entryToWord(e);
    A.db.words.push(w); A.save(); A.resetIndex(); A.xp(1);
    A.toast('Added ' + A.plainHead(w));
    if (el.closest('.wod')) { el.textContent = '✓ Added'; el.disabled = true; }
    else if (el.classList.contains('dr-add')) { el.outerHTML = `<a class="dr-add on" href="#/word/${w.id}">✓</a>`; }
    else A.render();
  };

  // dictionary entry page (built-in word, not yet necessarily mine)
  A.routes.entry = function (lemma) {
    const e = entryByLemma(lemma);
    if (!e) return A.go('#/words/dict');
    const mine = A.findByLemma(e.lemma);
    if (mine) return A.go('#/word/' + mine.id);
    const w = A.entryToWord(e);
    const t = A.tableFor(w, A._allTenses);
    A.view().innerHTML = `
      <header class="top"><a class="back" href="#/words/dict">Dictionary</a></header>
      <section class="entry g-entry-${e.gender || 'x'}">
        <h1 class="entry-head" lang="${A.LANG.code}">${A.headword(w)}</h1>
        <p class="entry-meta">${esc(e.topic)} · ${['', 'core', 'intermediate', 'advanced'][e.level]}${posLabel(e) ? ' · ' + posLabel(e) : ''}</p>
        <p class="entry-mean">${esc(e.meaning)}</p>
        <div class="row-btns"><button class="btn primary" data-act="add-entry" data-l="${esc(e.lemma)}">+ Add to my words</button><button class="btn" data-act="speak" data-t="${esc(A.plainHead(w))}">🔊 Listen</button></div>
      </section>
      ${t ? `<section class="tables"><h2>${w.pos === 'verb' ? 'Conjugation' : 'Declension'}</h2>${A.renderTable(w, t, true)}${moreTenses(t)}</section>` : ''}
      ${sameTopic(e)}`;
  };
  function sameTopic(e) {
    const rel = A.dict.filter(x => x.topic === e.topic && x !== e).slice(0, 8);
    return rel.length ? `<section><h2>More from ${esc(e.topic)}</h2><div class="chips wrap">${rel.map(x => `<button class="chip" data-act="open-entry" data-l="${esc(x.lemma)}" lang="${A.LANG.code}">${x.emoji || ''} ${esc(A.entryHead(x))}</button>`).join('')}</div></section>` : '';
  }

  // lookup sheet: used from reading texts, tutor chat, phrases
  A.acts.lookup = function (el) {
    const tok = el.dataset.t;
    const hits = A.lookupForm(tok);
    const seen = new Set();
    const items = hits.filter(h => { const k = h.kind === 'dict' ? 'd' + h.e.lemma : 'm' + h.id; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 4);
    const body = items.length ? items.map(h => {
      if (h.kind === 'mine') { const w = A.findWord(h.id); return w ? `<div class="lk"><p class="lk-word" lang="${A.LANG.code}">${A.headword(w)}</p><p>${esc(w.meaning)}</p><div class="row-btns"><a class="btn sm" href="#/word/${w.id}" data-act="sheet-close-go">Open</a><button class="btn sm" data-act="speak" data-t="${esc(A.plainHead(w))}">🔊</button><span class="tiny">In your words</span></div></div>` : ''; }
      const e = h.e;
      return `<div class="lk"><p class="lk-word" lang="${A.LANG.code}">${e.emoji ? `<span class="emo">${e.emoji}</span>` : ''}${e.gender ? `<span class="art g-${e.gender}">${A.artJoin(e.lemma, e.gender)}</span>` : ''}<span class="lemma">${esc(e.lemma)}</span></p><p>${esc(e.meaning)}</p>
        <div class="row-btns"><button class="btn sm primary" data-act="add-entry-sheet" data-l="${esc(e.lemma)}" data-ctx="${esc(el.dataset.ctx || '')}">+ Add</button><button class="btn sm" data-act="entry-sheet" data-l="${esc(e.lemma)}">Forms</button><button class="btn sm" data-act="speak" data-t="${esc(e.lemma)}">🔊</button></div></div>`;
    }).join('') : `<p class="muted">Not in the dictionary.</p><div class="row-btns"><button class="btn sm" data-act="ask-lookup" data-t="${esc(tok)}">✨ Ask Claude</button><button class="btn sm" data-act="inbox-token" data-t="${esc(tok)}">Save to inbox</button><button class="btn sm" data-act="open-url" data-url="${esc(A.LANG.lookupUrl(tok))}">Wiktionary</button></div>`;
    A.sheet(`<h2 lang="${A.LANG.code}">${esc(tok)}</h2>${body}`);
  };
  A.acts['add-entry-sheet'] = function (el) {
    const e = entryByLemma(el.dataset.l); if (!e) return;
    if (A.findByLemma(e.lemma)) { A.closeSheet(); return A.toast('Already in your words'); }
    const w = A.entryToWord(e, el.dataset.ctx ? { examples: [{ text: el.dataset.ctx, source: 'Reading' }] } : {});
    A.db.words.push(w); A.save(); A.resetIndex(); A.xp(1); A.closeSheet(); A.toast('Added ' + A.plainHead(w));
  };
  A.acts['entry-sheet'] = el => { A.closeSheet(); A.go('#/entry/' + encodeURIComponent(el.dataset.l)); };
  A.acts['sheet-close-go'] = () => A.closeSheet();
  A.acts['inbox-token'] = el => { A.db.inbox.push({ id: A.uid(), text: el.dataset.t, context: '', source: 'Lookup', created: Date.now() }); A.save(); A.closeSheet(); A.toast('Saved to inbox'); };
  A.acts['ask-lookup'] = async function (el) {
    const tok = (el.dataset.t || '').trim(); if (!tok) return;
    if (!A.aiReady()) { A.sheet(`<h2>Ask Claude</h2>${A.needKeyCard()}`); return; }
    A.sheet(`<h2 lang="${A.LANG.code}">${esc(tok)}</h2><p class="muted thinking">Asking Claude…</p>`);
    try {
      const r = A.ask ? await A.ask({ system: window.AI.prompts.lookup, messages: [{ role: 'user', content: tok }], maxTokens: 500 }) : '';
      const d = window.AI.parseJSON(r);
      A._aiWord = d;
      const g = G.ART_TO_G[d.article] || '';
      A.sheet(`<h2 lang="${A.LANG.code}">${g ? `<span class="art g-${g}">${esc(d.article)}</span> ` : ''}${esc(d.lemma)}</h2><p>${esc(d.meaning)}</p>${d.example ? `<p class="ex" lang="${A.LANG.code}">${esc(d.example)}</p>` : ''}${d.notes ? `<p class="tiny">${esc(d.notes)}</p>` : ''}
        <div class="row-btns"><button class="btn primary" data-act="add-ai-word">+ Add to my words</button><button class="btn" data-act="speak" data-t="${esc(d.lemma)}">🔊</button></div>`);
    } catch (e) { A.sheet(`<h2>Couldn't look that up</h2><p class="muted">${esc(e.message === 'NO_KEY' ? 'Add your API key in Settings.' : e.message)}</p>`); }
  };
  A.addAiWord = function (d, source) {
    if (A.findByLemma(d.lemma)) { A.toast('Already in your words'); return null; }
    const head = (d.article ? d.article + ' ' : '') + d.lemma;
    const a = G.analyse(head, { pos: d.pos });
    const ov = {}; if (d.aorist) ov.aorist = d.aorist; if (d.future) ov.future = d.future;
    const w = A.newWord({ lemma: d.lemma, pos: a.pos, gender: a.gender || '', article: d.article || '', paradigm: a.paradigm || null, group: a.group || null,
      meaning: d.meaning || '', note: d.notes || '', ov, irregular: !!d.aorist, examples: d.example ? [{ text: d.example, source: source || 'Claude' }] : [], source: source || 'Claude' });
    A.db.words.push(w); A.save(); A.resetIndex(); A.xp(1);
    A.toast('Added ' + A.plainHead(w));
    return w;
  };
  A.acts['add-ai-word'] = () => { if (A._aiWord) A.addAiWord(A._aiWord); A.closeSheet(); };

  // ---------------- INBOX ----------------
  A.routes.inbox = function () {
    A.view().innerHTML = `
      <header class="top"><a class="back" href="#/today">Today</a><h1>Inbox</h1>
      <p class="muted">Words you captured on the go. File each one to give it grammar and start reviewing it.</p></header>
      ${A.db.inbox.length ? `<ul class="list">${A.db.inbox.slice().reverse().map(it => {
        const hit = A.lookupForm(it.text).find(h => h.kind === 'dict');
        return `<li class="inbox-item">
          <div><p class="lemma-sm" lang="${A.LANG.code}">${esc(it.text)}</p>${hit ? `<p class="tiny">Dictionary: ${esc(A.entryHead(hit.e))}, ${esc(hit.e.meaning)}</p>` : ''}${it.context ? `<p class="ctx" lang="${A.LANG.code}">${esc(it.context)}</p>` : ''}<p class="tiny">${esc(it.source || '')} · ${new Date(it.created).toLocaleDateString('en-GB')}</p></div>
          <div class="item-btns"><button class="btn sm primary" data-act="file" data-id="${it.id}">File</button><button class="btn sm ghost" data-act="inbox-del" data-id="${it.id}" aria-label="Delete">✕</button></div>
        </li>`; }).join('')}</ul>` : `<p class="empty">Nothing waiting. Capture words from Today, or select text in Instagram or Chrome and choose Λέξεις.</p>`}`;
  };
  A.acts.file = function (el) {
    const it = A.db.inbox.find(i => i.id === el.dataset.id); if (!it) return;
    const hit = A.lookupForm(it.text).find(h => h.kind === 'dict');
    if (hit && !A.findByLemma(hit.e.lemma)) {
      const w = A.entryToWord(hit.e, { examples: it.context ? [{ text: it.context, source: it.source }] : [], source: it.source });
      A.db.words.push(w); A.db.inbox = A.db.inbox.filter(x => x.id !== it.id); A.save(); A.resetIndex(); A.xp(1);
      A.toast('Filed as ' + A.plainHead(w)); return A.go('#/word/' + w.id);
    }
    A.go('#/add/inbox:' + it.id);
  };
  A.acts['inbox-del'] = el => { A.db.inbox = A.db.inbox.filter(x => x.id !== el.dataset.id); A.save(); A.render(); };

  // ---------------- SHARE ----------------
  A.shared = null;
  A.routes.share = function () {
    const sh = A.shared;
    if (!sh) return A.go('#/today');
    const url = (sh.text.match(/https?:\/\/\S+/) || [])[0] || '';
    const src = /instagram/i.test(url) ? 'Instagram' : /youtu/i.test(url) ? 'YouTube' : /tiktok/i.test(url) ? 'TikTok' : url ? 'Web' : 'Shared';
    const body = sh.text.replace(/https?:\/\/\S+/g, '').trim();
    const tokens = Array.from(new Set((body.match(A.LANG.wordRe) || []).filter(t => t.length > 1)));
    Object.assign(sh, { src, body, url });
    A.view().innerHTML = `
      <header class="top"><h1>Add from ${esc(src)}</h1></header>
      ${body ? `<blockquote class="shared-text" lang="${A.LANG.code}">${esc(body.slice(0, 600))}</blockquote>` : ''}
      ${tokens.length ? `<p class="muted">Tap the words you want to keep.</p>
        <div class="tokens">${tokens.slice(0, 80).map(t => `<button class="token" data-act="tok" data-t="${esc(t)}">${esc(t)}</button>`).join('')}</div>
        <div class="row-btns sticky-btns"><button class="btn primary" data-act="share-inbox" disabled>Save to inbox</button><button class="btn" data-act="share-now" disabled>Add one now</button></div>`
      : `<p class="muted">${url ? 'Instagram shares only the link, not the words.' : ''} Type the word you heard. The link is kept as its source.</p>
        <form data-form="share-type" class="capture-form"><input name="text" placeholder="The word" lang="${A.LANG.code}" required autocomplete="off"><input name="ctx" placeholder="The sentence, if you remember it" lang="${A.LANG.code}" autocomplete="off"><button class="btn primary" type="submit">Save to inbox</button></form>`}
      <button class="btn ghost" data-act="share-cancel">Cancel</button>`;
  };
  const sentenceAround = (body, word) => ((body.split(/(?<=[.;!?·\n])\s+/).find(p => p.includes(word)) || body).trim().slice(0, 300));
  A.acts.tok = function (el) {
    el.classList.toggle('on');
    const n = A.$$('.token.on').length;
    A.$('[data-act="share-inbox"]').disabled = !n; A.$('[data-act="share-now"]').disabled = n !== 1;
  };
  A.acts['share-inbox'] = function () {
    const sh = A.shared, sel = A.$$('.token.on').map(b => b.dataset.t);
    sel.forEach(t => A.db.inbox.push({ id: A.uid(), text: G.lower(t), context: sentenceAround(sh.body, t), source: sh.src + (sh.url ? ' ' + sh.url : ''), created: Date.now() }));
    A.save(); A.shared = null; A.toast(`${sel.length} saved to inbox`); A.go('#/inbox');
  };
  A.acts['share-now'] = function () { const t = A.$('.token.on').dataset.t; A.shared.ctx = sentenceAround(A.shared.body, t); A.go('#/add/' + encodeURIComponent(G.lower(t))); };
  A.acts['share-cancel'] = () => { A.shared = null; A.go('#/today'); };
  A.forms['share-type'] = function (f, fd) {
    const sh = A.shared || { src: 'Shared' };
    A.db.inbox.push({ id: A.uid(), text: (fd.get('text') || '').trim(), context: (fd.get('ctx') || '').trim(), source: sh.src + (sh.url ? ' ' + sh.url : ''), created: Date.now() });
    A.save(); A.shared = null; A.toast('Saved to inbox'); A.go('#/inbox');
  };
  window.__lexeisShare = function (text, sid) {
    if (!text) return 1;
    if (sid && A.db.lastShare === sid) return 1;
    A.db.lastShare = sid || Date.now(); A.save();
    A.shared = { text: String(text) };
    const body = A.shared.text.replace(/https?:\/\/\S+/g, '').trim();
    const tokens = body.match(A.LANG.wordRe) || [];
    if (tokens.length === 1 && body.split(/\s+/).length <= 3) {
      A.shared.src = 'Shared'; A.shared.body = body;
      const hit = A.lookupForm(tokens[0]).find(h => h.kind === 'dict');
      if (hit) A.go('#/entry/' + encodeURIComponent(hit.e.lemma)); else A.go('#/add/' + encodeURIComponent(G.lower(tokens[0])));
    } else A.go('#/share');
    return 1;
  };

  // ---------------- ADD / EDIT ----------------
  let draft = null;
  A.routes.add = function (prefill) { renderAdd(prefill); };
  A.routes.edit = function (id) { renderAdd('', id); };
  function renderAdd(prefill, editId) {
    const editing = editId ? A.findWord(editId) : null;
    if (editing) draft = JSON.parse(JSON.stringify(editing));
    else {
      const inboxItem = prefill && prefill.startsWith('inbox:') ? A.db.inbox.find(i => i.id === prefill.slice(6)) : null;
      const text = inboxItem ? inboxItem.text : prefill;
      draft = A.newWord({ _input: text || '', _inbox: inboxItem ? inboxItem.id : null,
        examples: inboxItem && inboxItem.context ? [{ text: inboxItem.context, source: inboxItem.source || '' }] : [], source: inboxItem ? inboxItem.source || '' : '' });
      if (A.shared && A.shared.ctx && !inboxItem) { draft.examples = [{ text: A.shared.ctx, source: A.shared.src }]; draft.source = A.shared.src; }
      if (text) applyAnalysis(text);
    }
    const input = editing ? A.plainHead(editing) : draft._input;
    const ex = draft.examples[0] || {};
    A.view().innerHTML = `
      <header class="top">${editing ? `<a class="back" href="#/word/${editing.id}">Back</a>` : ''}<h1>${editing ? 'Edit word' : 'Add a word'}</h1></header>
      <form data-form="word" class="word-form" autocomplete="off">
        <label class="field"><span>${A.LANG.name}</span><input name="greek" value="${esc(input)}" placeholder="${esc(A.LANG.addPlaceholder)}" lang="${A.LANG.code}" autocapitalize="off" required data-input="greek"></label>
        <div id="dictHint"></div>
        <div id="analysis"></div>
        <label class="field"><span>Meaning</span><input name="meaning" value="${esc(draft.meaning)}" placeholder="In English" autocapitalize="off"></label>
        <label class="field"><span>Example sentence</span><textarea name="example" rows="2" lang="${A.LANG.code}" placeholder="Where you saw or heard it">${esc(ex.text || '')}</textarea></label>
        <label class="field"><span>Source</span><input name="source" value="${esc(draft.source || ex.source || '')}" placeholder="Instagram, a book, a friend…" list="sources"></label>
        <datalist id="sources"><option value="Instagram"><option value="Reading"><option value="TV / film"><option value="Podcast"><option value="Conversation"></datalist>
        <label class="field"><span>Note</span><input name="note" value="${esc(draft.note)}" placeholder="Anything to remember about it"></label>
        <label class="field"><span>Tags</span><input name="tags" value="${esc((draft.tags || []).join(', '))}" placeholder="food, work, slang"></label>
        <div id="dup"></div>
        <button class="btn primary wide" type="submit">${editing ? 'Save changes' : 'Save word'}</button>
      </form>`;
    renderAnalysis();
  }
  function applyAnalysis(text, keep) {
    const a = G.analyse(text, keep || {});
    Object.assign(draft, { lemma: a.lemma, article: a.article, pos: a.pos, gender: a.gender || '', paradigm: a.paradigm || null, group: a.group || null, conf: a.conf });
  }
  function renderAnalysis() {
    const el = A.$('#analysis'); if (!el) return;
    const hint = A.$('#dictHint');
    if (hint) {
      const hit = draft.lemma ? A.lookupForm(draft.lemma).find(h => h.kind === 'dict') : null;
      hint.innerHTML = hit && !A.findByLemma(hit.e.lemma) ? `<button type="button" class="dict-hint" data-act="use-dict" data-l="${esc(hit.e.lemma)}"><span>In the dictionary:</span> <b lang="${A.LANG.code}">${esc(A.entryHead(hit.e))}</b> · ${esc(hit.e.meaning)} <em>Use it</em></button>` : '';
    }
    if (!draft.lemma) { el.innerHTML = ''; return; }
    const pos = [['noun', 'Noun'], ['verb', 'Verb'], ['adj', 'Adjective'], ['other', 'Other']];
    let html = `<div class="analysis"><div class="seg" role="radiogroup" aria-label="Part of speech">${pos.map(([k, l]) => `<button type="button" class="${draft.pos === k ? 'on' : ''}" data-act="pos" data-v="${k}">${l}</button>`).join('')}</div>`;
    if (draft.pos === 'noun') {
      html += `<div class="seg gender-seg" role="radiogroup" aria-label="Gender">${G.GENDERS.map(g => `<button type="button" class="g-${g} ${draft.gender === g ? 'on' : ''}" data-act="gender" data-v="${g}">${G.G_TO_ART[g]}</button>`).join('')}</div>`;
      if (!draft.gender) html += `<p class="hint">Pick the article. -ος words can be any gender.</p>`;
      else if (draft.conf === 'mid' && !draft.article) html += `<p class="hint">Guessed from the ending. -ος words are usually masculine, but check: η οδός, το λάθος.</p>`;
      const opts = Object.entries(G.PARADIGMS).filter(([, p]) => !draft.gender || p.g === draft.gender);
      html += `<label class="field inline"><span>Pattern</span><select data-change="paradigm"><option value="">Irregular / fill in myself</option>${opts.map(([k, p]) => `<option value="${k}" ${draft.paradigm === k ? 'selected' : ''}>${esc(p.label)}</option>`).join('')}</select></label>`;
      if (draft.paradigm) { const d = G.declineWith(draft.lemma, draft.paradigm); const g = draft.gender; html += `<p class="preview">${G.ARTICLES[g].sg[1]} <b>${esc(d['sg.gen'])}</b> · ${G.ARTICLES[g].pl[0]} <b>${esc(d['pl.nom'])}</b> · ${G.ARTICLES[g].pl[1]} <b>${esc(d['pl.gen'])}</b></p>`; }
    } else if (draft.pos === 'verb') {
      html += `<label class="field inline"><span>Group</span><select data-change="group">${Object.entries(G.GROUPS).map(([k, l]) => `<option value="${k}" ${draft.group === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
      const c = G.conjugate(draft.lemma, draft.group, draft.ov);
      if (c && c.tenses.aorist) {
        html += `<p class="preview">${esc(c.tenses.aorist[0])} · ${esc((c.tenses.future || [''])[0])} · ${esc(c.tenses.imperfect[0])}</p>`;
        if (c.conf.aorist === 'low' || c.conf.aorist === 'mid') html += `<p class="hint">The aorist is a guess. If it's irregular, fix it on the word page after saving.</p>`;
      }
    } else if (draft.pos === 'adj') {
      const a = G.declineAdj(draft.lemma);
      html += a ? `<p class="preview"><b class="g-m">${esc(a.m['sg.nom'])}</b> · <b class="g-f">${esc(a.f['sg.nom'])}</b> · <b class="g-n">${esc(a.n['sg.nom'])}</b></p>` : `<p class="hint">Only -ος adjectives are generated. You can fill in forms yourself.</p>`;
    }
    el.innerHTML = html + '</div>';
    const dup = A.$('#dup');
    if (dup) { const d = A.db.words.find(w => w.id !== draft.id && G.strip(w.lemma) === G.strip(draft.lemma)); dup.innerHTML = d ? `<p class="hint warn">Already in your words: <a href="#/word/${d.id}">${esc(A.plainHead(d))}</a></p>` : ''; }
  }
  A.acts['use-dict'] = function (el) {
    const e = entryByLemma(el.dataset.l); if (!e) return;
    const f = A.$('form[data-form="word"]'); const fd = new FormData(f);
    const ex = (fd.get('example') || '').trim();
    const w = A.entryToWord(e, { examples: ex ? [{ text: ex, source: fd.get('source') || '' }] : [], source: fd.get('source') || 'Dictionary', note: fd.get('note') || '' });
    if ((fd.get('meaning') || '').trim()) w.meaning = fd.get('meaning').trim();
    A.db.words.push(w);
    if (draft._inbox) A.db.inbox = A.db.inbox.filter(x => x.id !== draft._inbox);
    A.shared = null; A.save(); A.resetIndex(); A.xp(1); A.toast('Word saved'); A.go('#/word/' + w.id);
  };
  A.acts.pos = el => { draft.pos = el.dataset.v; draft._posLocked = true; reanalyse(); };
  A.acts.gender = el => { draft.gender = el.dataset.v; draft._genderLocked = draft.gender; draft.article = A.art(draft.lemma, draft.gender); draft.paradigm = G.guessNoun(draft.lemma, draft.gender).key; draft.conf = 'high'; renderAnalysis(); };
  function reanalyse() {
    const inp = A.$('[data-input="greek"]');
    const locks = { p: draft._posLocked, g: draft._genderLocked };
    applyAnalysis(inp ? inp.value : draft.lemma, { pos: draft.pos });
    draft._posLocked = locks.p; draft._genderLocked = locks.g;
    renderAnalysis();
  }
  A.inputs.greek = function (v) {
    const sp = G.splitArticle(v);
    const keep = {}; if (draft._posLocked) keep.pos = draft.pos;
    const locks = { p: draft._posLocked, g: draft._genderLocked };
    applyAnalysis(v, keep);
    draft._posLocked = locks.p; draft._genderLocked = locks.g;
    if (!sp.article && draft._genderLocked && draft.pos === 'noun') { draft.gender = draft._genderLocked; draft.paradigm = G.guessNoun(draft.lemma, draft.gender).key; }
    renderAnalysis();
  };
  A.changes.paradigm = el => { draft.paradigm = el.value || null; renderAnalysis(); };
  A.changes.group = el => { draft.group = el.value; renderAnalysis(); };
  A.forms.word = function (form, fd) {
    const greek = (fd.get('greek') || '').trim();
    if (!greek) return A.toast(`Type the ${A.LANG.name} word first`);
    const sp = G.splitArticle(greek);
    draft.lemma = G.norm(sp.word);
    if (sp.article && draft.pos === 'noun') draft.gender = G.ART_TO_G[sp.article] || draft.gender;
    draft.article = draft.pos === 'noun' && draft.gender ? A.art(draft.lemma, draft.gender) : '';
    draft.meaning = (fd.get('meaning') || '').trim(); draft.note = (fd.get('note') || '').trim(); draft.source = (fd.get('source') || '').trim();
    draft.tags = (fd.get('tags') || '').split(',').map(t => t.trim()).filter(Boolean);
    const exText = (fd.get('example') || '').trim();
    draft.examples = draft.examples || [];
    if (exText) { if (draft.examples[0]) { draft.examples[0].text = exText; draft.examples[0].source = draft.source; } else draft.examples.unshift({ text: exText, source: draft.source }); }
    else if (draft.examples[0]) draft.examples.shift();
    const inboxId = draft._inbox;
    ['_input', '_inbox', 'conf', '_posLocked', '_genderLocked'].forEach(k => delete draft[k]);
    const i = A.db.words.findIndex(w => w.id === draft.id);
    if (i >= 0) A.db.words[i] = draft; else { A.db.words.push(draft); A.xp(1); }
    if (inboxId) A.db.inbox = A.db.inbox.filter(x => x.id !== inboxId);
    A.shared = null; A.save(); A.resetIndex();
    A.toast(i >= 0 ? 'Changes saved' : 'Word saved');
    A.go('#/word/' + draft.id);
  };

  // ---------------- WORD PAGE ----------------
  A.routes.word = function (id) {
    const w = A.findWord(id);
    if (!w) return A.go('#/words');
    const t = A.tableFor(w, A._allTenses), g = A.genderOf(w), types = A.cardTypes(w);
    const nextDue = Math.min(...types.map(x => (w.srs[x] && w.srs[x].due) || Infinity));
    A.view().innerHTML = `
      <header class="top"><a class="back" href="#/words">Words</a></header>
      <section class="entry g-entry-${g || 'x'}">
        <h1 class="entry-head" lang="${A.LANG.code}">${A.headword(w)}</h1>
        <p class="entry-meta">${esc({ noun: 'noun', verb: 'verb', adj: 'adjective', other: 'phrase / other' }[w.pos])}${g ? ', ' + { m: 'masculine', f: 'feminine', n: 'neuter' }[g] : ''}${w.pos === 'verb' && w.group ? ', ' + esc(G.GROUPS[w.group].split(' (')[0]) : ''}${A.isIrregular(w) ? ', <span class="irr">irregular</span>' : ''}</p>
        <p class="entry-mean">${esc(w.meaning || 'No meaning yet')}</p>
        ${w.note ? `<p class="entry-note">${esc(w.note)}</p>` : ''}
        <div class="row-btns"><button class="btn sm" data-act="speak" data-t="${esc(A.plainHead(w))}">🔊 Listen</button><a class="btn sm" href="#/edit/${w.id}">Edit</a><button class="btn sm" data-act="drill-word" data-id="${w.id}" ${t ? '' : 'disabled'}>Drill forms</button></div>
      </section>
      ${w.examples && w.examples.length ? `<section class="examples"><h2>In context</h2>${w.examples.map(e => `<blockquote lang="${A.LANG.code}">${A.tappable(e.text)}${e.source ? `<cite>${esc(e.source)}</cite>` : ''}</blockquote>`).join('')}</section>` : ''}
      ${w.pos === 'verb' && w.group !== 'IRR' && A.LANG.code === 'el' ? principalParts(w) : ''}
      ${t ? `<section class="tables"><h2>${w.pos === 'verb' ? 'Conjugation' : 'Declension'}</h2><p class="tiny">Tap any form to correct it. Corrections are marked and drilled more often.</p>${A.renderTable(w, t)}${moreTenses(t)}</section>`
        : (w.pos === 'noun' ? `<section class="tables"><h2>Declension</h2><p class="muted">No pattern set. Pick one in Edit, or <button class="linkish" data-act="manual-table" data-id="${w.id}">fill in the forms yourself</button>.</p></section>` : '')}
      <section class="study"><h2>Review</h2>
        <p class="muted">${types.length ? (nextDue === Infinity ? 'New. It will appear in your next review.' : 'Next review ' + (nextDue <= Date.now() ? 'now' : new Date(nextDue).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })) + '.') : 'Add a meaning to start reviewing this word.'}</p>
        <label class="toggle"><input type="checkbox" data-change="irregular" data-id="${w.id}" ${w.irregular ? 'checked' : ''}> Treat as irregular (drilled more often)</label>
      </section>
      <button class="btn danger ghost" data-act="delete-word" data-id="${w.id}">Delete word</button>`;
  };
  function moreTenses(t) {
    if (t.kind !== 'verb' || (!t.hidden && !A._allTenses) || !A.stageInfo) return '';
    return `<button class="linkish more-tenses" data-act="all-tenses">${A._allTenses ? 'Show only my level\'s tenses' : `Show ${t.hidden} more tense${t.hidden === 1 ? '' : 's'} (for later)`}</button>`;
  }
  A.acts['all-tenses'] = () => { A._allTenses = !A._allTenses; A.render(); };
  function principalParts(w) {
    const c = G.conjugate(w.lemma, w.group, w.ov) || { tenses: {}, conf: {} };
    const field = (k, label, ph) => `<label class="pp"><span>${label}</span><input lang="${A.LANG.code}" data-pp="${k}" data-id="${w.id}" value="${esc((w.ov || {})[k] || '')}" placeholder="${esc(ph)}" autocapitalize="off"></label>`;
    return `<section class="pparts"><h2>Key forms</h2>
      <p class="tiny">Irregular verb? Type the 1st person forms and the rest of each tense is rebuilt from them.${c.conf.aorist === 'low' ? ' <b>The aorist below is only a guess.</b>' : ''}</p>
      <div class="pp-grid">${field('imperfect', 'Imperfect', (c.tenses.imperfect || [''])[0])}${field('aorist', 'Aorist', (c.tenses.aorist || [''])[0])}${field('future', 'θα …', ((c.tenses.future || [''])[0] || '').replace(/^θα /, ''))}</div></section>`;
  }
  A.renderTable = function (w, t, readonly) {
    const cell = r => readonly ? `<span class="cell ro" lang="${A.LANG.code}">${r.prefix ? `<span class="pfx">${esc(r.prefix)}</span> ` : ''}${esc(r.value || '—')}</span>`
      : `<button class="cell ${r.edited ? 'edited' : ''}" data-act="cell" data-id="${w.id}" data-k="${r.key}" lang="${A.LANG.code}">${r.prefix ? `<span class="pfx">${esc(r.prefix)}</span> ` : ''}${esc(r.value || '—')}</button>`;
    if (t.kind === 'verb') {
      return `<div class="tense-tabs">${t.sections.map((s, i) => `<button class="tt ${i === 0 ? 'on' : ''}" data-act="tense-tab" data-i="${i}">${esc(s.title.split(' (')[0])}${s.conf === 'low' ? '*' : ''}</button>`).join('')}</div>` +
        t.sections.map((s, i) => `<div class="tbl tense-pane" data-i="${i}" ${i ? 'hidden' : ''}><h3>${esc(s.title)}${s.conf === 'low' ? ' <span class="guess">guess</span>' : ''}</h3><table><tbody>${s.rows.map(r => `<tr><th>${esc(r.label)}</th><td>${cell(r)}</td></tr>`).join('')}</tbody></table></div>`).join('');
    }
    if (t.kind === 'noun') {
      const [sg, pl] = t.sections;
      return `<div class="tbl"><table class="decl"><thead><tr><th></th><th>Singular</th><th>Plural</th></tr></thead><tbody>${G.CASES.map((c, i) => `<tr><th>${G.CASES.length > 1 ? G.CASE_LABEL[c].slice(0, 3) : ''}</th><td>${cell(sg.rows[i])}</td><td>${cell(pl.rows[i])}</td></tr>`).join('')}</tbody></table></div>`;
    }
    const by = {}; t.sections.forEach(s => { by[s.gender + s.num] = s; });
    return ['sg', 'pl'].map(n => `<div class="tbl"><h3>${n === 'sg' ? 'Singular' : 'Plural'}</h3><table class="decl adj"><thead><tr><th></th>${G.GENDERS.map(g => `<th class="g-${g}">${{ m: 'Masc.', f: 'Fem.', n: 'Neut.' }[g]}</th>`).join('')}</tr></thead><tbody>${G.CASES.map((c, i) => `<tr><th>${G.CASES.length > 1 ? G.CASE_LABEL[c].slice(0, 3) : ''}</th>${G.GENDERS.map(g => `<td>${cell(by[g + n].rows[i])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`).join('');
  };
  A.acts['tense-tab'] = function (el) {
    const box = el.closest('.tables');
    A.$$('.tt', box).forEach(b => b.classList.toggle('on', b === el));
    A.$$('.tense-pane', box).forEach(p => { p.hidden = p.dataset.i !== el.dataset.i; });
  };
  A.acts.cell = function (el) {
    const w = A.findWord(el.dataset.id), key = el.dataset.k;
    const r = A.allRows(w).find(x => x.key === key) || { auto: '', value: '' };
    A.sheet(`<h2>Correct this form</h2><p class="muted">${esc(A.plainHead(w))} · ${esc(describeKey(w, key))}</p>
      <form data-form="cell" data-id="${w.id}" data-k="${key}"><input name="v" value="${esc(r.value)}" lang="${A.LANG.code}" autocapitalize="off" autocomplete="off">
      ${r.auto ? `<p class="tiny">Rule gives: ${esc(r.auto)}</p>` : ''}
      <div class="row-btns"><button class="btn primary" type="submit">Save form</button>${(w.cells || {})[key] != null ? `<button type="button" class="btn" data-act="cell-reset" data-id="${w.id}" data-k="${key}">Use the rule</button>` : ''}<button type="button" class="btn ghost" data-act="sheet-close">Cancel</button></div></form>`);
  };
  function describeKey(w, key) {
    const p = key.split('.');
    if (w.pos === 'verb') return `${G.TENSE_LABEL[p[0]]}, ${G.PERSONS[+p[1]]}`;
    if (w.pos === 'adj') return `${{ m: 'masculine', f: 'feminine', n: 'neuter' }[p[0]]} ${G.CASE_LABEL[p[2]].toLowerCase()} ${p[1] === 'sg' ? 'singular' : 'plural'}`;
    return `${G.CASE_LABEL[p[1]]} ${p[0] === 'sg' ? 'singular' : 'plural'}`;
  }
  A.forms.cell = function (f, fd) {
    const w = A.findWord(f.dataset.id), k = f.dataset.k, v = G.norm(fd.get('v') || '');
    const r = A.allRows(w).find(x => x.key === k);
    w.cells = w.cells || {};
    if (!v || (r && v === r.auto)) delete w.cells[k]; else w.cells[k] = v;
    A.save(); A.resetIndex(); A.closeSheet(); A.toast('Form saved'); A.render();
  };
  A.acts['cell-reset'] = el => { const w = A.findWord(el.dataset.id); delete w.cells[el.dataset.k]; A.save(); A.closeSheet(); A.render(); };
  A.acts['manual-table'] = el => { const w = A.findWord(el.dataset.id); w.cells = w.cells || {}; w.cells['sg.nom'] = w.lemma; w.irregular = true; A.save(); A.render(); };
  A.acts['delete-word'] = el => A.sheet(`<h2>Delete this word?</h2><p class="muted">${esc(A.plainHead(A.findWord(el.dataset.id)))} and its review history will be removed.</p><div class="row-btns"><button class="btn danger" data-act="delete-yes" data-id="${el.dataset.id}">Delete word</button><button class="btn ghost" data-act="sheet-close">Keep it</button></div>`);
  A.acts['delete-yes'] = el => { A.db.words = A.db.words.filter(w => w.id !== el.dataset.id); A.save(); A.resetIndex(); A.closeSheet(); A.toast('Word deleted'); A.go('#/words'); };
  A.changes.irregular = el => { const w = A.findWord(el.dataset.id); w.irregular = el.checked; A.save(); };
  A.changes.pp = function (el) {
    const w = A.findWord(el.dataset.id), pp = el.dataset.pp;
    w.ov = w.ov || {};
    const v = G.norm(el.value).replace(/^θα\s+/, '');
    if (v) w.ov[pp] = v; else delete w.ov[pp];
    Object.keys(w.cells || {}).forEach(c => { if (c.startsWith(pp + '.') || (pp === 'aorist' && /^(future|perfect|imperative)\./.test(c)) || (pp === 'future' && /^(perfect|imperative)\./.test(c))) delete w.cells[c]; });
    A.save(); A.resetIndex(); A.render(); A.toast('Forms rebuilt');
  };

  // ---------------- REVIEW ----------------
  let session = null;
  function startSession() {
    const q = A.dueQueue();
    const items = q.due.concat(q.fresh);
    for (let i = 1; i < items.length; i++) if (items[i].w.id === items[i - 1].w.id) { const j = items.findIndex((x, k) => k > i && x.w.id !== items[i].w.id); if (j > 0) [items[i], items[j]] = [items[j], items[i]]; }
    session = { items, i: 0, done: 0, right: 0, startedWith: items.length };
  }
  A.routes.review = function () {
    if (!session || session.i >= session.items.length) {
      if (session && session.startedWith && session.i >= session.items.length) return reviewDone();
      startSession();
      if (!session.items.length) return reviewDone();
    }
    const it = session.items[session.i], { w, t } = it;
    it.q = it.q || (t === 'form' ? A.formQuestion(w) : t === 'cloze' ? A.clozeFor(w) : null);
    const q = it.q, total = session.items.length;
    const g = A.genderOf(w);
    let front = '', back = '', mode = 'flip';
    if (t === 'mean') { front = `<p class="cue">What does it mean?</p><p class="card-word" lang="${A.LANG.code}">${A.headword(w)}</p>`; back = `<p class="card-mean">${esc(w.meaning)}</p>${w.examples[0] ? `<p class="card-ex" lang="${A.LANG.code}">${esc(w.examples[0].text)}</p>` : ''}`; }
    else if (t === 'recall') { front = `<p class="cue">Say it in ${A.LANG.name}${w.pos === 'noun' ? ', with the article' : ''}</p><p class="card-mean big">${esc(w.meaning)}</p>${w.note ? `<p class="muted">${esc(w.note)}</p>` : ''}${A.canListen() ? `<button class="mic-btn sm" data-act="rv-say" aria-label="Say it">🎙️</button><p class="tiny center" id="saidRes"></p>` : ''}`; back = `<p class="card-word" lang="${A.LANG.code}">${A.headword(w)}</p>`; }
    else if (t === 'gender') { mode = 'pick'; front = `<p class="cue">Which article?</p><p class="card-word" lang="${A.LANG.code}"><span class="lemma">${esc(w.lemma)}</span></p><p class="muted">${esc(w.meaning)}</p><div class="gender-pick g${G.GENDERS.length}">${G.GENDERS.map(x => `<button class="gp g-${x}" data-act="gp" data-g="${x}">${G.G_TO_ART[x]}</button>`).join('')}</div>`; back = `<p class="verdict"></p><p class="card-word" lang="${A.LANG.code}">${A.headword(w)}</p>`; }
    else {
      mode = 'type';
      front = t === 'form' && q ? `<p class="cue">${esc(q.prompt.detail)}</p><p class="card-word" lang="${A.LANG.code}">${esc(q.prompt.head)}</p><p class="muted">${esc(w.meaning)}</p>`
        : q ? `<p class="cue">Fill the gap</p><p class="cloze" lang="${A.LANG.code}">${esc(q.before)}<span class="gap">…</span>${esc(q.after)}</p><p class="muted">${esc(w.meaning)} (${esc(w.lemma)})</p>` : '';
      front += `<form data-form="typed" class="typed"><input name="a" lang="${A.LANG.code}" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Type the form">${A.canListen() ? '<button type="button" class="icon-btn mic" data-act="mic-fill" aria-label="Say it">🎙️</button>' : ''}<button class="btn primary" type="submit">Check</button></form>`;
      back = `<p class="verdict"></p><p class="card-word sm" lang="${A.LANG.code}">${q ? esc(t === 'form' ? (q.prompt.prefix ? q.prompt.prefix + ' ' : '') + q.row.value : q.answer) : ''}</p>`;
    }
    const s = w.srs[t] || null;
    A.view().innerHTML = `<div class="review">
      <div class="rv-top"><a class="back" href="#/today">Stop</a><span class="rv-count">${session.i + 1} / ${total}</span></div>
      <div class="progress"><span style="width:${Math.round(session.i / total * 100)}%"></span></div>
      <div class="flip ${mode}" id="flip"><article class="card face front g-card-${g || 'x'}" ${mode === 'flip' ? 'data-act="reveal"' : ''}>${front}${mode === 'flip' ? '<p class="tap-hint">Tap to flip</p>' : ''}</article>
      <article class="card face back g-card-${g || 'x'}">${mode === 'flip' ? front.replace('class="cue"', 'class="cue faint"') : ''}<div class="answer">${back}</div></article></div>
      <div class="rv-actions">
        <div class="grades" hidden>${[['Again', 0], ['Hard', 1], ['Good', 2], ['Easy', 3]].map(([l, x]) => `<button class="grade gr-${x}" data-act="grade" data-g="${x}"><span>${l}</span><small>${A.previewIvl(s, x)}</small></button>`).join('')}</div>
        <button class="btn ghost sm" data-act="speak" data-t="${esc(A.plainHead(w))}">🔊 Listen</button>
      </div></div>`;
    const inp = A.$('.typed input'); if (inp) inp.focus();
  };
  function reveal(verdict, suggested) {
    const f = A.$('#flip'); if (!f) return;
    if (f.classList.contains('flip') && f.classList.contains('type') || f.classList.contains('pick')) {
      const back = A.$('.back .answer', f); const front = A.$('.front', f);
      front.insertAdjacentHTML('beforeend', `<div class="answer inline">${back.innerHTML}</div>`);
      A.$$('.typed input, .typed button', front).forEach(x => x.disabled = true);
    } else f.classList.add('flipped');
    if (verdict) { const v = A.$('.front .verdict') || A.$('.verdict'); if (v) { v.textContent = verdict; v.className = 'verdict ' + (suggested >= 2 ? 'ok' : suggested === 1 ? 'mid' : 'bad'); } }
    const gr = A.$('.grades'); gr.hidden = false;
    if (suggested != null) A.$$('.grade', gr).forEach(b => b.classList.toggle('suggest', +b.dataset.g === suggested));
  }
  A.acts['rv-say'] = async function (el) {
    const it = session.items[session.i], target = A.plainHead(it.w), res = A.$('#saidRes');
    res.textContent = 'Listening…';
    try {
      const m = await A.listen(it.w.meaning); const b = A.bestMatch(m, target);
      A.db.stats.spoken = (A.db.stats.spoken || 0) + 1; A.save();
      res.innerHTML = `I heard <b>${esc(b.text || '…')}</b>`;
      reveal(b.score >= 0.8 ? 'You said it! 🎉' : b.score > 0.5 ? 'Close!' : 'Not quite', b.score >= 0.8 ? 2 : b.score > 0.5 ? 1 : 0);
      (b.score >= 0.8 ? A.sfx.right : A.sfx.wrong)();
    } catch (e) { res.textContent = e.message; }
  };
  A.acts['rem-on'] = async () => { await A.enableReminders(true); A.render(); };
  A.acts['rem-dismiss'] = () => { A.global.remDismissed = true; A.saveGlobal(); A.render(); };
  A.acts.reveal = () => { const f = A.$('#flip'); if (f && !f.classList.contains('flipped')) reveal(null, null); };
  A.acts.gp = function (el) {
    const it = session.items[session.i], right = A.genderOf(it.w), ok = el.dataset.g === right;
    A.$$('.gp').forEach(b => { b.disabled = true; b.classList.toggle('right', b.dataset.g === right); b.classList.toggle('wrongpick', b === el && !ok); });
    reveal(ok ? 'Right' : 'Not quite', ok ? 2 : 0);
  };
  A.forms.typed = function (f, fd) {
    const it = session.items[session.i], q = it.q;
    const exp = it.t === 'form' ? q.row.value : q.answer;
    const res = A.checkAnswer(fd.get('a') || '', exp);
    reveal(res === 'right' ? 'Right' : res === 'accent' ? 'Nearly: check the stress' : 'Not quite', res === 'right' ? 2 : res === 'accent' ? 1 : 0);
  };
  A.acts.grade = function (el) {
    const g = +el.dataset.g, it = session.items[session.i], { w, t } = it;
    const wasNew = !w.srs[t];
    w.srs[t] = A.schedule(w.srs[t], g);
    if (wasNew) A.bumpDay('new');
    A.bumpDay('reviews'); A.xp(g > 0 ? 2 : 1);
    if (g > 0) { A.bumpDay('correct'); session.right++; }
    A.recordCat(t === 'form' && it.q ? it.q.cat : t === 'gender' ? 'gender:' + A.genderOf(w) : t === 'mean' ? 'meaning' : t, g > 0);
    if (g === 0) session.items.splice(Math.min(session.items.length, session.i + 4), 0, { w, t });
    A.save(); session.i++; session.done++;
    A.routes.review();
  };
  function reviewDone() {
    const s = session || { done: 0, right: 0 };
    A.view().innerHTML = `<header class="top"><h1>${s.done ? 'Review done' : 'Nothing to review'}</h1></header>
      <section class="done-card">${s.done ? `${A.ring(s.right, s.done, 120, 'Remembered')}<p class="big-num">${Math.round(s.right / s.done * 100)}%</p><p class="muted">${s.done} cards. Next due ${A.nextDueText()}.</p>` : `<p class="muted">${A.db.words.length ? 'Everything is scheduled for later. Try a flash test.' : 'Add some words first.'}</p>`}
      <div class="row-btns"><a class="btn primary" href="#/today">Back to today</a><a class="btn" href="#/flash">Flash test</a></div></section>`;
    session = null;
  }
  A.acts.speak = el => A.speak(el.dataset.t);
  A.acts['open-url'] = el => A.openUrl(el.dataset.url);
  A.acts['sheet-close'] = () => A.closeSheet();
})();
